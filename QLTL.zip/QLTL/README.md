# ỨNG DỤNG QUẢN LÝ TÀI LIỆU HỌC TẬP (QLTL)
## ĐỒ ÁN THỰC HÀNH 1 - KIẾN TRÚC CASHEW (CLIENT-CENTRIC / LOCAL-FIRST)

- **Sinh viên thực hiện:** Đào Ngọc Đình
- **Mã sinh viên:** 2351170582
- **Lớp:** 65KTPM
- **Học phần:** Phát triển ứng dụng di động / Kiến trúc phần mềm
- **Repository tham chiếu:** [Cashew (DaoNgocDinh/Cashew)](https://github.com/DaoNgocDinh/Cashew)

---

## 1. GIỚI THIỆU TỔNG QUAN

Dự án **QLTL (Quản lý Tài liệu Học tập)** được thiết kế và triển khai dựa trên các nguyên lý kiến trúc cốt lõi của ứng dụng **Cashew**:
1. **Mô hình Local-First / Client-Centric:** Dữ liệu được lưu trữ, xử lý và truy vấn trực tiếp trên cơ sở dữ liệu SQLite cục bộ của thiết bị. Ứng dụng hoạt động với hiệu năng cao, tốc độ phản hồi tức thì và không phụ thuộc vào kết nối mạng hay Backend server trung gian.
2. **Kiến trúc phân lớp rõ ràng (Layered / Clean Architecture):** Phân tách tuyệt đối giữa 4 lớp:
   - **Domain Layer:** Chứa Business Entities (`Document`) và Repository Interface (`DocumentRepository`). Hoàn toàn độc lập với UI và cơ sở dữ liệu.
   - **Data Layer:** Chứa SQLite Database Helper (`DatabaseHelper`), Data Access Object (`DocumentDao`), Data Models (`DocumentModel`), và Repository Implementation (`DocumentRepositoryImpl`).
   - **Application Layer:** Chứa các Use Cases nghiệp vụ (`GetDocumentsUseCase`, `AddDocumentUseCase`, `UpdateDocumentUseCase`, `DeleteDocumentUseCase`, `SearchDocumentsUseCase`) và Quản lý trạng thái (`DocumentController` sử dụng `ChangeNotifier` / `Provider`).
   - **Presentation Layer:** Chứa giao diện người dùng Flutter (Material 3), bao gồm các màn hình (`DocumentListPage`, `AddEditDocumentPage`, `DocumentDetailPage`) và các widget tái sử dụng (`DocumentCard`, `CategoryFilterChip`, `DocumentSearchBar`, `ConfirmDeleteDialog`, `EmptyStateView`).

---

## 2. CẤU TRÚC THƯ MỤC DỰ ÁN

```text
QLTL/
├── lib/
│   ├── core/                           # Thành phần dùng chung toàn hệ thống
│   │   ├── constants/
│   │   │   └── app_constants.dart      # Hằng số danh mục, định dạng tệp, màu sắc, icon
│   │   └── theme/
│   │       └── app_theme.dart          # Cấu hình giao diện Material 3
│   ├── domain/                         # Lớp nghiệp vụ cốt lõi (Domain Layer)
│   │   ├── entities/
│   │   │   └── document.dart           # Thực thể Tài liệu học tập (Document)
│   │   └── repositories/
│   │       └── document_repository.dart# Contract / Interface thao tác tài liệu
│   ├── data/                           # Lớp dữ liệu (Data Layer)
│   │   ├── database/
│   │   │   └── database_helper.dart    # Khởi tạo SQLite, định nghĩa schema, migration, seed data
│   │   ├── dao/
│   │   │   └── document_dao.dart       # Data Access Object (thực hiện truy vấn SQL trực tiếp)
│   │   ├── models/
│   │   │   └── document_model.dart     # Ánh xạ Entity <-> SQLite Map
│   │   └── repositories/
│   │       └── document_repository_impl.dart # Triển khai DocumentRepository từ Domain
│   ├── application/                    # Lớp điều phối nghiệp vụ & trạng thái
│   │   ├── use_cases/                  # Các Use Case độc lập
│   │   │   ├── add_document.dart       # Thêm tài liệu mới (có kiểm tra dữ liệu hợp lệ)
│   │   │   ├── get_documents.dart      # Lấy danh sách tài liệu (hỗ trợ lọc danh mục)
│   │   │   ├── get_document_by_id.dart # Lấy chi tiết tài liệu theo ID
│   │   │   ├── update_document.dart    # Cập nhật tài liệu
│   │   │   ├── delete_document.dart    # Xóa tài liệu
│   │   │   └── search_documents.dart   # Tìm kiếm theo từ khóa & danh mục
│   │   └── controllers/
│   │       └── document_controller.dart# Quản lý State với ChangeNotifier / Provider
│   ├── presentation/                   # Lớp giao diện người dùng (Presentation Layer)
│   │   ├── pages/
│   │   │   ├── document_list_page.dart # Màn hình chính: Tìm kiếm, lọc danh mục, danh sách
│   │   │   ├── add_edit_document_page.dart # Màn hình thêm / sửa tài liệu
│   │   │   └── document_detail_page.dart   # Màn hình xem chi tiết tài liệu
│   │   └── widgets/
│   │       ├── document_card.dart      # Thẻ tài liệu kèm thông tin và menu thao tác
│   │       ├── category_chip.dart      # Chip lọc danh mục kèm bộ đếm số lượng
│   │       ├── document_search_bar.dart# Thanh tìm kiếm thời gian thực
│   │       ├── confirm_delete_dialog.dart # Hộp thoại xác nhận xóa an toàn
│   │       └── empty_state.dart        # Giao diện khi chưa có dữ liệu hoặc không tìm thấy
│   └── main.dart                       # Điểm khởi chạy & Dependency Injection
├── test/                               # Bộ kiểm thử tự động (Unit & Widget Tests)
│   ├── domain/
│   │   └── document_entity_test.dart   # Kiểm thử Domain Entity
│   ├── data/
│   │   ├── document_model_test.dart    # Kiểm thử Serialization và Mapping
│   │   └── document_dao_test.dart      # Kiểm thử SQLite In-Memory Database
│   ├── application/
│   │   ├── use_cases_test.dart         # Kiểm thử các Use Case nghiệp vụ
│   │   └── document_controller_test.dart # Kiểm thử State Management Controller
│   └── widget_test.dart                # Kiểm thử giao diện Widget
└── pubspec.yaml                        # Quản lý dependencies
```

---

## 3. SƠ ĐỒ LUỒNG DỮ LIỆU (DATA FLOW)

```mermaid
sequenceDiagram
    autonumber
    actor User as Người dùng
    participant UI as Presentation (Pages / Widgets)
    participant Ctrl as Controller (ChangeNotifier)
    participant UC as Application (Use Cases)
    participant Repo as Data (DocumentRepositoryImpl)
    participant DAO as Data (DocumentDao)
    participant DB as SQLite Database (Local Storage)

    Note over User,DB: Luồng 1: Xem & Lọc danh sách tài liệu
    User->>UI: Mở ứng dụng / Chọn Tab danh mục
    UI->>Ctrl: loadDocuments() / selectCategory("Bài giảng")
    Ctrl->>UC: GetDocumentsUseCase.execute(category)
    UC->>Repo: getAllDocuments(category)
    Repo->>DAO: getAllDocuments(category)
    DAO->>DB: SELECT * FROM study_documents WHERE category = ? ORDER BY updated_at DESC
    DB-->>DAO: Trả về danh sách Rows (List<Map>)
    DAO-->>Repo: List<Map<String, dynamic>>
    Repo-->>UC: Chuyển đổi Map sang List<Document>
    UC-->>Ctrl: List<Document>
    Ctrl-->>UI: Cập nhật state & notifyListeners()
    UI-->>User: Hiển thị danh sách thẻ tài liệu trực quan

    Note over User,DB: Luồng 2: Thêm mới tài liệu
    User->>UI: Nhập form & Bấm "Thêm tài liệu"
    UI->>Ctrl: addDocument(newDocument)
    Ctrl->>UC: AddDocumentUseCase.execute(newDocument)
    UC->>UC: Validate tiêu đề, danh mục không rỗng
    UC->>Repo: addDocument(sanitizedDoc)
    Repo->>DAO: insertDocument(documentModel.toMap())
    DAO->>DB: INSERT INTO study_documents (...) VALUES (...)
    DB-->>DAO: rowId mới
    DAO-->>Repo: rowId
    Repo-->>UC: rowId
    UC-->>Ctrl: Thành công
    Ctrl->>Ctrl: loadDocuments()
    Ctrl-->>UI: notifyListeners()
    UI-->>User: Đóng form, thông báo SnackBar thành công
```

---

## 4. HƯỚNG DẪN CÀI ĐẶT VÀ CHẠY ỨNG DỤNG

### 4.1. Yêu cầu hệ thống
- Flutter SDK >= 3.19.0 (Khuyến nghị 3.47 trở lên)
- Dart SDK >= 3.3.0
- Nền tảng hỗ trợ: Windows, Android, iOS, macOS, Linux

### 4.2. Cài đặt thư viện
Tại thư mục gốc `QLTL`, chạy lệnh:
```bash
flutter pub get
```

### 4.3. Chạy bộ kiểm thử (Automated Tests)
Kiểm thử toàn bộ 4 tầng kiến trúc:
```bash
flutter test
```
*Kết quả mong đợi: `All 20 tests passed!`*

### 4.4. Khởi chạy ứng dụng
Chạy trực tiếp trên thiết bị (hoặc máy ảo/Windows Desktop):
```bash
flutter run
```

---

## 5. KẾT QUẢ KIỂM THỬ (AUTOMATED TESTS SUMMARY)

| Tầng kiến trúc | File kiểm thử | Số test case | Trạng thái |
| :--- | :--- | :---: | :---: |
| **Domain Layer** | `test/domain/document_entity_test.dart` | 3 | **PASSED** (100%) |
| **Data Layer (Model)** | `test/data/document_model_test.dart` | 2 | **PASSED** (100%) |
| **Data Layer (SQLite)** | `test/data/document_dao_test.dart` | 4 | **PASSED** (100%) |
| **Application Layer (Use Cases)** | `test/application/use_cases_test.dart` | 6 | **PASSED** (100%) |
| **Application Layer (Controller)** | `test/application/document_controller_test.dart` | 4 | **PASSED** (100%) |
| **Presentation Layer (UI Widget)** | `test/widget_test.dart` | 1 | **PASSED** (100%) |
| **Tổng cộng** | **Tất cả các tầng** | **20** | **20/20 PASSED** |
