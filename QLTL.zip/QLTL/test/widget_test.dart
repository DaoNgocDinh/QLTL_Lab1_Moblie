import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:qltl/application/controllers/document_controller.dart';
import 'package:qltl/application/use_cases/add_document.dart';
import 'package:qltl/application/use_cases/delete_document.dart';
import 'package:qltl/application/use_cases/get_document_by_id.dart';
import 'package:qltl/application/use_cases/get_documents.dart';
import 'package:qltl/application/use_cases/search_documents.dart';
import 'package:qltl/application/use_cases/update_document.dart';
import 'package:qltl/core/theme/app_theme.dart';
import 'package:qltl/domain/entities/document.dart';
import 'package:qltl/domain/repositories/document_repository.dart';
import 'package:qltl/presentation/pages/document_list_page.dart';

class MockRepo implements DocumentRepository {
  final List<Document> _docs = [
    Document(
      id: 1,
      title: 'Kiến trúc Phần mềm',
      description: 'Phân tích Cashew App',
      category: 'Bài giảng',
      filePath: '/docs/cashew.pdf',
      fileType: 'PDF',
      author: 'Đào Ngọc Đình',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  @override
  Future<List<Document>> getAllDocuments({String? category}) async => _docs;

  @override
  Future<Document?> getDocumentById(int id) async => _docs.first;

  @override
  Future<int> addDocument(Document document) async => 2;

  @override
  Future<bool> updateDocument(Document document) async => true;

  @override
  Future<int> deleteDocument(int id) async => 1;

  @override
  Future<List<Document>> searchDocuments(String keyword, {String? category}) async => _docs;

  @override
  Stream<List<Document>> watchAllDocuments({String? category}) => Stream.value(_docs);
}

void main() {
  testWidgets('Kiểm thử giao diện DocumentListPage hiển thị đầy đủ thành phần', (WidgetTester tester) async {
    final repo = MockRepo();
    final controller = DocumentController(
      getDocumentsUseCase: GetDocumentsUseCase(repo),
      getDocumentByIdUseCase: GetDocumentByIdUseCase(repo),
      addDocumentUseCase: AddDocumentUseCase(repo),
      updateDocumentUseCase: UpdateDocumentUseCase(repo),
      deleteDocumentUseCase: DeleteDocumentUseCase(repo),
      searchDocumentsUseCase: SearchDocumentsUseCase(repo),
    );

    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<DocumentController>.value(value: controller),
        ],
        child: MaterialApp(
          theme: AppTheme.lightTheme,
          home: const DocumentListPage(),
        ),
      ),
    );

    // Initial pump & settle
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    // Verify Title
    expect(find.text('QL Tài Liệu Học Tập'), findsOneWidget);
    expect(find.text('Kiến trúc Cashew (Local-First)'), findsOneWidget);

    // Verify Search bar
    expect(find.byType(TextField), findsOneWidget);

    // Verify Filter chips
    expect(find.text('Tất cả'), findsOneWidget);
    expect(find.text('Bài giảng'), findsAtLeastNWidgets(1));

    // Verify FAB
    expect(find.text('Thêm tài liệu'), findsOneWidget);
    expect(find.byType(FloatingActionButton), findsOneWidget);
  });
}
