import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/data/database/database_helper.dart';
import 'package:qltl/data/models/document_model.dart';
import 'package:qltl/domain/entities/document.dart';

void main() {
  group('Data Layer - DocumentModel Mapping Tests', () {
    final now = DateTime.parse('2026-05-10T10:00:00.000Z');

    test('Chuyển đổi từ Domain Entity sang Data Model và ngược lại', () {
      final entity = Document(
        id: 10,
        title: 'Kiến trúc phần mềm',
        description: 'Tài liệu Cashew',
        category: 'Bài giảng',
        filePath: '/files/lecture.pdf',
        fileType: 'PDF',
        author: 'Đào Ngọc Đình',
        createdAt: now,
        updatedAt: now,
      );

      final model = DocumentModel.fromEntity(entity);
      expect(model.id, 10);
      expect(model.title, 'Kiến trúc phần mềm');

      final backToEntity = model.toEntity();
      expect(backToEntity, equals(entity));
    });

    test('Chuyển đổi từ Map SQLite sang DocumentModel và ngược lại (Serialization)', () {
      final map = <String, dynamic>{
        DatabaseHelper.colId: 5,
        DatabaseHelper.colTitle: 'Đề thi cuối kỳ',
        DatabaseHelper.colDescription: 'Năm học 2025-2026',
        DatabaseHelper.colCategory: 'Đề thi',
        DatabaseHelper.colFilePath: '/exams/exam.pdf',
        DatabaseHelper.colFileType: 'PDF',
        DatabaseHelper.colAuthor: 'Khoa CNTT',
        DatabaseHelper.colCreatedAt: now.toIso8601String(),
        DatabaseHelper.colUpdatedAt: now.toIso8601String(),
      };

      final model = DocumentModel.fromMap(map);
      expect(model.id, 5);
      expect(model.title, 'Đề thi cuối kỳ');
      expect(model.category, 'Đề thi');

      final generatedMap = model.toMap();
      expect(generatedMap[DatabaseHelper.colTitle], 'Đề thi cuối kỳ');
      expect(generatedMap[DatabaseHelper.colCategory], 'Đề thi');
      expect(generatedMap[DatabaseHelper.colId], 5);
    });
  });
}
