import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/data/dao/document_dao.dart';
import 'package:qltl/data/database/database_helper.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  late Database db;
  late DatabaseHelper dbHelper;
  late DocumentDao dao;

  setUp(() async {
    db = await databaseFactory.openDatabase(
      inMemoryDatabasePath,
      options: OpenDatabaseOptions(
        version: 1,
        onCreate: (database, version) async {
          await database.execute('''
            CREATE TABLE ${DatabaseHelper.tableDocuments} (
              ${DatabaseHelper.colId} INTEGER PRIMARY KEY AUTOINCREMENT,
              ${DatabaseHelper.colTitle} TEXT NOT NULL,
              ${DatabaseHelper.colDescription} TEXT NOT NULL DEFAULT '',
              ${DatabaseHelper.colCategory} TEXT NOT NULL,
              ${DatabaseHelper.colFilePath} TEXT NOT NULL DEFAULT '',
              ${DatabaseHelper.colFileType} TEXT NOT NULL DEFAULT 'PDF',
              ${DatabaseHelper.colAuthor} TEXT NOT NULL DEFAULT '',
              ${DatabaseHelper.colCreatedAt} TEXT NOT NULL,
              ${DatabaseHelper.colUpdatedAt} TEXT NOT NULL
            )
          ''');
        },
      ),
    );

    dbHelper = DatabaseHelper.withDatabase(db);
    dao = DocumentDao(databaseHelper: dbHelper);
  });

  tearDown(() async {
    await db.close();
  });

  group('Data Layer - DocumentDao SQLite Tests', () {
    test('Thêm tài liệu vào SQLite và đọc lại thành công', () async {
      final now = DateTime.now().toIso8601String();
      final id = await dao.insertDocument({
        DatabaseHelper.colTitle: 'Bài giảng Kiến trúc',
        DatabaseHelper.colDescription: 'Nội dung chi tiết',
        DatabaseHelper.colCategory: 'Bài giảng',
        DatabaseHelper.colFilePath: '/path/doc.pdf',
        DatabaseHelper.colFileType: 'PDF',
        DatabaseHelper.colAuthor: 'Thầy C',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: now,
      });

      expect(id, isPositive);

      final doc = await dao.getDocumentById(id);
      expect(doc, isNotNull);
      expect(doc![DatabaseHelper.colTitle], 'Bài giảng Kiến trúc');
      expect(doc[DatabaseHelper.colCategory], 'Bài giảng');
    });

    test('Cập nhật tài liệu trong SQLite thành công', () async {
      final now = DateTime.now().toIso8601String();
      final id = await dao.insertDocument({
        DatabaseHelper.colTitle: 'Tài liệu ban đầu',
        DatabaseHelper.colDescription: 'Mô tả',
        DatabaseHelper.colCategory: 'Bài tập',
        DatabaseHelper.colFilePath: '',
        DatabaseHelper.colFileType: 'DOCX',
        DatabaseHelper.colAuthor: 'Tác giả',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: now,
      });

      final rowsAffected = await dao.updateDocument(id, {
        DatabaseHelper.colTitle: 'Tài liệu đã cập nhật',
        DatabaseHelper.colDescription: 'Mô tả mới',
        DatabaseHelper.colCategory: 'Bài tập',
        DatabaseHelper.colFilePath: '/new/path.docx',
        DatabaseHelper.colFileType: 'DOCX',
        DatabaseHelper.colAuthor: 'Tác giả',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: DateTime.now().toIso8601String(),
      });

      expect(rowsAffected, 1);

      final updatedDoc = await dao.getDocumentById(id);
      expect(updatedDoc![DatabaseHelper.colTitle], 'Tài liệu đã cập nhật');
    });

    test('Xóa tài liệu khỏi SQLite thành công', () async {
      final now = DateTime.now().toIso8601String();
      final id = await dao.insertDocument({
        DatabaseHelper.colTitle: 'Tài liệu cần xóa',
        DatabaseHelper.colDescription: '',
        DatabaseHelper.colCategory: 'Đề thi',
        DatabaseHelper.colFilePath: '',
        DatabaseHelper.colFileType: 'PDF',
        DatabaseHelper.colAuthor: '',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: now,
      });

      final deletedRows = await dao.deleteDocument(id);
      expect(deletedRows, 1);

      final doc = await dao.getDocumentById(id);
      expect(doc, isNull);
    });

    test('Tìm kiếm tài liệu theo từ khóa và danh mục', () async {
      final now = DateTime.now().toIso8601String();
      await dao.insertDocument({
        DatabaseHelper.colTitle: 'Flutter Cơ bản',
        DatabaseHelper.colDescription: 'Học Widget',
        DatabaseHelper.colCategory: 'Bài giảng',
        DatabaseHelper.colFilePath: '',
        DatabaseHelper.colFileType: 'PDF',
        DatabaseHelper.colAuthor: 'Google',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: now,
      });

      await dao.insertDocument({
        DatabaseHelper.colTitle: 'Flutter Nâng cao',
        DatabaseHelper.colDescription: 'Học BLoC và Clean Architecture',
        DatabaseHelper.colCategory: 'Bài tập',
        DatabaseHelper.colFilePath: '',
        DatabaseHelper.colFileType: 'PDF',
        DatabaseHelper.colAuthor: 'Google',
        DatabaseHelper.colCreatedAt: now,
        DatabaseHelper.colUpdatedAt: now,
      });

      final results = await dao.searchDocuments('BLoC');
      expect(results.length, 1);
      expect(results.first[DatabaseHelper.colTitle], 'Flutter Nâng cao');

      final categoryResults = await dao.searchDocuments('Flutter', category: 'Bài giảng');
      expect(categoryResults.length, 1);
      expect(categoryResults.first[DatabaseHelper.colTitle], 'Flutter Cơ bản');
    });
  });
}
