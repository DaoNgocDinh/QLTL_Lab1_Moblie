import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/application/use_cases/add_document.dart';
import 'package:qltl/application/use_cases/delete_document.dart';
import 'package:qltl/application/use_cases/get_document_by_id.dart';
import 'package:qltl/application/use_cases/get_documents.dart';
import 'package:qltl/application/use_cases/search_documents.dart';
import 'package:qltl/application/use_cases/update_document.dart';
import 'package:qltl/domain/entities/document.dart';
import 'package:qltl/domain/repositories/document_repository.dart';

class FakeDocumentRepository implements DocumentRepository {
  final List<Document> _storage = [];
  int _autoId = 1;

  @override
  Future<List<Document>> getAllDocuments({String? category}) async {
    if (category != null && category.isNotEmpty && category != 'Tất cả') {
      return _storage.where((d) => d.category == category).toList();
    }
    return List.from(_storage);
  }

  @override
  Future<Document?> getDocumentById(int id) async {
    try {
      return _storage.firstWhere((d) => d.id == id);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<int> addDocument(Document document) async {
    final id = _autoId++;
    final newDoc = document.copyWith(id: id);
    _storage.add(newDoc);
    return id;
  }

  @override
  Future<bool> updateDocument(Document document) async {
    final index = _storage.indexWhere((d) => d.id == document.id);
    if (index >= 0) {
      _storage[index] = document;
      return true;
    }
    return false;
  }

  @override
  Future<int> deleteDocument(int id) async {
    final before = _storage.length;
    _storage.removeWhere((d) => d.id == id);
    return before - _storage.length;
  }

  @override
  Future<List<Document>> searchDocuments(String keyword, {String? category}) async {
    final q = keyword.toLowerCase();
    return _storage.where((d) {
      final matchesQuery = d.title.toLowerCase().contains(q) ||
          d.description.toLowerCase().contains(q) ||
          d.author.toLowerCase().contains(q);
      final matchesCat = (category == null || category.isEmpty || category == 'Tất cả') ||
          d.category == category;
      return matchesQuery && matchesCat;
    }).toList();
  }

  @override
  Stream<List<Document>> watchAllDocuments({String? category}) {
    return Stream.value(_storage);
  }
}

void main() {
  late FakeDocumentRepository repo;
  late GetDocumentsUseCase getDocs;
  late GetDocumentByIdUseCase getDocById;
  late AddDocumentUseCase addDoc;
  late UpdateDocumentUseCase updateDoc;
  late DeleteDocumentUseCase deleteDoc;
  late SearchDocumentsUseCase searchDocs;

  setUp(() {
    repo = FakeDocumentRepository();
    getDocs = GetDocumentsUseCase(repo);
    getDocById = GetDocumentByIdUseCase(repo);
    addDoc = AddDocumentUseCase(repo);
    updateDoc = UpdateDocumentUseCase(repo);
    deleteDoc = DeleteDocumentUseCase(repo);
    searchDocs = SearchDocumentsUseCase(repo);
  });

  group('Application Layer - Use Cases Tests', () {
    test('AddDocumentUseCase thêm thành công khi dữ liệu hợp lệ', () async {
      final now = DateTime.now();
      final doc = Document(
        title: 'Giáo trình KTPM',
        description: 'Mô tả tài liệu',
        category: 'Bài giảng',
        filePath: '/docs/ktpm.pdf',
        fileType: 'PDF',
        author: 'Đào Ngọc Đình',
        createdAt: now,
        updatedAt: now,
      );

      final id = await addDoc.execute(doc);
      expect(id, isPositive);

      final list = await getDocs.execute();
      expect(list.length, 1);
      expect(list.first.title, 'Giáo trình KTPM');
    });

    test('AddDocumentUseCase ném ngoại lệ khi tiêu đề rỗng', () async {
      final now = DateTime.now();
      final doc = Document(
        title: '   ',
        description: 'Mô tả',
        category: 'Bài giảng',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      );

      expect(() => addDoc.execute(doc), throwsArgumentError);
    });

    test('AddDocumentUseCase ném ngoại lệ khi danh mục rỗng', () async {
      final now = DateTime.now();
      final doc = Document(
        title: 'Tài liệu hợp lệ',
        description: 'Mô tả',
        category: '',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      );

      expect(() => addDoc.execute(doc), throwsArgumentError);
    });

    test('UpdateDocumentUseCase cập nhật thành công tài liệu', () async {
      final now = DateTime.now();
      final doc = Document(
        title: 'Bản thảo 1',
        description: '',
        category: 'Bài tập',
        filePath: '',
        fileType: 'DOCX',
        author: '',
        createdAt: now,
        updatedAt: now,
      );
      final id = await addDoc.execute(doc);

      final docToUpdate = Document(
        id: id,
        title: 'Bản thảo chính thức',
        description: 'Đã hoàn thiện',
        category: 'Bài tập',
        filePath: '',
        fileType: 'DOCX',
        author: '',
        createdAt: now,
        updatedAt: now,
      );

      final updated = await updateDoc.execute(docToUpdate);
      expect(updated, isTrue);

      final fetched = await getDocById.execute(id);
      expect(fetched?.title, 'Bản thảo chính thức');
    });

    test('DeleteDocumentUseCase xóa tài liệu thành công', () async {
      final now = DateTime.now();
      final doc = Document(
        title: 'Tài liệu tạm',
        description: '',
        category: 'Đề thi',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      );
      final id = await addDoc.execute(doc);

      final count = await deleteDoc.execute(id);
      expect(count, 1);

      final list = await getDocs.execute();
      expect(list, isEmpty);
    });

    test('SearchDocumentsUseCase tìm đúng tài liệu theo từ khóa', () async {
      final now = DateTime.now();
      await addDoc.execute(Document(
        title: 'Cơ sở dữ liệu nâng cao',
        description: 'Tối ưu SQL',
        category: 'Bài giảng',
        filePath: '',
        fileType: 'PDF',
        author: 'Nguyễn Văn A',
        createdAt: now,
        updatedAt: now,
      ));

      await addDoc.execute(Document(
        title: 'Mạng máy tính',
        description: 'Giao thức TCP/IP',
        category: 'Bài giảng',
        filePath: '',
        fileType: 'PDF',
        author: 'Trần Văn B',
        createdAt: now,
        updatedAt: now,
      ));

      final results = await searchDocs.execute('SQL');
      expect(results.length, 1);
      expect(results.first.title, 'Cơ sở dữ liệu nâng cao');
    });
  });
}
