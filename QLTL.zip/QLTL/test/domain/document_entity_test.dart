import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/domain/entities/document.dart';

void main() {
  group('Domain Layer - Document Entity Tests', () {
    test('Khởi tạo Document entity thành công với đầy đủ thuộc tính', () {
      final now = DateTime.now();
      final doc = Document(
        id: 1,
        title: 'Lập trình Di động',
        description: 'Tài liệu học Flutter',
        category: 'Bài giảng',
        filePath: '/docs/flutter.pdf',
        fileType: 'PDF',
        author: 'Giảng viên A',
        createdAt: now,
        updatedAt: now,
      );

      expect(doc.id, 1);
      expect(doc.title, 'Lập trình Di động');
      expect(doc.category, 'Bài giảng');
      expect(doc.fileType, 'PDF');
      expect(doc.author, 'Giảng viên A');
    });

    test('Phương thức copyWith cập nhật chính xác các trường', () {
      final now = DateTime.now();
      final doc = Document(
        id: 1,
        title: 'Tiêu đề cũ',
        description: 'Mô tả cũ',
        category: 'Bài giảng',
        filePath: '/docs/old.pdf',
        fileType: 'PDF',
        author: 'Tác giả cũ',
        createdAt: now,
        updatedAt: now,
      );

      final updatedDoc = doc.copyWith(
        title: 'Tiêu đề mới',
        category: 'Bài tập',
      );

      expect(updatedDoc.id, 1);
      expect(updatedDoc.title, 'Tiêu đề mới');
      expect(updatedDoc.category, 'Bài tập');
      expect(updatedDoc.description, 'Mô tả cũ'); // Giữ nguyên
    });

    test('So sánh equality (==) giữa hai Document giống nhau', () {
      final date = DateTime(2026, 1, 1);
      final doc1 = Document(
        id: 1,
        title: 'Toán rời rạc',
        description: 'Tài liệu ôn tập',
        category: 'Đề thi',
        filePath: '/docs/toan.pdf',
        fileType: 'PDF',
        author: 'Bộ môn',
        createdAt: date,
        updatedAt: date,
      );

      final doc2 = Document(
        id: 1,
        title: 'Toán rời rạc',
        description: 'Tài liệu ôn tập',
        category: 'Đề thi',
        filePath: '/docs/toan.pdf',
        fileType: 'PDF',
        author: 'Bộ môn',
        createdAt: date,
        updatedAt: date,
      );

      expect(doc1, equals(doc2));
      expect(doc1.hashCode, equals(doc2.hashCode));
    });
  });
}
