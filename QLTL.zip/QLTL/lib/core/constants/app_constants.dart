import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'Quản Lý Tài Liệu Học Tập';
  static const String appSubtitle = 'Kiến trúc Cashew (Client-Centric / Local-First)';

  // Categories
  static const String categoryAll = 'Tất cả';
  static const String categoryLecture = 'Bài giảng';
  static const String categoryExercise = 'Bài tập';
  static const String categoryReference = 'Tài liệu tham khảo';
  static const String categoryExam = 'Đề thi';

  static const List<String> categories = [
    categoryLecture,
    categoryExercise,
    categoryReference,
    categoryExam,
  ];

  static const List<String> allCategoriesWithAll = [
    categoryAll,
    categoryLecture,
    categoryExercise,
    categoryReference,
    categoryExam,
  ];

  // File Types
  static const String fileTypePdf = 'PDF';
  static const String fileTypeDocx = 'DOCX';
  static const String fileTypePptx = 'PPTX';
  static const String fileTypeVideo = 'Video';
  static const String fileTypeOther = 'Khác';

  static const List<String> fileTypes = [
    fileTypePdf,
    fileTypeDocx,
    fileTypePptx,
    fileTypeVideo,
    fileTypeOther,
  ];

  // Colors for Categories
  static Color getCategoryColor(String category) {
    switch (category) {
      case categoryLecture:
        return const Color(0xFF1976D2); // Blue
      case categoryExercise:
        return const Color(0xFF388E3C); // Green
      case categoryReference:
        return const Color(0xFFF57C00); // Orange
      case categoryExam:
        return const Color(0xFFD32F2F); // Red
      default:
        return const Color(0xFF7B1FA2); // Purple
    }
  }

  // Icons for Categories
  static IconData getCategoryIcon(String category) {
    switch (category) {
      case categoryLecture:
        return Icons.menu_book_rounded;
      case categoryExercise:
        return Icons.assignment_rounded;
      case categoryReference:
        return Icons.auto_stories_rounded;
      case categoryExam:
        return Icons.quiz_rounded;
      default:
        return Icons.description_rounded;
    }
  }

  // Icons for File Types
  static IconData getFileTypeIcon(String fileType) {
    switch (fileType.toUpperCase()) {
      case 'PDF':
        return Icons.picture_as_pdf_rounded;
      case 'DOCX':
      case 'DOC':
        return Icons.article_rounded;
      case 'PPTX':
      case 'PPT':
        return Icons.slideshow_rounded;
      case 'VIDEO':
      case 'MP4':
        return Icons.video_library_rounded;
      default:
        return Icons.insert_drive_file_rounded;
    }
  }
}
