import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/document.dart';
import '../../application/controllers/document_controller.dart';
import '../widgets/confirm_delete_dialog.dart';
import 'add_edit_document_page.dart';

class DocumentDetailPage extends StatelessWidget {
  final int documentId;

  const DocumentDetailPage({super.key, required this.documentId});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<DocumentController>();
    final document = controller.documents.cast<Document?>().firstWhere(
          (doc) => doc?.id == documentId,
          orElse: () => null,
        );

    if (document == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Chi tiết tài liệu')),
        body: const Center(
          child: Text('Tài liệu không tồn tại hoặc đã bị xóa.'),
        ),
      );
    }

    final categoryColor = AppConstants.getCategoryColor(document.category);
    final fileTypeIcon = AppConstants.getFileTypeIcon(document.fileType);
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm:ss');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết tài liệu'),
        actions: [
          IconButton(
            tooltip: 'Chỉnh sửa',
            icon: const Icon(Icons.edit_rounded),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddEditDocumentPage(document: document),
                ),
              );
            },
          ),
          IconButton(
            tooltip: 'Xóa',
            icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
            onPressed: () async {
              final confirmed = await ConfirmDeleteDialog.show(
                context,
                title: 'Xóa tài liệu',
                message: 'Bạn có chắc chắn muốn xóa "${document.title}" không?',
              );
              if (confirmed == true && context.mounted) {
                final success = await context.read<DocumentController>().deleteDocument(document.id!);
                if (context.mounted) {
                  if (success) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Đã xóa tài liệu'),
                        backgroundColor: Colors.green,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                    Navigator.of(context).pop();
                  }
                }
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Category & Type Header Banner
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    categoryColor.withValues(alpha: 0.15),
                    categoryColor.withValues(alpha: 0.05),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: categoryColor.withValues(alpha: 0.3)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: categoryColor,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(fileTypeIcon, color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          document.category,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: categoryColor,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Định dạng tệp: ${document.fileType}',
                          style: TextStyle(fontSize: 13, color: Colors.grey.shade700),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Document Title
            Text(
              document.title,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF212121),
                height: 1.3,
              ),
            ),
            const SizedBox(height: 16),

            // Metadata card (Author, Created, Updated)
            Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildMetaRow(
                      icon: Icons.person_rounded,
                      label: 'Tác giả / Nguồn',
                      value: document.author.isEmpty ? 'Chưa cập nhật' : document.author,
                    ),
                    const Divider(height: 20),
                    _buildMetaRow(
                      icon: Icons.calendar_today_rounded,
                      label: 'Ngày tạo',
                      value: dateFormat.format(document.createdAt),
                    ),
                    const Divider(height: 20),
                    _buildMetaRow(
                      icon: Icons.update_rounded,
                      label: 'Cập nhật lần cuối',
                      value: dateFormat.format(document.updatedAt),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // File path box
            if (document.filePath.isNotEmpty) ...[
              const Text(
                'Vị trí lưu trữ tệp',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.attach_file_rounded, size: 20, color: Colors.blueGrey),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        document.filePath,
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy_rounded, size: 18),
                      tooltip: 'Sao chép đường dẫn',
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: document.filePath));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Đã sao chép đường dẫn vào clipboard'),
                            duration: Duration(seconds: 2),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Description Section
            const Text(
              'Nội dung tóm tắt & Ghi chú',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Text(
                document.description.isEmpty
                    ? 'Không có mô tả chi tiết cho tài liệu này.'
                    : document.description,
                style: TextStyle(
                  fontSize: 14,
                  height: 1.5,
                  color: document.description.isEmpty ? Colors.grey : const Color(0xFF333333),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Action: Edit button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => AddEditDocumentPage(document: document),
                    ),
                  );
                },
                icon: const Icon(Icons.edit_note_rounded),
                label: const Text('Chỉnh sửa tài liệu này'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetaRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.blueGrey),
        const SizedBox(width: 10),
        Text(
          label,
          style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
        ),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
