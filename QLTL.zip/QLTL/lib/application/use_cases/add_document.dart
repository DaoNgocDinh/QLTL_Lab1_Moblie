import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class AddDocumentUseCase {
  final DocumentRepository repository;

  AddDocumentUseCase(this.repository);

  Future<int> execute(Document document) async {
    if (document.title.trim().isEmpty) {
      throw ArgumentError('Tiêu đề tài liệu không được để trống');
    }

    if (document.category.trim().isEmpty) {
      throw ArgumentError('Danh mục tài liệu không được để trống');
    }

    final sanitizedDoc = document.copyWith(
      title: document.title.trim(),
      category: document.category.trim(),
      description: document.description.trim(),
      author: document.author.trim().isEmpty ? 'Chưa cập nhật' : document.author.trim(),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    return await repository.addDocument(sanitizedDoc);
  }
}
