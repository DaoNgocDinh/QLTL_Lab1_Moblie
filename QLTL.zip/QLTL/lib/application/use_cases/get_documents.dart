import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class GetDocumentsUseCase {
  final DocumentRepository repository;

  GetDocumentsUseCase(this.repository);

  Future<List<Document>> execute({String? category}) {
    return repository.getAllDocuments(category: category);
  }

  Stream<List<Document>> watch({String? category}) {
    return repository.watchAllDocuments(category: category);
  }
}
