import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class GetDocumentByIdUseCase {
  final DocumentRepository repository;

  GetDocumentByIdUseCase(this.repository);

  Future<Document?> execute(int id) {
    if (id <= 0) {
      throw ArgumentError('ID tài liệu không hợp lệ: $id');
    }
    return repository.getDocumentById(id);
  }
}
