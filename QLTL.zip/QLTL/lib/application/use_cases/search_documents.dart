import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class SearchDocumentsUseCase {
  final DocumentRepository repository;

  SearchDocumentsUseCase(this.repository);

  Future<List<Document>> execute(String keyword, {String? category}) {
    return repository.searchDocuments(keyword, category: category);
  }
}
