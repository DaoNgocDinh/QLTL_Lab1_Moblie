import '../../domain/repositories/document_repository.dart';

class DeleteDocumentUseCase {
  final DocumentRepository repository;

  DeleteDocumentUseCase(this.repository);

  Future<int> execute(int id) async {
    if (id <= 0) {
      throw ArgumentError('ID tài liệu không hợp lệ để xóa: $id');
    }
    return await repository.deleteDocument(id);
  }
}
