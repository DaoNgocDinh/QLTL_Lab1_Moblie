import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class UpdateDocumentUseCase {
  final DocumentRepository repository;

  UpdateDocumentUseCase(this.repository);

  Future<bool> execute(Document document) async {
    if (document.id == null || document.id! <= 0) {
      throw ArgumentError('ID tài liệu không hợp lệ để cập nhật');
    }

    if (document.title.trim().isEmpty) {
      throw ArgumentError('Tiêu đề tài liệu không được để trống');
    }

    if (document.category.trim().isEmpty) {
      throw ArgumentError('Danh mục tài liệu không được để trống');
    }

    final sanitizedDoc = document.copyWith(
      title: document.title.trim(),
      category: document.category.trim(),
      description: document.description.trim(),
      author: document.author.trim().isEmpty ? 'Chưa cập nhật' : document.author.trim(),
      updatedAt: DateTime.now(),
    );

    return await repository.updateDocument(sanitizedDoc);
  }
}
