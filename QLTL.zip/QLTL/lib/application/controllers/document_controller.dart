import 'package:flutter/foundation.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/document.dart';
import '../use_cases/add_document.dart';
import '../use_cases/delete_document.dart';
import '../use_cases/get_document_by_id.dart';
import '../use_cases/get_documents.dart';
import '../use_cases/search_documents.dart';
import '../use_cases/update_document.dart';

class DocumentController extends ChangeNotifier {
  final GetDocumentsUseCase getDocumentsUseCase;
  final GetDocumentByIdUseCase getDocumentByIdUseCase;
  final AddDocumentUseCase addDocumentUseCase;
  final UpdateDocumentUseCase updateDocumentUseCase;
  final DeleteDocumentUseCase deleteDocumentUseCase;
  final SearchDocumentsUseCase searchDocumentsUseCase;

  List<Document> _documents = [];
  bool _isLoading = false;
  String? _errorMessage;
  String _selectedCategory = AppConstants.categoryAll;
  String _searchQuery = '';

  DocumentController({
    required this.getDocumentsUseCase,
    required this.getDocumentByIdUseCase,
    required this.addDocumentUseCase,
    required this.updateDocumentUseCase,
    required this.deleteDocumentUseCase,
    required this.searchDocumentsUseCase,
  });

  // Getters
  List<Document> get documents => _documents;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;

  // Category counts
  int get totalCount => _documents.length;

  int countByCategory(String category) {
    if (category == AppConstants.categoryAll) {
      return _documents.length;
    }
    return _documents.where((d) => d.category == category).length;
  }

  // Load documents
  Future<void> loadDocuments() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (_searchQuery.trim().isNotEmpty) {
        _documents = await searchDocumentsUseCase.execute(
          _searchQuery,
          category: _selectedCategory == AppConstants.categoryAll ? null : _selectedCategory,
        );
      } else {
        _documents = await getDocumentsUseCase.execute(
          category: _selectedCategory == AppConstants.categoryAll ? null : _selectedCategory,
        );
      }
    } catch (e) {
      _errorMessage = 'Không thể tải danh sách tài liệu: ${e.toString()}';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Select category filter
  void selectCategory(String category) {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    loadDocuments();
  }

  // Search
  void onSearchChanged(String query) {
    _searchQuery = query;
    loadDocuments();
  }

  void clearSearch() {
    if (_searchQuery.isEmpty) return;
    _searchQuery = '';
    loadDocuments();
  }

  // Add document
  Future<bool> addDocument(Document document) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await addDocumentUseCase.execute(document);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '').replaceAll('ArgumentError: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Update document
  Future<bool> updateDocument(Document document) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await updateDocumentUseCase.execute(document);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '').replaceAll('ArgumentError: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Delete document
  Future<bool> deleteDocument(int id) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await deleteDocumentUseCase.execute(id);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = 'Lỗi khi xóa tài liệu: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Get by ID
  Future<Document?> getDocumentById(int id) async {
    try {
      return await getDocumentByIdUseCase.execute(id);
    } catch (e) {
      _errorMessage = 'Lỗi khi lấy tài liệu: ${e.toString()}';
      return null;
    }
  }
}
