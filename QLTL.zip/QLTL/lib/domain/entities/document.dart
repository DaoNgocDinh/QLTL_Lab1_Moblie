class Document {
  final int? id;
  final String title;
  final String description;
  final String category;
  final String filePath;
  final String fileType;
  final String author;
  final DateTime createdAt;
  final DateTime updatedAt;

  const Document({
    this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.filePath,
    required this.fileType,
    required this.author,
    required this.createdAt,
    required this.updatedAt,
  });

  Document copyWith({
    int? id,
    String? title,
    String? description,
    String? category,
    String? filePath,
    String? fileType,
    String? author,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Document(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      filePath: filePath ?? this.filePath,
      fileType: fileType ?? this.fileType,
      author: author ?? this.author,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Document &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          title == other.title &&
          description == other.description &&
          category == other.category &&
          filePath == other.filePath &&
          fileType == other.fileType &&
          author == other.author;

  @override
  int get hashCode =>
      id.hashCode ^
      title.hashCode ^
      description.hashCode ^
      category.hashCode ^
      filePath.hashCode ^
      fileType.hashCode ^
      author.hashCode;
}
