import '../entities/document.dart';

abstract class DocumentRepository {
  Future<List<Document>> getAllDocuments({String? category});

  Future<Document?> getDocumentById(int id);

  Future<int> addDocument(Document document);

  Future<bool> updateDocument(Document document);

  Future<int> deleteDocument(int id);

  Future<List<Document>> searchDocuments(String keyword, {String? category});

  Stream<List<Document>> watchAllDocuments({String? category});
}
