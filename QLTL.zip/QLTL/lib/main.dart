import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'application/controllers/document_controller.dart';
import 'application/use_cases/add_document.dart';
import 'application/use_cases/delete_document.dart';
import 'application/use_cases/get_document_by_id.dart';
import 'application/use_cases/get_documents.dart';
import 'application/use_cases/search_documents.dart';
import 'application/use_cases/update_document.dart';
import 'core/theme/app_theme.dart';
import 'data/dao/document_dao.dart';
import 'data/database/database_helper.dart';
import 'data/repositories/document_repository_impl.dart';
import 'domain/repositories/document_repository.dart';
import 'presentation/pages/document_list_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize FFI for Windows/Desktop if running on Desktop platform
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  // 1. Data Layer: Database & DAO
  final databaseHelper = DatabaseHelper();
  final documentDao = DocumentDao(databaseHelper: databaseHelper);

  // 2. Data Layer -> Domain Layer: Repository Implementation
  final DocumentRepository documentRepository = DocumentRepositoryImpl(documentDao);

  // 3. Application Layer: Use Cases
  final getDocumentsUseCase = GetDocumentsUseCase(documentRepository);
  final getDocumentByIdUseCase = GetDocumentByIdUseCase(documentRepository);
  final addDocumentUseCase = AddDocumentUseCase(documentRepository);
  final updateDocumentUseCase = UpdateDocumentUseCase(documentRepository);
  final deleteDocumentUseCase = DeleteDocumentUseCase(documentRepository);
  final searchDocumentsUseCase = SearchDocumentsUseCase(documentRepository);

  // 4. Application Layer: Controller (State Management)
  final documentController = DocumentController(
    getDocumentsUseCase: getDocumentsUseCase,
    getDocumentByIdUseCase: getDocumentByIdUseCase,
    addDocumentUseCase: addDocumentUseCase,
    updateDocumentUseCase: updateDocumentUseCase,
    deleteDocumentUseCase: deleteDocumentUseCase,
    searchDocumentsUseCase: searchDocumentsUseCase,
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<DocumentController>.value(value: documentController),
      ],
      child: const QLTLApp(),
    ),
  );
}

class QLTLApp extends StatelessWidget {
  const QLTLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quản Lý Tài Liệu Học Tập - Cashew',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const DocumentListPage(),
    );
  }
}
