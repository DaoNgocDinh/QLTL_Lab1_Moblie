import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class DatabaseHelper {
  static const String databaseName = 'qltl_study_documents.db';
  static const int databaseVersion = 1;

  static const String tableDocuments = 'study_documents';
  static const String colId = 'id';
  static const String colTitle = 'title';
  static const String colDescription = 'description';
  static const String colCategory = 'category';
  static const String colFilePath = 'file_path';
  static const String colFileType = 'file_type';
  static const String colAuthor = 'author';
  static const String colCreatedAt = 'created_at';
  static const String colUpdatedAt = 'updated_at';

  static Database? _database;
  static DatabaseHelper? _instance;

  DatabaseHelper._internal();

  factory DatabaseHelper() {
    _instance ??= DatabaseHelper._internal();
    return _instance!;
  }

  // Allow passing an external or in-memory Database for testing
  DatabaseHelper.withDatabase(Database db) {
    _database = db;
  }

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    // If running on desktop platforms (Windows, Linux, macOS), use sqflite_ffi
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
      final appDocDir = await getApplicationDocumentsDirectory();
      final path = join(appDocDir.path, 'QLTL', databaseName);
      // Ensure directory exists
      final dir = Directory(dirname(path));
      if (!await dir.exists()) {
        await dir.create(recursive: true);
      }
      return await databaseFactory.openDatabase(
        path,
        options: OpenDatabaseOptions(
          version: databaseVersion,
          onCreate: _onCreate,
          onUpgrade: _onUpgrade,
        ),
      );
    } else {
      // Mobile platforms (Android, iOS)
      final databasesPath = await getDatabasesPath();
      final path = join(databasesPath, databaseName);
      return await openDatabase(
        path,
        version: databaseVersion,
        onCreate: _onCreate,
        onUpgrade: _onUpgrade,
      );
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableDocuments (
        $colId INTEGER PRIMARY KEY AUTOINCREMENT,
        $colTitle TEXT NOT NULL,
        $colDescription TEXT NOT NULL DEFAULT '',
        $colCategory TEXT NOT NULL,
        $colFilePath TEXT NOT NULL DEFAULT '',
        $colFileType TEXT NOT NULL DEFAULT 'PDF',
        $colAuthor TEXT NOT NULL DEFAULT '',
        $colCreatedAt TEXT NOT NULL,
        $colUpdatedAt TEXT NOT NULL
      )
    ''');

    // Seed initial study documents for student
    await _seedInitialData(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Migration strategy matching Cashew
    if (oldVersion < 2) {
      // Future migrations go here
    }
  }

  Future<void> _seedInitialData(Database db) async {
    final now = DateTime.now();
    final sampleDocs = [
      {
        colTitle: 'Bài giảng Kiến trúc Phần mềm - Chương 1: Tổng quan',
        colDescription: 'Khái niệm kiến trúc, các phong cách kiến trúc phần mềm, Client-Server, MVC, Clean Architecture.',
        colCategory: 'Bài giảng',
        colFilePath: '/documents/lectures/kientruc_phanmem_chuong1.pdf',
        colFileType: 'PDF',
        colAuthor: 'TS. Nguyễn Văn A',
        colCreatedAt: now.subtract(const Duration(days: 5)).toIso8601String(),
        colUpdatedAt: now.subtract(const Duration(days: 5)).toIso8601String(),
      },
      {
        colTitle: 'Bài tập Thực hành 1: Xây dựng ứng dụng theo kiến trúc Cashew',
        colDescription: 'Thiết kế ứng dụng Quản lý tài liệu học tập theo kiến trúc Local-First của Cashew.',
        colCategory: 'Bài tập',
        colFilePath: '/documents/exercises/th1_cashew_architecture.docx',
        colFileType: 'DOCX',
        colAuthor: 'ThS. Trần Thị B',
        colCreatedAt: now.subtract(const Duration(days: 3)).toIso8601String(),
        colUpdatedAt: now.subtract(const Duration(days: 2)).toIso8601String(),
      },
      {
        colTitle: 'Tài liệu hướng dẫn Flutter & Clean Architecture',
        colDescription: 'Sách tham khảo Clean Architecture trên nền tảng Flutter, phân tách lớp Domain, Data, Presentation.',
        colCategory: 'Tài liệu tham khảo',
        colFilePath: '/documents/references/flutter_clean_architecture_guide.pdf',
        colFileType: 'PDF',
        colAuthor: 'Google Developer Group',
        colCreatedAt: now.subtract(const Duration(days: 10)).toIso8601String(),
        colUpdatedAt: now.subtract(const Duration(days: 10)).toIso8601String(),
      },
      {
        colTitle: 'Đề thi trắc nghiệm & tự luận Lập trình Thiết bị Di động 2025',
        colDescription: 'Ngân hàng câu hỏi trắc nghiệm kiến trúc mobile, luồng dữ liệu và lưu trữ SQLite cục bộ.',
        colCategory: 'Đề thi',
        colFilePath: '/documents/exams/dethi_mobile_2025.pdf',
        colFileType: 'PDF',
        colAuthor: 'Bộ môn KTPM',
        colCreatedAt: now.subtract(const Duration(days: 1)).toIso8601String(),
        colUpdatedAt: now.subtract(const Duration(days: 1)).toIso8601String(),
      },
      {
        colTitle: 'Slide thuyết trình: Phân tích mã nguồn Cashew App',
        colDescription: 'Báo cáo chi tiết các module, Drift ORM, Provider state management và cơ chế Local-First.',
        colCategory: 'Bài giảng',
        colFilePath: '/documents/lectures/cashew_analysis_presentation.pptx',
        colFileType: 'PPTX',
        colAuthor: 'Đào Ngọc Đình',
        colCreatedAt: now.subtract(const Duration(hours: 12)).toIso8601String(),
        colUpdatedAt: now.subtract(const Duration(hours: 12)).toIso8601String(),
      },
    ];

    for (var doc in sampleDocs) {
      await db.insert(tableDocuments, doc);
    }
  }

  Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
