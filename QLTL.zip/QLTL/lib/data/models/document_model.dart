import '../../domain/entities/document.dart';
import '../database/database_helper.dart';

class DocumentModel {
  final int? id;
  final String title;
  final String description;
  final String category;
  final String filePath;
  final String fileType;
  final String author;
  final DateTime createdAt;
  final DateTime updatedAt;

  const DocumentModel({
    this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.filePath,
    required this.fileType,
    required this.author,
    required this.createdAt,
    required this.updatedAt,
  });

  factory DocumentModel.fromEntity(Document document) {
    return DocumentModel(
      id: document.id,
      title: document.title,
      description: document.description,
      category: document.category,
      filePath: document.filePath,
      fileType: document.fileType,
      author: document.author,
      createdAt: document.createdAt,
      updatedAt: document.updatedAt,
    );
  }

  Document toEntity() {
    return Document(
      id: id,
      title: title,
      description: description,
      category: category,
      filePath: filePath,
      fileType: fileType,
      author: author,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  factory DocumentModel.fromMap(Map<String, dynamic> map) {
    return DocumentModel(
      id: map[DatabaseHelper.colId] as int?,
      title: map[DatabaseHelper.colTitle] as String,
      description: (map[DatabaseHelper.colDescription] ?? '') as String,
      category: map[DatabaseHelper.colCategory] as String,
      filePath: (map[DatabaseHelper.colFilePath] ?? '') as String,
      fileType: (map[DatabaseHelper.colFileType] ?? 'PDF') as String,
      author: (map[DatabaseHelper.colAuthor] ?? '') as String,
      createdAt: DateTime.parse(map[DatabaseHelper.colCreatedAt] as String),
      updatedAt: DateTime.parse(map[DatabaseHelper.colUpdatedAt] as String),
    );
  }

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      DatabaseHelper.colTitle: title,
      DatabaseHelper.colDescription: description,
      DatabaseHelper.colCategory: category,
      DatabaseHelper.colFilePath: filePath,
      DatabaseHelper.colFileType: fileType,
      DatabaseHelper.colAuthor: author,
      DatabaseHelper.colCreatedAt: createdAt.toIso8601String(),
      DatabaseHelper.colUpdatedAt: updatedAt.toIso8601String(),
    };
    if (id != null) {
      map[DatabaseHelper.colId] = id;
    }
    return map;
  }
}
