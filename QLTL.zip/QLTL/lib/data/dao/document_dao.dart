import 'package:sqflite/sqflite.dart';
import '../database/database_helper.dart';

class DocumentDao {
  final DatabaseHelper databaseHelper;

  DocumentDao({DatabaseHelper? databaseHelper})
      : databaseHelper = databaseHelper ?? DatabaseHelper();

  Future<Database> get _db => databaseHelper.database;

  Future<List<Map<String, dynamic>>> getAllDocuments({String? category}) async {
    final db = await _db;
    if (category != null && category.isNotEmpty && category != 'Tất cả') {
      return await db.query(
        DatabaseHelper.tableDocuments,
        where: '${DatabaseHelper.colCategory} = ?',
        whereArgs: [category],
        orderBy: '${DatabaseHelper.colUpdatedAt} DESC',
      );
    }
    return await db.query(
      DatabaseHelper.tableDocuments,
      orderBy: '${DatabaseHelper.colUpdatedAt} DESC',
    );
  }

  Future<Map<String, dynamic>?> getDocumentById(int id) async {
    final db = await _db;
    final results = await db.query(
      DatabaseHelper.tableDocuments,
      where: '${DatabaseHelper.colId} = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  Future<int> insertDocument(Map<String, dynamic> data) async {
    final db = await _db;
    return await db.insert(
      DatabaseHelper.tableDocuments,
      data,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> updateDocument(int id, Map<String, dynamic> data) async {
    final db = await _db;
    return await db.update(
      DatabaseHelper.tableDocuments,
      data,
      where: '${DatabaseHelper.colId} = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteDocument(int id) async {
    final db = await _db;
    return await db.delete(
      DatabaseHelper.tableDocuments,
      where: '${DatabaseHelper.colId} = ?',
      whereArgs: [id],
    );
  }

  Future<List<Map<String, dynamic>>> searchDocuments(
    String keyword, {
    String? category,
  }) async {
    final db = await _db;
    final query = keyword.trim();
    if (query.isEmpty) {
      return getAllDocuments(category: category);
    }

    final searchPattern = '%$query%';
    if (category != null && category.isNotEmpty && category != 'Tất cả') {
      return await db.query(
        DatabaseHelper.tableDocuments,
        where: '(${DatabaseHelper.colTitle} LIKE ? OR ${DatabaseHelper.colDescription} LIKE ? OR ${DatabaseHelper.colAuthor} LIKE ?) AND ${DatabaseHelper.colCategory} = ?',
        whereArgs: [searchPattern, searchPattern, searchPattern, category],
        orderBy: '${DatabaseHelper.colUpdatedAt} DESC',
      );
    }

    return await db.query(
      DatabaseHelper.tableDocuments,
      where: '${DatabaseHelper.colTitle} LIKE ? OR ${DatabaseHelper.colDescription} LIKE ? OR ${DatabaseHelper.colAuthor} LIKE ? OR ${DatabaseHelper.colCategory} LIKE ?',
      whereArgs: [searchPattern, searchPattern, searchPattern, searchPattern],
      orderBy: '${DatabaseHelper.colUpdatedAt} DESC',
    );
  }

  Future<Map<String, int>> countByCategory() async {
    final db = await _db;
    final result = await db.rawQuery('''
      SELECT ${DatabaseHelper.colCategory}, COUNT(*) as total
      FROM ${DatabaseHelper.tableDocuments}
      GROUP BY ${DatabaseHelper.colCategory}
    ''');
    final Map<String, int> counts = {};
    for (var row in result) {
      final category = row[DatabaseHelper.colCategory] as String;
      final total = Sqflite.firstIntValue([{'count': row['total']}]) ?? 0;
      counts[category] = total;
    }
    return counts;
  }
}
