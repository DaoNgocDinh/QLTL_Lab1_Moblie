package com.daongocdinh.qltl

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
