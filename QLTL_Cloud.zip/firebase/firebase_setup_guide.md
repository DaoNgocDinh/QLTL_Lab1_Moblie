# HƯỚNG DẪN THIẾT LẬP FIREBASE VÀ SUPABASE CHO DỰ ÁN QLTL

Tài liệu này hướng dẫn chi tiết quy trình cấu hình hệ sinh thái Cloud kết hợp giữa **Firebase** (Google Authentication + Firebase Storage) và **Supabase** (PostgreSQL Database + Row Level Security - RLS).

---

## 1. THIẾT LẬP DỰ ÁN FIREBASE

### 1.1. Tạo dự án trên Firebase Console
1. Truy cập [Firebase Console](https://console.firebase.google.com/) và bấm **Add project** (Đặt tên dự án: `qltl-cloud-doc`).
2. Bỏ chọn Google Analytics (tùy chọn) và bấm **Create project**.

### 1.2. Thêm ứng dụng Android & iOS/Web
- **Android:**
  - Package name: `com.example.qltl` (kiểm tra trong `android/app/build.gradle.kts` hoặc `AndroidManifest.xml`).
  - Lấy mã SHA-1 của máy phát triển bằng lệnh:
    ```bash
    cd android
    ./gradlew signingReport
    ```
  - Dán SHA-1 vào Firebase Console (bắt buộc để Google Sign-In hoạt động trên Android).
  - Tải tệp `google-services.json` và đặt vào thư mục `android/app/google-services.json`.

### 1.3. Kích hoạt Firebase Authentication
1. Tại menu bên trái, vào **Build** -> **Authentication** -> Bấm **Get Started**.
2. Chọn tab **Sign-in method**, kích hoạt nhà cung cấp **Google**.
3. Điền email hỗ trợ dự án và bấm **Save**.

### 1.4. Kích hoạt Firebase Storage
1. Tại menu bên trái, vào **Build** -> **Storage** -> Bấm **Get Started**.
2. Chọn vị trí lưu trữ (khuyến nghị: `asia-southeast1` hoặc `asia-southeast2` để có độ trễ thấp tại Việt Nam).
3. Tại tab **Rules**, sao chép nội dung từ tệp `firebase/storage.rules` vào và bấm **Publish**.

---

## 2. THIẾT LẬP DỰ ÁN SUPABASE

### 2.1. Tạo dự án trên Supabase Dashboard
1. Truy cập [Supabase Dashboard](https://supabase.com/dashboard) và bấm **New Project**.
2. Nhập tên dự án (vd: `qltl-document-management`), tạo Database Password an toàn, chọn khu vực `Southeast Asia (Singapore)`.

### 2.2. Khởi tạo Cơ sở dữ liệu và Chính sách bảo mật (RLS)
1. Tại menu bên trái, vào **SQL Editor**.
2. Mở tệp `supabase/supabase_schema.sql` trong dự án Flutter, sao chép toàn bộ nội dung và dán vào SQL Editor.
3. Bấm **Run** để khởi tạo:
   - 3 bảng: `users`, `documents`, `document_permissions`.
   - Các index tăng tốc tìm kiếm.
   - Hàm `current_app_user_id()`.
   - Các chính sách bảo mật hàng (RLS Policies).
   - Dữ liệu mẫu ban đầu (3 tài khoản kiểm thử: Alice, Bob, Charlie).

### 2.3. Lấy thông tin kết nối Supabase
1. Vào **Project Settings** -> **API**.
2. Sao chép **Project URL** và **anon public key**.
3. Điền vào tệp cấu hình `lib/core/config/app_config.dart`.

---

## 3. CHẾ ĐỘ HOẠT ĐỘNG LINH HOẠT TRONG ỨNG DỤNG (HYBRID ARCHITECTURE)

Ứng dụng hỗ trợ 2 chế độ thông qua cờ cấu hình `AppConfig.backendMode`:
1. **Chế độ Demo / Test nội bộ (`CloudBackendMode.mockCloud`):**
   - Không cần nạp API Key thật vẫn có thể chạy 100% đầy đủ tính năng:
     - Đăng nhập 1-chạm giữa 3 tài khoản Alice, Bob, Charlie.
     - Mô phỏng chính xác 100% logic phân quyền Row Level Security (RLS) của Supabase.
     - Kiểm thử tải file, tìm kiếm, cấp quyền, thu hồi quyền.
     - Toàn bộ các bộ test tự động (`flutter test`) chạy độc lập, xanh tuyệt đối.
2. **Chế độ Live Cloud (`CloudBackendMode.liveCloud`):**
   - Kết nối trực tiếp tới Firebase Auth thật, Firebase Storage thật và Supabase PostgreSQL thật.
