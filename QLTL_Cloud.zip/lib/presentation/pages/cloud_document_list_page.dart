import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../application/controllers/auth_controller.dart';
import '../../application/controllers/cloud_document_controller.dart';
import '../../core/config/app_config.dart';
import '../../data/repositories/supabase_document_repository.dart';
import '../../domain/repositories/cloud_document_repository.dart';
import '../widgets/account_switcher_bar.dart';
import '../widgets/cloud_document_card.dart';
import '../widgets/share_document_dialog.dart';
import 'cloud_add_edit_document_page.dart';
import 'cloud_document_detail_page.dart';
import 'login_page.dart';

class CloudDocumentListPage extends StatefulWidget {
  const CloudDocumentListPage({super.key});

  @override
  State<CloudDocumentListPage> createState() => _CloudDocumentListPageState();
}

class _CloudDocumentListPageState extends State<CloudDocumentListPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(_handleTabChange);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = context.read<AuthController>();
      final docCtrl = context.read<CloudDocumentController>();
      if (auth.currentUser != null) {
        docCtrl.loadDocuments(auth.currentUser!.id);
      }
    });
  }

  void _handleTabChange() {
    if (_tabController.indexIsChanging) return;
    final auth = context.read<AuthController>();
    final docCtrl = context.read<CloudDocumentController>();
    if (auth.currentUser == null) return;

    DocumentTabFilter filter;
    switch (_tabController.index) {
      case 1:
        filter = DocumentTabFilter.mine;
        break;
      case 2:
        filter = DocumentTabFilter.shared;
        break;
      default:
        filter = DocumentTabFilter.all;
    }
    docCtrl.setTab(filter, auth.currentUser!.id);
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authController = context.watch<AuthController>();
    final documentController = context.watch<CloudDocumentController>();
    final currentUser = authController.currentUser;
    final theme = Theme.of(context);

    if (currentUser == null) {
      return const LoginPage();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Quản lý Tài liệu Học tập',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
            Text(
              'Hệ thống Cloud (Firebase & Supabase RLS)',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.normal),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.cloud_sync_rounded),
            tooltip: 'Liên kết Cloud (Firebase + Supabase)',
            onPressed: () => _showCloudConfigDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Làm mới dữ liệu',
            onPressed: () {
              documentController.loadDocuments(currentUser.id);
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Đăng xuất',
            onPressed: () async {
              await authController.signOut();
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Tất cả'),
            Tab(text: 'Của tôi (Owner)'),
            Tab(text: 'Được chia sẻ'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Thanh chuyển đổi tài khoản 1-chạm (Alice / Bob / Charlie)
          const AccountSwitcherBar(),

          // Thanh tìm kiếm
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Tìm kiếm theo tên tài liệu, danh mục...',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded),
                        onPressed: () {
                          _searchController.clear();
                          documentController.setSearchQuery('', currentUser.id);
                        },
                      )
                    : null,
                filled: true,
                fillColor: theme.colorScheme.surfaceContainerHighest.withOpacity(0.4),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              ),
              onChanged: (val) {
                documentController.setSearchQuery(val, currentUser.id);
              },
            ),
          ),

          // Bộ lọc danh mục (Category Filter Chips)
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: AppConfig.categories.map((cat) {
                final isSelected = documentController.selectedCategory == cat;
                final count = documentController.categoryCounts[cat] ?? 0;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text('$cat ($count)'),
                    selected: isSelected,
                    onSelected: (val) {
                      documentController.selectCategory(cat, currentUser.id);
                    },
                    selectedColor: theme.colorScheme.primaryContainer,
                    checkmarkColor: theme.colorScheme.primary,
                  ),
                );
              }).toList(),
            ),
          ),
          // Hiển thị thông báo lỗi nếu tải tài liệu thất bại
          if (documentController.errorMessage != null)
            Container(
              margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade300),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      documentController.errorMessage!,
                      style: TextStyle(color: Colors.red.shade900, fontSize: 12),
                    ),
                  ),
                  TextButton(
                    onPressed: () => documentController.loadDocuments(currentUser.id),
                    child: const Text('Thử lại', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ),

          // Danh sách tài liệu
          Expanded(
            child: documentController.isLoading
                ? const Center(child: CircularProgressIndicator())
                : documentController.documents.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.folder_off_outlined,
                                size: 64,
                                color: theme.colorScheme.outline,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Không có tài liệu nào',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: theme.colorScheme.onSurface,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                currentUser.id == 'user_charlie_003'
                                    ? 'Tài khoản Charlie chưa tạo tài liệu nào và chưa được ai chia sẻ (RLS đang bảo vệ dữ liệu tuyệt đối).'
                                    : 'Bạn chưa có tài liệu nào trong danh mục hoặc bộ lọc này.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 13,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                              if (currentUser.id == 'user_charlie_003') ...[
                                const SizedBox(height: 16),
                                OutlinedButton.icon(
                                  onPressed: () {
                                    authController.switchUser('user_alice_001');
                                    documentController
                                        .loadDocuments('user_alice_001');
                                  },
                                  icon: const Icon(Icons.switch_account_rounded),
                                  label: const Text('Chuyển sang Alice để chia sẻ'),
                                ),
                              ],
                            ],
                          ),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: () =>
                            documentController.loadDocuments(currentUser.id),
                        child: ListView.builder(
                          itemCount: documentController.documents.length,
                          itemBuilder: (context, index) {
                            final doc = documentController.documents[index];
                            return CloudDocumentCard(
                              document: doc,
                              currentUserId: currentUser.id,
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        CloudDocumentDetailPage(documentId: doc.id),
                                  ),
                                );
                              },
                              onEdit: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        CloudAddEditDocumentPage(document: doc),
                                  ),
                                );
                              },
                              onShare: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => ShareDocumentDialog(
                                    document: doc,
                                    requestingUserId: currentUser.id,
                                  ),
                                );
                              },
                              onDelete: () async {
                                final confirm = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text('Xác nhận xóa tài liệu'),
                                    content: Text(
                                      'Bạn có chắc chắn muốn xóa "${doc.title}"?',
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(ctx, false),
                                        child: const Text('Hủy'),
                                      ),
                                      FilledButton(
                                        style: FilledButton.styleFrom(
                                          backgroundColor: Colors.red,
                                        ),
                                        onPressed: () => Navigator.pop(ctx, true),
                                        child: const Text('Xóa'),
                                      ),
                                    ],
                                  ),
                                );

                                if (confirm == true && context.mounted) {
                                  await documentController.deleteDocument(
                                    doc.id,
                                    currentUser.id,
                                  );
                                }
                              },
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const CloudAddEditDocumentPage(),
            ),
          );
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('Thêm tài liệu'),
      ),
    );
  }

  void _showCloudConfigDialog(BuildContext context) {
    final urlController = TextEditingController(text: AppConfig.supabaseUrl);
    final keyController = TextEditingController(text: AppConfig.supabaseAnonKey);
    bool isLive = AppConfig.backendMode == CloudBackendMode.liveCloud;
    String? statusMessage;
    bool isTesting = false;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Row(
                children: [
                  Icon(Icons.cloud_sync_rounded, color: Colors.blue),
                  SizedBox(width: 8),
                  Text('Liên kết Cloud (Firebase + Supabase)', style: TextStyle(fontSize: 16)),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Thông tin Firebase
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.amber.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.amber.shade300),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('🔥 Firebase Ecosystem:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                          SizedBox(height: 4),
                          Text('• Auth: Project qltl-cloud-doc (Google/Email)', style: TextStyle(fontSize: 11)),
                          Text('• Storage: documents/{userId}/{filename}', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),

                    // Thông tin Supabase
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.teal.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.teal.shade300),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('⚡ Supabase Relational Database:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: isLive ? Colors.green.shade100 : Colors.blue.shade100,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  isLive ? 'Live Cloud' : 'Mock Cloud',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    color: isLive ? Colors.green.shade900 : Colors.blue.shade900,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          const Text('• Bảng dữ liệu: users, documents, document_permissions', style: TextStyle(fontSize: 11)),
                          const Text('• Bảo mật: Row Level Security (RLS)', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    const Text('Supabase Project URL:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                    const SizedBox(height: 4),
                    TextField(
                      controller: urlController,
                      style: const TextStyle(fontSize: 12),
                      decoration: const InputDecoration(
                        hintText: 'https://xyzcompany.supabase.co',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 10),

                    const Text('Supabase Anon Public Key:', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                    const SizedBox(height: 4),
                    TextField(
                      controller: keyController,
                      style: const TextStyle(fontSize: 12),
                      decoration: const InputDecoration(
                        hintText: 'eyJhbGciOi...',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),

                    if (statusMessage != null)
                      Container(
                        padding: const EdgeInsets.all(8),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Text(
                          statusMessage!,
                          style: const TextStyle(fontSize: 11.5, height: 1.3),
                        ),
                      ),

                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: isTesting
                                ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Icon(Icons.network_check_rounded, size: 16),
                            label: const Text('Kiểm tra kết nối', style: TextStyle(fontSize: 12)),
                            onPressed: isTesting
                                ? null
                                : () async {
                                    setState(() {
                                      isTesting = true;
                                      statusMessage = 'Đang kiểm tra kết nối tới Supabase...';
                                    });
                                    final res = await SupabaseDocumentRepository.testConnection(
                                      urlController.text,
                                      keyController.text,
                                    );
                                    setState(() {
                                      isTesting = false;
                                      statusMessage = res['message'] as String;
                                    });
                                  },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: isLive ? Colors.teal : Colors.blueGrey,
                            ),
                            onPressed: () async {
                              final newMode = isLive ? CloudBackendMode.mockCloud : CloudBackendMode.liveCloud;
                              await AppConfig.updateSupabaseConfig(
                                url: urlController.text,
                                anonKey: keyController.text,
                                mode: newMode,
                              );
                              setState(() {
                                isLive = newMode == CloudBackendMode.liveCloud;
                                statusMessage = isLive
                                    ? '✅ Đã chuyển sang chế độ Live Cloud (Supabase PostgreSQL)!'
                                    : 'ℹ️ Đã chuyển về chế độ Mock Cloud (Mô phỏng an toàn)!';
                              });
                              if (context.mounted) {
                                final auth = context.read<AuthController>();
                                final docCtrl = context.read<CloudDocumentController>();
                                if (auth.currentUser != null) {
                                  docCtrl.loadDocuments(auth.currentUser!.id);
                                }
                              }
                            },
                            child: Text(
                              isLive ? 'Dùng Mock Cloud' : 'Bật Live Cloud',
                              style: const TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    Center(
                      child: TextButton.icon(
                        icon: const Icon(Icons.code_rounded, size: 16),
                        label: const Text('Xem hướng dẫn tạo bảng SQL trên Supabase', style: TextStyle(fontSize: 11.5)),
                        onPressed: () => _showSqlHelpDialog(context),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                FilledButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Đóng'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showSqlHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.terminal_rounded, color: Colors.teal),
            SizedBox(width: 8),
            Text('Tập lệnh SQL Supabase & RLS'),
          ],
        ),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Để liên kết Supabase với Firebase Storage và phân quyền RLS:\n\n'
                '1. Mở Supabase Dashboard -> chọn Project của bạn.\n'
                '2. Click vào mục "SQL Editor" ở menu bên trái.\n'
                '3. Mở file "supabase/supabase_schema.sql" trong thư mục dự án này, copy toàn bộ nội dung.\n'
                '4. Dán vào ô soạn thảo SQL trên Supabase và bấm "Run".\n\n'
                'Toàn bộ 3 bảng (users, documents, document_permissions) cùng các chính sách bảo mật RLS sẽ được khởi tạo tự động!',
                style: TextStyle(fontSize: 12.5, height: 1.4),
              ),
            ],
          ),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Đã hiểu'),
          ),
        ],
      ),
    );
  }
}
