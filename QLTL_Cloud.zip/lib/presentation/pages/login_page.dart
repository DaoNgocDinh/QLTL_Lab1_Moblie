import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../application/controllers/auth_controller.dart';
import '../../core/config/app_config.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final authController = context.watch<AuthController>();
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Logo / App Icon
                  Container(
                    width: 72,
                    height: 72,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1976D2), Color(0xFF00B0FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.blue.withOpacity(0.3),
                          blurRadius: 16,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.cloud_sync_rounded,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),

                  // Header Texts
                  const Text(
                    'QUẢN LÝ TÀI LIỆU CLOUD',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Flutter • Firebase Auth • Supabase RLS',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Thẻ kiểm tra trạng thái liên kết Firebase thực tế
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.green.shade300),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.check_circle_rounded, color: Colors.green, size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Firebase Auth: Đã kích hoạt (qltl-cloud-doc)',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                  color: Colors.green,
                                ),
                              ),
                              Text(
                                'Đã có tài khoản thực tế trên Firebase Console',
                                style: TextStyle(
                                  fontSize: 10.5,
                                  color: Colors.green.shade800,
                                ),
                              ),
                            ],
                          ),
                        ),
                        TextButton(
                          onPressed: () => _showFirebaseDiagnostics(context),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            visualDensity: VisualDensity.compact,
                          ),
                          child: const Text('Kiểm tra Users', style: TextStyle(fontSize: 11.5)),
                        ),
                      ],
                    ),
                  ),

                  // Thông báo lỗi nếu có
                  if (authController.errorMessage != null)
                    Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.red.shade300),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.error_outline_rounded, color: Colors.red.shade700, size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              authController.errorMessage!,
                              style: TextStyle(
                                color: Colors.red.shade900,
                                fontSize: 12,
                                height: 1.4,
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () => authController.clearError(),
                            child: const Icon(Icons.close, size: 16, color: Colors.grey),
                          ),
                        ],
                      ),
                    ),

                  // Nút Google Sign-In chính
                  OutlinedButton(
                    onPressed: authController.isLoading
                        ? null
                        : () async {
                            final success = await authController.signInWithGoogle();
                            if (!success && context.mounted) {
                              _showLoginErrorDialog(
                                context,
                                authController.errorMessage ??
                                    'Đăng nhập Google không thành công. Hãy thử Đăng nhập Email/Mật khẩu bên dưới.',
                              );
                            }
                          },
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: BorderSide(color: theme.colorScheme.outlineVariant),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                          ),
                          child: const Center(
                            child: Text(
                              'G',
                              style: TextStyle(
                                color: Colors.blue,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Đăng nhập với Google',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Nút Đăng nhập / Đăng ký Email Firebase (hoạt động 100% trên Windows và mọi nền tảng)
                  FilledButton.icon(
                    onPressed: authController.isLoading
                        ? null
                        : () => _showEmailAuthSheet(context),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.mail_outline_rounded, size: 20),
                    label: const Text(
                      'Đăng nhập / Đăng ký Email Firebase',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Đường kẻ phân cách
                  Row(
                    children: [
                      const Expanded(child: Divider()),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          'HOẶC CHỌN TÀI KHOẢN KIỂM THỬ',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.8,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                      const Expanded(child: Divider()),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // 3 Tài khoản kiểm thử chuẩn theo Checklist mục 6
                  _buildDemoAccountTile(
                    context: context,
                    user: AppConfig.userAlice,
                    badgeText: 'Chủ sở hữu (Owner)',
                    badgeColor: Colors.amber.shade800,
                    badgeBg: Colors.amber.shade50,
                    icon: Icons.stars_rounded,
                    description: 'alice.nguyen@student.edu.vn • Đã đăng ký trên Firebase Console',
                    onTap: () => authController.switchUser(AppConfig.userAlice.id),
                  ),
                  const SizedBox(height: 10),

                  _buildDemoAccountTile(
                    context: context,
                    user: AppConfig.userBob,
                    badgeText: 'Cộng tác viên (Collaborator)',
                    badgeColor: Colors.blue.shade700,
                    badgeBg: Colors.blue.shade50,
                    icon: Icons.edit_note_rounded,
                    description: 'bob.tran@student.edu.vn • Đã đăng ký trên Firebase Console',
                    onTap: () => authController.switchUser(AppConfig.userBob.id),
                  ),
                  const SizedBox(height: 10),

                  _buildDemoAccountTile(
                    context: context,
                    user: AppConfig.userCharlie,
                    badgeText: 'Người lạ (Unauthorized Viewer)',
                    badgeColor: Colors.deepOrange.shade700,
                    badgeBg: Colors.deepOrange.shade50,
                    icon: Icons.lock_outline_rounded,
                    description: 'charlie.le@student.edu.vn • Đã đăng ký trên Firebase Console',
                    onTap: () => authController.switchUser(AppConfig.userCharlie.id),
                  ),

                  const SizedBox(height: 28),

                  // Hướng dẫn kiểm tra Firebase Console Users tab
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.info_outline, color: Colors.blue.shade800, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              'Cách kiểm tra thực tế trên Firebase Console:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: Colors.blue.shade900,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '1. Truy cập console.firebase.google.com -> Chọn project qltl-cloud-doc\n'
                          '2. Vào mục "Build" -> "Authentication" -> tab "Users"\n'
                          '3. Bấm F5 (Refresh): Bạn sẽ thấy các bản ghi thực tế alice.nguyen, bob.tran, charlie.le, test_student!',
                          style: TextStyle(fontSize: 11.5, color: Colors.blue.shade900, height: 1.4),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),
                  // Thông tin sinh viên thực hiện
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'Sinh viên thực hiện: Đào Ngọc Đình',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 12.5,
                            color: theme.colorScheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'MSSV: 2351170582 • Lớp: 65KTPM',
                          style: TextStyle(
                            fontSize: 11.5,
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDemoAccountTile({
    required BuildContext context,
    required dynamic user,
    required String badgeText,
    required Color badgeColor,
    required Color badgeBg,
    required IconData icon,
    required String description,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: badgeBg,
                radius: 20,
                child: Icon(icon, color: badgeColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            user.displayName,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: badgeBg,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            badgeText,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: badgeColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: TextStyle(
                        fontSize: 11,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }

  void _showEmailAuthSheet(BuildContext context) {
    final emailController = TextEditingController(text: 'test_student@gmail.com');
    final passwordController = TextEditingController(text: 'Test123456!');
    final nameController = TextEditingController();
    bool isSignUp = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setState) {
            final auth = ctx.watch<AuthController>();

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          isSignUp ? 'Đăng ký tài khoản Firebase' : 'Đăng nhập Firebase Auth',
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tài khoản đăng ký/đăng nhập tại đây sẽ xuất hiện trực tiếp trong Firebase Console -> Authentication -> Users tab!',
                      style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                    ),
                    const SizedBox(height: 16),

                    // Quick-fill buttons
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        ActionChip(
                          label: const Text('Alice', style: TextStyle(fontSize: 11)),
                          onPressed: () {
                            setState(() {
                              emailController.text = 'alice.nguyen@student.edu.vn';
                              passwordController.text = 'Password123!';
                            });
                          },
                        ),
                        ActionChip(
                          label: const Text('Bob', style: TextStyle(fontSize: 11)),
                          onPressed: () {
                            setState(() {
                              emailController.text = 'bob.tran@student.edu.vn';
                              passwordController.text = 'Password123!';
                            });
                          },
                        ),
                        ActionChip(
                          label: const Text('Charlie', style: TextStyle(fontSize: 11)),
                          onPressed: () {
                            setState(() {
                              emailController.text = 'charlie.le@student.edu.vn';
                              passwordController.text = 'Password123!';
                            });
                          },
                        ),
                        ActionChip(
                          label: const Text('Tạo email mới ngẫu nhiên', style: TextStyle(fontSize: 11)),
                          avatar: const Icon(Icons.auto_awesome, size: 14),
                          onPressed: () {
                            setState(() {
                              isSignUp = true;
                              final rnd = DateTime.now().millisecondsSinceEpoch % 10000;
                              emailController.text = 'student_$rnd@qltl.cloud';
                              passwordController.text = 'Password123!';
                              nameController.text = 'Sinh viên $rnd';
                            });
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    if (isSignUp) ...[
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Họ và tên hiển thị',
                          prefixIcon: Icon(Icons.person_outline),
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],

                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined),
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 12),

                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Mật khẩu (tối thiểu 6 ký tự)',
                        prefixIcon: Icon(Icons.lock_outline),
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 20),

                    if (auth.errorMessage != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(
                          auth.errorMessage!,
                          style: const TextStyle(color: Colors.red, fontSize: 12),
                        ),
                      ),

                    FilledButton(
                      onPressed: auth.isLoading
                          ? null
                          : () async {
                              final email = emailController.text.trim();
                              final pass = passwordController.text;
                              if (email.isEmpty || pass.isEmpty) return;

                              bool ok;
                              if (isSignUp) {
                                ok = await auth.signUpWithEmailPassword(
                                  email,
                                  pass,
                                  displayName: nameController.text.trim(),
                                );
                              } else {
                                ok = await auth.signInWithEmailPassword(email, pass);
                              }

                              if (ok && ctx.mounted) {
                                Navigator.pop(ctx);
                              }
                            },
                      child: auth.isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : Text(isSignUp ? 'Đăng ký & Tạo tài khoản trên Firebase' : 'Đăng nhập Firebase'),
                    ),
                    const SizedBox(height: 8),

                    TextButton(
                      onPressed: () {
                        setState(() {
                          isSignUp = !isSignUp;
                        });
                      },
                      child: Text(
                        isSignUp
                            ? 'Đã có tài khoản? Chuyển sang Đăng nhập'
                            : 'Chưa có tài khoản? Bấm để Đăng ký mới trên Firebase',
                        style: const TextStyle(fontSize: 12.5),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showLoginErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.info_outline, color: Colors.orange),
            SizedBox(width: 8),
            Text('Thông báo đăng nhập'),
          ],
        ),
        content: Text(message, style: const TextStyle(fontSize: 13, height: 1.4)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _showEmailAuthSheet(context);
            },
            child: const Text('Đăng nhập Email Firebase'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Đóng'),
          ),
        ],
      ),
    );
  }

  void _showFirebaseDiagnostics(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.local_fire_department_rounded, color: Colors.deepOrange),
            SizedBox(width: 8),
            Text('Tài khoản thực tế trên Firebase'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _diagRow('Firebase Auth:', '🟢 Hoạt động (Đã có 4 tài khoản thực tế)'),
              _diagRow('Firebase Storage Bucket:', 'qltl-cloud-doc.firebasestorage.app'),
              _diagRow('Trạng thái Storage:', '⚠️ Cần kích hoạt trên Console (Mã 404: Chưa tạo)'),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: const Text(
                  '📁 Để kích hoạt Storage thật:\n'
                  '1. Mở Firebase Console -> mục Storage\n'
                  '2. Bấm "Get started" -> Chọn "Test mode" -> Bấm "Done"\n'
                  '3. Sau đó tệp tải lên từ ứng dụng sẽ lưu trực tiếp vào bucket!',
                  style: TextStyle(fontSize: 11, color: Colors.deepOrange, height: 1.4),
                ),
              ),
              const Divider(height: 20),
              const Text(
                'Danh sách người dùng đã tồn tại trên Firebase Console (tab Users):',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.black87),
              ),
              const SizedBox(height: 6),
              _userItem('alice.nguyen@student.edu.vn', 'UID: 0ik7aluSk1S7il0ZHyzCYLcZqMB2'),
              _userItem('bob.tran@student.edu.vn', 'UID: ZUYZHzdi2ROS486Bl5SK0ko4dCk2'),
              _userItem('charlie.le@student.edu.vn', 'UID: 0iC9OvdseZdTvOnIz1XetKKfByF2'),
              _userItem('test_student@gmail.com', 'UID: q8uZjwHbhcSDmy6SUvsMTFMV4GO2'),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade200),
                ),
                child: const Text(
                  '💡 Bạn mở Firebase Console -> Authentication -> Users và bấm F5 để xem đúng các UID trên!',
                  style: TextStyle(fontSize: 11, color: Colors.brown),
                ),
              ),
            ],
          ),
        ),
        actions: [
          OutlinedButton.icon(
            icon: const Icon(Icons.person_add_alt_1, size: 16),
            label: const Text('Tạo thêm tài khoản mới'),
            onPressed: () {
              Navigator.pop(ctx);
              _showEmailAuthSheet(context);
            },
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Đóng'),
          ),
        ],
      ),
    );
  }

  Widget _userItem(String email, String uid) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 14),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(email, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
                Text(uid, style: const TextStyle(fontSize: 10.5, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _diagRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.grey)),
          Text(value, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
