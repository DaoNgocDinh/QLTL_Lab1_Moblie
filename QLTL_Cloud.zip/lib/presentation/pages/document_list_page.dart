import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/document.dart';
import '../../application/controllers/document_controller.dart';
import '../widgets/category_chip.dart';
import '../widgets/confirm_delete_dialog.dart';
import '../widgets/document_card.dart';
import '../widgets/document_search_bar.dart';
import '../widgets/empty_state.dart';
import 'add_edit_document_page.dart';
import 'document_detail_page.dart';

class DocumentListPage extends StatefulWidget {
  const DocumentListPage({super.key});

  @override
  State<DocumentListPage> createState() => _DocumentListPageState();
}

class _DocumentListPageState extends State<DocumentListPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DocumentController>().loadDocuments();
    });
  }

  void _navigateToDetail(Document document) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DocumentDetailPage(documentId: document.id!),
      ),
    );
  }

  void _navigateToAdd() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const AddEditDocumentPage(),
      ),
    );
  }

  void _navigateToEdit(Document document) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AddEditDocumentPage(document: document),
      ),
    );
  }

  Future<void> _handleDelete(Document document) async {
    final confirmed = await ConfirmDeleteDialog.show(
      context,
      title: 'Xóa tài liệu',
      message: 'Bạn có chắc chắn muốn xóa "${document.title}" không? Thao tác này không thể hoàn tác.',
    );

    if (confirmed == true && mounted) {
      final success = await context.read<DocumentController>().deleteDocument(document.id!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              success ? 'Đã xóa tài liệu thành công' : 'Xóa tài liệu thất bại',
            ),
            backgroundColor: success ? Colors.green.shade700 : Colors.redAccent,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<DocumentController>();

    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: const [
            Text(
              'QL Tài Liệu Học Tập',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(
              'Kiến trúc Cashew (Local-First)',
              style: TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.normal),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Làm mới',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => controller.loadDocuments(),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadDocuments(),
        child: Column(
          children: [
            // Top Section: Search and Filter Chips
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Search Bar
                  DocumentSearchBar(
                    initialValue: controller.searchQuery,
                    onChanged: (val) => controller.onSearchChanged(val),
                    onClear: () => controller.clearSearch(),
                  ),
                  const SizedBox(height: 12),
                  // Category Filter Chips
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: AppConstants.allCategoriesWithAll.map((category) {
                        final isSelected = controller.selectedCategory == category;
                        final count = controller.countByCategory(category);
                        return CategoryFilterChip(
                          label: category,
                          isSelected: isSelected,
                          count: count,
                          onTap: () => controller.selectCategory(category),
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Tổng số tài liệu trong kho (không bị ảnh hưởng bởi bộ lọc)
                  Row(
                    children: [
                      const Icon(Icons.inventory_2_outlined,
                          size: 14, color: Colors.grey),
                      const SizedBox(width: 6),
                      Text(
                        'Tổng: ${controller.totalCount} tài liệu'
                        '${controller.documents.length == controller.totalCount ? '' : ' • Đang hiện: ${controller.documents.length}'}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade700,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Content List / Loading / Error / Empty
            Expanded(
              child: _buildBody(controller),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateToAdd,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Thêm tài liệu', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildBody(DocumentController controller) {
    if (controller.isLoading && controller.documents.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (controller.errorMessage != null && controller.documents.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline_rounded, size: 48, color: Colors.redAccent),
              const SizedBox(height: 12),
              Text(
                controller.errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.redAccent, fontSize: 14),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => controller.loadDocuments(),
                child: const Text('Thử lại'),
              ),
            ],
          ),
        ),
      );
    }

    if (controller.documents.isEmpty) {
      final isFiltered = controller.selectedCategory != AppConstants.categoryAll ||
          controller.searchQuery.isNotEmpty;
      return EmptyStateView(
        title: isFiltered ? 'Không tìm thấy tài liệu phù hợp' : 'Chưa có tài liệu học tập nào',
        subtitle: isFiltered
            ? 'Hãy thử thay đổi từ khóa tìm kiếm hoặc chọn danh mục khác.'
            : 'Bấm nút "Thêm tài liệu" để bắt đầu lưu trữ bài giảng, bài tập, đề thi.',
        icon: isFiltered ? Icons.search_off_rounded : Icons.library_books_rounded,
        actionLabel: isFiltered ? 'Xóa bộ lọc' : 'Thêm tài liệu ngay',
        onAction: () {
          if (isFiltered) {
            controller.selectCategory(AppConstants.categoryAll);
            controller.clearSearch();
          } else {
            _navigateToAdd();
          }
        },
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
      itemCount: controller.documents.length,
      itemBuilder: (context, index) {
        final doc = controller.documents[index];
        return DocumentCard(
          document: doc,
          onTap: () => _navigateToDetail(doc),
          onEdit: () => _navigateToEdit(doc),
          onDelete: () => _handleDelete(doc),
        );
      },
    );
  }
}
