import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../application/controllers/auth_controller.dart';
import '../../application/controllers/cloud_document_controller.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/cloud_document.dart';

class CloudAddEditDocumentPage extends StatefulWidget {
  final CloudDocument? document;

  const CloudAddEditDocumentPage({super.key, this.document});

  @override
  State<CloudAddEditDocumentPage> createState() =>
      _CloudAddEditDocumentPageState();
}

class _CloudAddEditDocumentPageState extends State<CloudAddEditDocumentPage> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _titleController;
  late TextEditingController _descController;
  late String _selectedCategory;

  String? _pickedFileName;
  Uint8List? _pickedFileBytes;
  int _pickedFileSize = 0;
  bool _isSubmitting = false;

  bool get isEditing => widget.document != null;

  @override
  void initState() {
    super.initState();
    _titleController =
        TextEditingController(text: widget.document?.title ?? '');
    _descController =
        TextEditingController(text: widget.document?.description ?? '');

    final docCategory = widget.document?.category;
    if (docCategory != null &&
        AppConfig.categories.contains(docCategory) &&
        docCategory != 'Tất cả') {
      _selectedCategory = docCategory;
    } else {
      _selectedCategory = 'Bài giảng';
    }

    if (widget.document != null) {
      _pickedFileName = widget.document!.fileName;
      _pickedFileSize = widget.document!.fileSize;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    try {
      final files = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: AppConfig.allowedFileExtensions,
      );

      if (files.isNotEmpty) {
        final file = files.first;
        final bytes = await file.readAsBytes();
        final size = (await file.length()) ?? bytes.length;
        setState(() {
          _pickedFileName = file.name;
          _pickedFileBytes = bytes;
          _pickedFileSize = size;
          // Tự động điền tiêu đề nếu chưa nhập
          if (_titleController.text.trim().isEmpty) {
            _titleController.text = file.name;
          }
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi chọn tệp: $e')),
        );
      }
    }
  }

  String _formatSize(int bytes) {
    if (bytes <= 0) return '0 B';
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final authController = context.watch<AuthController>();
    final documentController = context.read<CloudDocumentController>();
    final currentUser = authController.currentUser;
    final theme = Theme.of(context);

    if (currentUser == null) {
      return const Scaffold(
        body: Center(child: Text('Vui lòng đăng nhập')),
      );
    }

    // Kiểm tra quyền chỉnh sửa nếu đang ở chế độ edit
    final isReadOnly = isEditing && !widget.document!.canEdit(currentUser.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Chỉnh sửa tài liệu' : 'Thêm tài liệu mới'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Thông báo nếu bị chặn quyền (Read-only do RLS)
              if (isReadOnly)
                Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.amber.shade400),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.warning_amber_rounded, color: Colors.amber.shade900),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Bạn chỉ có quyền "Chỉ xem" đối với tài liệu này. Giao diện đang ở chế độ chỉ đọc.',
                          style: TextStyle(
                            color: Colors.amber.shade900,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              // Thẻ chọn tệp Firebase Storage
              Card(
                elevation: 0,
                color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: theme.colorScheme.outlineVariant),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.cloud_upload_rounded, color: Colors.indigo),
                          SizedBox(width: 8),
                          Text(
                            'Tệp tin vật lý (Firebase Storage)',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (_pickedFileName != null) ...[
                        ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: const Icon(Icons.insert_drive_file_rounded, size: 32),
                          title: Text(
                            _pickedFileName!,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text('Kích thước: ${_formatSize(_pickedFileSize)}'),
                          trailing: isReadOnly
                              ? null
                              : TextButton(
                                  onPressed: _pickFile,
                                  child: const Text('Đổi tệp'),
                                ),
                        ),
                      ] else ...[
                        const Text(
                          'Chưa có tệp nào được chọn. Chọn tệp PDF, Word, PowerPoint hoặc Excel để tải lên.',
                          style: TextStyle(fontSize: 12.5),
                        ),
                        const SizedBox(height: 10),
                        FilledButton.tonalIcon(
                          onPressed: isReadOnly ? null : _pickFile,
                          icon: const Icon(Icons.file_open_rounded, size: 18),
                          label: const Text('Chọn tệp từ máy'),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Tiêu đề
              TextFormField(
                controller: _titleController,
                enabled: !isReadOnly,
                decoration: const InputDecoration(
                  labelText: 'Tiêu đề tài liệu *',
                  hintText: 'Nhập tiêu đề hoặc tên tài liệu',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.title_rounded),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Vui lòng nhập tiêu đề tài liệu';
                  }
                  if (val.trim().length < 3) {
                    return 'Tiêu đề phải có ít nhất 3 ký tự';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Danh mục
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(
                  labelText: 'Danh mục *',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category_rounded),
                ),
                items: AppConfig.categories
                    .where((cat) => cat != 'Tất cả')
                    .map((cat) => DropdownMenuItem(value: cat, child: Text(cat)))
                    .toList(),
                onChanged: isReadOnly
                    ? null
                    : (val) {
                        if (val != null) {
                          setState(() => _selectedCategory = val);
                        }
                      },
              ),
              const SizedBox(height: 16),

              // Mô tả
              TextFormField(
                controller: _descController,
                enabled: !isReadOnly,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Mô tả tóm tắt',
                  hintText: 'Nhập nội dung tóm tắt hoặc ghi chú về tài liệu',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 24),

              // Nút Submit
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton.icon(
                  onPressed: (isReadOnly || _isSubmitting)
                      ? null
                      : () async {
                          if (!_formKey.currentState!.validate()) return;

                          setState(() => _isSubmitting = true);

                          bool success = false;
                          if (isEditing) {
                            final updatedDoc = widget.document!.copyWith(
                              title: _titleController.text.trim(),
                              description: _descController.text.trim(),
                              category: _selectedCategory,
                              fileName: _pickedFileName ?? widget.document!.fileName,
                              fileSize: _pickedFileSize > 0
                                  ? _pickedFileSize
                                  : widget.document!.fileSize,
                              updatedAt: DateTime.now(),
                            );
                            success = await documentController.updateDocument(
                              updatedDoc,
                              currentUser.id,
                            );
                          } else {
                            success = await documentController.uploadAndCreateDocument(
                              userId: currentUser.id,
                              userEmail: currentUser.email,
                              userName: currentUser.displayName,
                              title: _titleController.text.trim(),
                              description: _descController.text.trim(),
                              category: _selectedCategory,
                              fileName: _pickedFileName ??
                                  '${_titleController.text.trim()}.pdf',
                              fileBytes: _pickedFileBytes ?? Uint8List(1024 * 50),
                            );
                          }

                          setState(() => _isSubmitting = false);

                          if (!mounted) return;
                          if (success) {
                            Navigator.pop(context);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  isEditing
                                      ? 'Cập nhật tài liệu thành công!'
                                      : 'Thêm tài liệu và tải lên Firebase Storage thành công!',
                                ),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  documentController.errorMessage ??
                                      'Thao tác thất bại!',
                                ),
                                backgroundColor: Colors.red,
                              ),
                            );
                          }
                        },
                  icon: _isSubmitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Icon(isEditing ? Icons.save_rounded : Icons.cloud_upload_rounded),
                  label: Text(
                    isEditing ? 'Lưu thay đổi' : 'Tải lên & Lưu tài liệu',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
