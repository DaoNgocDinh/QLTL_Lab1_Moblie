import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../application/controllers/auth_controller.dart';
import '../../application/controllers/cloud_document_controller.dart';
import '../../domain/entities/cloud_document.dart';
import '../widgets/share_document_dialog.dart';
import 'cloud_add_edit_document_page.dart';

class CloudDocumentDetailPage extends StatelessWidget {
  final String documentId;

  const CloudDocumentDetailPage({super.key, required this.documentId});

  @override
  Widget build(BuildContext context) {
    final authController = context.watch<AuthController>();
    final documentController = context.watch<CloudDocumentController>();
    final currentUser = authController.currentUser;
    final theme = Theme.of(context);
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm:ss');

    if (currentUser == null) {
      return const Scaffold(
        body: Center(child: Text('Vui lòng đăng nhập')),
      );
    }

    final docList = documentController.documents
        .where((d) => d.id == documentId)
        .toList();
    final CloudDocument? doc = docList.isNotEmpty
        ? docList.first
        : documentController.selectedDocument;

    if (doc == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Chi tiết tài liệu')),
        body: const Center(child: Text('Không tìm thấy tài liệu hoặc không có quyền truy cập.')),
      );
    }

    final isOwner = doc.isOwner(currentUser.id);
    final canEdit = doc.canEdit(currentUser.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết tài liệu'),
        actions: [
          if (canEdit)
            IconButton(
              icon: const Icon(Icons.edit_rounded),
              tooltip: 'Chỉnh sửa tài liệu',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CloudAddEditDocumentPage(document: doc),
                  ),
                );
              },
            ),
          if (isOwner)
            IconButton(
              icon: const Icon(Icons.share_rounded),
              tooltip: 'Chia sẻ tài liệu',
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => ShareDocumentDialog(
                    document: doc,
                    requestingUserId: currentUser.id,
                  ),
                );
              },
            ),
          if (isOwner)
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: Colors.red),
              tooltip: 'Xóa tài liệu',
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Xác nhận xóa tài liệu'),
                    content: Text(
                      'Bạn có chắc chắn muốn xóa tài liệu "${doc.title}"?\nThao tác này sẽ xóa tệp vật lý trên Firebase Storage và dữ liệu trên Supabase.',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Hủy'),
                      ),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: Colors.red),
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Xóa'),
                      ),
                    ],
                  ),
                );

                if (confirm == true && context.mounted) {
                  final ok = await documentController.deleteDocument(
                    doc.id,
                    currentUser.id,
                  );
                  if (ok && context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Đã xóa tài liệu thành công.')),
                    );
                  }
                }
              },
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status & Permissions Header Card
            Card(
              elevation: 0,
              color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: theme.colorScheme.outlineVariant),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          isOwner
                              ? Icons.stars_rounded
                              : (canEdit ? Icons.edit_rounded : Icons.visibility_rounded),
                          color: isOwner
                              ? Colors.amber.shade900
                              : (canEdit ? Colors.blue.shade800 : Colors.grey.shade800),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          isOwner
                              ? 'Bạn là Chủ sở hữu (Full Access)'
                              : (canEdit
                                  ? 'Bạn có quyền Chỉnh sửa (Edit Access)'
                                  : 'Bạn có quyền Chỉ xem (View Only Access)'),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: isOwner
                                ? Colors.amber.shade900
                                : (canEdit ? Colors.blue.shade800 : Colors.grey.shade800),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Tài khoản đăng nhập: ${currentUser.displayName} (${currentUser.email})',
                      style: TextStyle(
                        fontSize: 12,
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Tiêu đề & Danh mục
            Text(
              doc.title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                doc.category,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Thông tin tệp vật lý (Firebase Storage)
            const Text(
              'Tệp đính kèm (Firebase Storage)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 8),
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(color: theme.colorScheme.outlineVariant),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: theme.colorScheme.secondaryContainer,
                  child: Icon(
                    Icons.attachment_rounded,
                    color: theme.colorScheme.onSecondaryContainer,
                  ),
                ),
                title: Text(
                  doc.fileName ?? doc.title,
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
                subtitle: Text(
                  '${doc.fileType} • ${doc.formattedFileSize}',
                  style: const TextStyle(fontSize: 12),
                ),
                trailing: (doc.fileUrl != null && doc.fileUrl!.isNotEmpty)
                    ? IconButton(
                        icon: const Icon(Icons.open_in_new_rounded),
                        tooltip: 'Mở / Tải tệp',
                        onPressed: () async {
                          final uri = Uri.parse(doc.fileUrl!);
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri);
                          } else {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Đường dẫn tệp Firebase Storage:\n${doc.fileUrl}'),
                                ),
                              );
                            }
                          }
                        },
                      )
                    : null,
              ),
            ),
            if (doc.storagePath != null) ...[
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  'Storage Path: ${doc.storagePath}',
                  style: TextStyle(
                    fontSize: 11,
                    fontFamily: 'monospace',
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 16),

            // Mô tả
            const Text(
              'Mô tả chi tiết',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: theme.colorScheme.outlineVariant),
              ),
              child: Text(
                doc.description.isNotEmpty
                    ? doc.description
                    : 'Không có mô tả chi tiết cho tài liệu này.',
                style: const TextStyle(fontSize: 13.5, height: 1.4),
              ),
            ),
            const SizedBox(height: 16),

            // Metadata & Quyền chia sẻ
            const Text(
              'Thông tin hệ thống & Quyền hạn',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            const SizedBox(height: 8),
            Table(
              columnWidths: const {
                0: FlexColumnWidth(1.2),
                1: FlexColumnWidth(2.0),
              },
              children: [
                TableRow(children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 4),
                    child: Text('Chủ sở hữu:', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text('${doc.ownerName ?? doc.ownerId} (${doc.ownerEmail ?? ""})'),
                  ),
                ]),
                TableRow(children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 4),
                    child: Text('Ngày tạo:', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(dateFormat.format(doc.createdAt)),
                  ),
                ]),
                TableRow(children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 4),
                    child: Text('Cập nhật lần cuối:', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(dateFormat.format(doc.updatedAt)),
                  ),
                ]),
                TableRow(children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 4),
                    child: Text('Được chia sẻ với:', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      doc.permissions.isEmpty
                          ? 'Chưa chia sẻ cho ai'
                          : doc.permissions
                              .map((p) =>
                                  '${p.userDisplayName ?? p.userId} (${p.permissionLevel == "edit" ? "Sửa" : "Xem"})')
                              .join(', '),
                    ),
                  ),
                ]),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
