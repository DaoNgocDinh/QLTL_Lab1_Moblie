import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/validation/document_validator.dart';
import '../../domain/entities/document.dart';
import '../../application/controllers/document_controller.dart';

class AddEditDocumentPage extends StatefulWidget {
  final Document? document;

  const AddEditDocumentPage({super.key, this.document});

  bool get isEditing => document != null;

  @override
  State<AddEditDocumentPage> createState() => _AddEditDocumentPageState();
}

class _AddEditDocumentPageState extends State<AddEditDocumentPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _titleController;
  late final TextEditingController _descriptionController;
  late final TextEditingController _filePathController;
  late final TextEditingController _authorController;

  late String _selectedCategory;
  late String _selectedFileType;

  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final doc = widget.document;
    _titleController = TextEditingController(text: doc?.title ?? '');
    _descriptionController = TextEditingController(text: doc?.description ?? '');
    _filePathController = TextEditingController(text: doc?.filePath ?? '');
    _authorController = TextEditingController(text: doc?.author ?? '');

    _selectedCategory = doc?.category ?? AppConstants.categoryLecture;
    _selectedFileType = doc?.fileType ?? AppConstants.fileTypePdf;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _filePathController.dispose();
    _authorController.dispose();
    super.dispose();
  }

  Future<void> _saveDocument() async {
    if (_isSaving) return;
    if (!_formKey.currentState!.validate()) return;

    final controller = context.read<DocumentController>();
    final isEdit = widget.isEditing;

    setState(() => _isSaving = true);

    final doc = Document(
      id: widget.document?.id,
      title: _titleController.text.trim(),
      description: _descriptionController.text.trim(),
      category: _selectedCategory,
      filePath: _filePathController.text.trim(),
      fileType: _selectedFileType,
      author: _authorController.text.trim().isEmpty ? 'Chưa cập nhật' : _authorController.text.trim(),
      createdAt: widget.document?.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );

    final success = isEdit
        ? await controller.updateDocument(doc)
        : await controller.addDocument(doc);

    if (!mounted) return;

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isEdit ? 'Đã cập nhật tài liệu' : 'Đã thêm tài liệu thành công'),
          backgroundColor: Colors.green.shade700,
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.of(context).pop();
    } else {
      setState(() => _isSaving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(controller.errorMessage ?? 'Có lỗi xảy ra, vui lòng thử lại'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.isEditing;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Chỉnh sửa tài liệu' : 'Thêm tài liệu mới'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title Field
              const Text(
                'Tên tài liệu *',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _titleController,
                textInputAction: TextInputAction.next,
                maxLength: DocumentValidator.maxTitleLength,
                decoration: const InputDecoration(
                  hintText: 'Nhập tên tài liệu hoặc bài giảng...',
                  prefixIcon: Icon(Icons.title_rounded),
                  counterText: '',
                ),
                validator: DocumentValidator.validateTitle,
              ),
              const SizedBox(height: 18),

              // Category & File Type Row
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category Dropdown
                  Expanded(
                    flex: 3,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Danh mục *',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        const SizedBox(height: 6),
                        DropdownButtonFormField<String>(
                          initialValue: _selectedCategory,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.category_rounded),
                          ),
                          validator: DocumentValidator.validateCategory,
                          items: AppConstants.categories.map((cat) {
                            return DropdownMenuItem(
                              value: cat,
                              child: Text(cat, style: const TextStyle(fontSize: 14)),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedCategory = val);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  // File Type Dropdown
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Định dạng *',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        const SizedBox(height: 6),
                        DropdownButtonFormField<String>(
                          initialValue: _selectedFileType,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.insert_drive_file_rounded),
                          ),
                          validator: DocumentValidator.validateFileType,
                          items: AppConstants.fileTypes.map((type) {
                            return DropdownMenuItem(
                              value: type,
                              child: Text(type, style: const TextStyle(fontSize: 14)),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => _selectedFileType = val);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // Author Field
              const Text(
                'Tác giả / Giảng viên',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _authorController,
                textInputAction: TextInputAction.next,
                maxLength: DocumentValidator.maxAuthorLength,
                decoration: const InputDecoration(
                  hintText: 'Nhập tên tác giả, giảng viên hoặc nguồn...',
                  prefixIcon: Icon(Icons.person_outline_rounded),
                  counterText: '',
                ),
                validator: DocumentValidator.validateAuthor,
              ),
              const SizedBox(height: 18),

              // File Path or Link
              const Text(
                'Đường dẫn / Tên file lưu trữ',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _filePathController,
                textInputAction: TextInputAction.next,
                maxLength: DocumentValidator.maxFilePathLength,
                decoration: const InputDecoration(
                  hintText: 'Ví dụ: /documents/lectures/bai1.pdf',
                  prefixIcon: Icon(Icons.folder_open_rounded),
                  counterText: '',
                ),
                validator: DocumentValidator.validateFilePath,
              ),
              const SizedBox(height: 18),

              // Description Field
              const Text(
                'Mô tả chi tiết',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 6),
              TextFormField(
                controller: _descriptionController,
                maxLines: 4,
                maxLength: DocumentValidator.maxDescriptionLength,
                decoration: const InputDecoration(
                  hintText: 'Tóm tắt nội dung chính của tài liệu học tập...',
                  alignLabelWithHint: true,
                ),
                validator: DocumentValidator.validateDescription,
              ),
              const SizedBox(height: 28),

              // Submit Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isSaving ? null : _saveDocument,
                  icon: _isSaving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Icon(isEdit ? Icons.save_rounded : Icons.add_circle_rounded),
                  label: Text(
                    _isSaving
                        ? 'Đang lưu...'
                        : (isEdit ? 'Lưu thay đổi' : 'Thêm tài liệu vào kho'),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
