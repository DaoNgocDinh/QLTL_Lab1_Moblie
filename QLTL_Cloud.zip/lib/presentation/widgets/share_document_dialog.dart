import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../application/controllers/auth_controller.dart';
import '../../application/controllers/cloud_document_controller.dart';
import '../../domain/entities/cloud_document.dart';

class ShareDocumentDialog extends StatefulWidget {
  final CloudDocument document;
  final String requestingUserId;

  const ShareDocumentDialog({
    super.key,
    required this.document,
    required this.requestingUserId,
  });

  @override
  State<ShareDocumentDialog> createState() => _ShareDocumentDialogState();
}

class _ShareDocumentDialogState extends State<ShareDocumentDialog> {
  String? _selectedUserId;
  String _selectedPermissionLevel = 'view';
  bool _isSubmitting = false;

  @override
  Widget build(BuildContext context) {
    final authController = context.watch<AuthController>();
    final documentController = context.watch<CloudDocumentController>();

    // Lấy tài liệu mới nhất từ controller nếu có
    final currentDoc = documentController.selectedDocument?.id == widget.document.id
        ? documentController.selectedDocument!
        : widget.document;

    // Lọc danh sách người dùng khả dụng (loại trừ chính owner)
    final eligibleUsers = authController.demoUsers
        .where((u) => u.id != currentDoc.ownerId)
        .toList();

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 500, maxHeight: 650),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.share_rounded,
                      color: Theme.of(context).colorScheme.primary,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Chia sẻ tài liệu',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          currentDoc.title,
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),

              // Form Cấp quyền
              const Text(
                'Thêm người nhận quyền',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedUserId,
                decoration: const InputDecoration(
                  labelText: 'Chọn người dùng',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  prefixIcon: Icon(Icons.person_outline_rounded),
                ),
                hint: const Text('Chọn tài khoản nhận quyền'),
                items: eligibleUsers.map((user) {
                  return DropdownMenuItem<String>(
                    value: user.id,
                    child: Text(
                      '${user.displayName} (${user.email})',
                      style: const TextStyle(fontSize: 13),
                    ),
                  );
                }).toList(),
                onChanged: (val) {
                  setState(() => _selectedUserId = val);
                },
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _selectedPermissionLevel,
                      decoration: const InputDecoration(
                        labelText: 'Cấp độ quyền',
                        border: OutlineInputBorder(),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        prefixIcon: Icon(Icons.security_rounded),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'view',
                          child: Text('Chỉ xem (View)'),
                        ),
                        DropdownMenuItem(
                          value: 'edit',
                          child: Text('Chỉnh sửa (Edit)'),
                        ),
                      ],
                      onChanged: (val) {
                        if (val != null) {
                          setState(() => _selectedPermissionLevel = val);
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  FilledButton.icon(
                    onPressed: _selectedUserId == null || _isSubmitting
                        ? null
                        : () async {
                            setState(() => _isSubmitting = true);
                            final success = await documentController.shareDocument(
                              documentId: currentDoc.id,
                              targetUserId: _selectedUserId!,
                              permissionLevel: _selectedPermissionLevel,
                              requestingUserId: widget.requestingUserId,
                            );
                            setState(() => _isSubmitting = false);
                            if (!mounted) return;
                            if (success) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Đã cập nhật quyền chia sẻ thành công.'),
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            }
                          },
                    icon: _isSubmitting
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.person_add_alt_1_rounded, size: 18),
                    label: const Text('Cấp quyền'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),

              // Danh sách những người đang có quyền
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Người dùng có quyền truy cập',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                  ),
                  Text(
                    '${currentDoc.permissions.length + 1} người',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),

              // Danh sách cuộn
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    // Owner Tile
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const CircleAvatar(
                        radius: 16,
                        backgroundColor: Colors.amber,
                        child: Icon(Icons.star, size: 16, color: Colors.white),
                      ),
                      title: Text(
                        currentDoc.ownerName ?? 'Chủ sở hữu',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      subtitle: Text(
                        currentDoc.ownerEmail ?? currentDoc.ownerId,
                        style: const TextStyle(fontSize: 11),
                      ),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.amber.shade100,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Chủ sở hữu',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Colors.amber.shade900,
                          ),
                        ),
                      ),
                    ),

                    // Permission tiles
                    ...currentDoc.permissions.map((perm) {
                      final isEdit = perm.permissionLevel == 'edit';
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: CircleAvatar(
                          radius: 16,
                          backgroundColor:
                              isEdit ? Colors.blue.shade100 : Colors.grey.shade200,
                          child: Icon(
                            isEdit ? Icons.edit : Icons.visibility,
                            size: 14,
                            color: isEdit ? Colors.blue.shade800 : Colors.grey.shade800,
                          ),
                        ),
                        title: Text(
                          perm.userDisplayName ?? perm.userId,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        subtitle: Text(
                          perm.userEmail ?? perm.userId,
                          style: const TextStyle(fontSize: 11),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: isEdit
                                    ? Colors.blue.shade50
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(
                                  color: isEdit
                                      ? Colors.blue.shade300
                                      : Colors.grey.shade400,
                                ),
                              ),
                              child: Text(
                                isEdit ? 'Được sửa' : 'Chỉ xem',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: isEdit
                                      ? Colors.blue.shade900
                                      : Colors.grey.shade800,
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            IconButton(
                              icon: const Icon(
                                Icons.delete_outline_rounded,
                                size: 18,
                                color: Colors.red,
                              ),
                              tooltip: 'Thu hồi quyền',
                              onPressed: () async {
                                final confirm = await showDialog<bool>(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text('Thu hồi quyền'),
                                    content: Text(
                                      'Bạn có chắc chắn muốn thu hồi quyền truy cập của ${perm.userDisplayName ?? perm.userId}?',
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(ctx, false),
                                        child: const Text('Hủy'),
                                      ),
                                      FilledButton(
                                        style: FilledButton.styleFrom(
                                          backgroundColor: Colors.red,
                                        ),
                                        onPressed: () => Navigator.pop(ctx, true),
                                        child: const Text('Thu hồi'),
                                      ),
                                    ],
                                  ),
                                );

                                if (confirm == true) {
                                  await documentController.revokePermission(
                                    documentId: currentDoc.id,
                                    targetUserId: perm.userId,
                                    requestingUserId: widget.requestingUserId,
                                  );
                                }
                              },
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),

              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Đóng'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
