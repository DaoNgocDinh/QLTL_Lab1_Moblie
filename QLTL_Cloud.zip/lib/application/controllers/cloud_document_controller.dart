import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../../domain/entities/cloud_document.dart';
import '../../domain/repositories/cloud_document_repository.dart';
import '../../domain/repositories/storage_repository.dart';

class CloudDocumentController extends ChangeNotifier {
  final CloudDocumentRepository _documentRepository;
  final StorageRepository _storageRepository;

  List<CloudDocument> _documents = [];
  Map<String, int> _categoryCounts = {'Tất cả': 0};
  String _selectedCategory = 'Tất cả';
  String _searchQuery = '';
  DocumentTabFilter _currentTab = DocumentTabFilter.all;
  bool _isLoading = false;
  String? _errorMessage;
  CloudDocument? _selectedDocument;

  CloudDocumentController({
    required CloudDocumentRepository documentRepository,
    required StorageRepository storageRepository,
  })  : _documentRepository = documentRepository,
        _storageRepository = storageRepository;

  List<CloudDocument> get documents => _documents;
  Map<String, int> get categoryCounts => _categoryCounts;
  String get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;
  DocumentTabFilter get currentTab => _currentTab;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  CloudDocument? get selectedDocument => _selectedDocument;

  /// Tải danh sách tài liệu tuân theo phân quyền RLS cho user
  Future<void> loadDocuments(String userId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _documents = await _documentRepository.getDocumentsForUser(
        userId,
        category: _selectedCategory,
        query: _searchQuery,
        tab: _currentTab,
      );
      _categoryCounts = await _documentRepository.getDocumentCounts(userId);
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Lọc theo danh mục
  Future<void> selectCategory(String category, String userId) async {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    await loadDocuments(userId);
  }

  /// Tìm kiếm theo từ khóa
  Future<void> setSearchQuery(String query, String userId) async {
    _searchQuery = query;
    await loadDocuments(userId);
  }

  /// Đổi tab (Tất cả / Của tôi / Được chia sẻ)
  Future<void> setTab(DocumentTabFilter tab, String userId) async {
    if (_currentTab == tab) return;
    _currentTab = tab;
    await loadDocuments(userId);
  }

  /// Tải lên tệp lên Firebase Storage và tạo bản ghi tài liệu trên Supabase
  Future<bool> uploadAndCreateDocument({
    required String userId,
    required String userEmail,
    required String userName,
    required String title,
    required String description,
    required String category,
    String? fileName,
    List<int>? fileBytes,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      String? fileUrl;
      String? storagePath;
      String fileType = 'PDF';
      int fileSize = 0;

      // Nếu người dùng chọn file vật lý, upload lên Firebase Storage
      if (fileName != null && fileBytes != null && fileBytes.isNotEmpty) {
        final uploaded = await _storageRepository.uploadDocumentFile(
          userId: userId,
          fileName: fileName,
          bytes: fileBytes,
        );
        fileUrl = uploaded.fileUrl;
        storagePath = uploaded.storagePath;
        fileType = uploaded.fileType;
        fileSize = uploaded.fileSize;
      }

      final newDoc = CloudDocument(
        id: const Uuid().v4(),
        ownerId: userId,
        ownerEmail: userEmail,
        ownerName: userName,
        title: title.trim(),
        description: description.trim(),
        category: category,
        fileUrl: fileUrl,
        fileName: fileName,
        fileType: fileType,
        fileSize: fileSize,
        storagePath: storagePath,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _documentRepository.createDocument(newDoc, userId);
      await loadDocuments(userId);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Cập nhật thông tin tài liệu (Kiểm tra quyền RLS)
  Future<bool> updateDocument(
    CloudDocument document,
    String requestingUserId,
  ) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final updated = await _documentRepository.updateDocument(
        document,
        requestingUserId,
      );
      _selectedDocument = updated;
      await loadDocuments(requestingUserId);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Xóa tài liệu (Chỉ Owner mới có quyền)
  Future<bool> deleteDocument(
    String documentId,
    String requestingUserId,
  ) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _documentRepository.deleteDocument(documentId, requestingUserId);
      if (_selectedDocument?.id == documentId) {
        _selectedDocument = null;
      }
      await loadDocuments(requestingUserId);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Chia sẻ tài liệu cho người khác
  Future<bool> shareDocument({
    required String documentId,
    required String targetUserId,
    required String permissionLevel,
    required String requestingUserId,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _documentRepository.shareDocument(
        documentId: documentId,
        targetUserId: targetUserId,
        permissionLevel: permissionLevel,
        requestingUserId: requestingUserId,
      );
      // Cập nhật lại chi tiết document hiện tại nếu đang mở
      if (_selectedDocument?.id == documentId) {
        _selectedDocument = await _documentRepository.getDocumentById(
          documentId,
          requestingUserId,
        );
      }
      await loadDocuments(requestingUserId);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Thu hồi quyền chia sẻ tài liệu
  Future<bool> revokePermission({
    required String documentId,
    required String targetUserId,
    required String requestingUserId,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _documentRepository.revokePermission(
        documentId: documentId,
        targetUserId: targetUserId,
        requestingUserId: requestingUserId,
      );
      if (_selectedDocument?.id == documentId) {
        _selectedDocument = await _documentRepository.getDocumentById(
          documentId,
          requestingUserId,
        );
      }
      await loadDocuments(requestingUserId);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Lấy chi tiết tài liệu theo ID
  Future<CloudDocument?> getDocumentById(
    String documentId,
    String userId,
  ) async {
    try {
      _selectedDocument = await _documentRepository.getDocumentById(
        documentId,
        userId,
      );
      notifyListeners();
      return _selectedDocument;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return null;
    }
  }
}
