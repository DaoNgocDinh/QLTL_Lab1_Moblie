import 'package:flutter/foundation.dart';
import '../../core/constants/app_constants.dart';
import '../../domain/entities/document.dart';
import '../use_cases/add_document.dart';
import '../use_cases/delete_document.dart';
import '../use_cases/get_document_by_id.dart';
import '../use_cases/get_document_counts.dart';
import '../use_cases/get_documents.dart';
import '../use_cases/search_documents.dart';
import '../use_cases/update_document.dart';

class DocumentController extends ChangeNotifier {
  final GetDocumentsUseCase getDocumentsUseCase;
  final GetDocumentByIdUseCase getDocumentByIdUseCase;
  final AddDocumentUseCase addDocumentUseCase;
  final UpdateDocumentUseCase updateDocumentUseCase;
  final DeleteDocumentUseCase deleteDocumentUseCase;
  final SearchDocumentsUseCase searchDocumentsUseCase;
  final GetDocumentCountsUseCase getDocumentCountsUseCase;

  List<Document> _documents = [];
  Map<String, int> _categoryCounts = const {};
  bool _isLoading = false;
  String? _errorMessage;
  String _selectedCategory = AppConstants.categoryAll;
  String _searchQuery = '';

  DocumentController({
    required this.getDocumentsUseCase,
    required this.getDocumentByIdUseCase,
    required this.addDocumentUseCase,
    required this.updateDocumentUseCase,
    required this.deleteDocumentUseCase,
    required this.searchDocumentsUseCase,
    required this.getDocumentCountsUseCase,
  });

  // Getters
  List<Document> get documents => _documents;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;

  // Category counts — phản ánh TOÀN BỘ kho tài liệu, không phụ thuộc bộ lọc
  // danh mục hay từ khóa tìm kiếm đang hoạt động.
  int get totalCount => _categoryCounts.values.fold(0, (sum, count) => sum + count);

  int countByCategory(String category) {
    if (category == AppConstants.categoryAll) {
      return totalCount;
    }
    return _categoryCounts[category] ?? 0;
  }

  // Load documents
  Future<void> loadDocuments() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (_searchQuery.trim().isNotEmpty) {
        _documents = await searchDocumentsUseCase.execute(
          _searchQuery,
          category: _selectedCategory == AppConstants.categoryAll ? null : _selectedCategory,
        );
      } else {
        _documents = await getDocumentsUseCase.execute(
          category: _selectedCategory == AppConstants.categoryAll ? null : _selectedCategory,
        );
      }
      await _loadCounts();
    } catch (e) {
      _errorMessage = 'Không thể tải danh sách tài liệu: ${e.toString()}';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _loadCounts() async {
    try {
      _categoryCounts = await getDocumentCountsUseCase.execute();
    } catch (_) {
      // Nếu lấy số liệu thống kê thất bại thì giữ số liệu cũ,
      // không làm hỏng việc hiển thị danh sách tài liệu.
      _categoryCounts = const {};
    }
  }

  // Select category filter
  void selectCategory(String category) {
    if (_selectedCategory == category) return;
    _selectedCategory = category;
    loadDocuments();
  }

  // Search
  void onSearchChanged(String query) {
    _searchQuery = query;
    loadDocuments();
  }

  void clearSearch() {
    if (_searchQuery.isEmpty) return;
    _searchQuery = '';
    loadDocuments();
  }

  // Add document
  Future<bool> addDocument(Document document) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await addDocumentUseCase.execute(document);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '').replaceAll('ArgumentError: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Update document
  Future<bool> updateDocument(Document document) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await updateDocumentUseCase.execute(document);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '').replaceAll('ArgumentError: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Delete document
  Future<bool> deleteDocument(int id) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await deleteDocumentUseCase.execute(id);
      await loadDocuments();
      return true;
    } catch (e) {
      _errorMessage = 'Lỗi khi xóa tài liệu: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Get by ID
  Future<Document?> getDocumentById(int id) async {
    try {
      return await getDocumentByIdUseCase.execute(id);
    } catch (e) {
      _errorMessage = 'Lỗi khi lấy tài liệu: ${e.toString()}';
      return null;
    }
  }
}
