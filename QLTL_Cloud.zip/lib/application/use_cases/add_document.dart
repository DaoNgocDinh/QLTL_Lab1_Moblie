import '../../core/validation/document_validator.dart';
import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class AddDocumentUseCase {
  final DocumentRepository repository;

  AddDocumentUseCase(this.repository);

  Future<int> execute(Document document) async {
    final error = DocumentValidator.collectFirstError(
      title: document.title,
      category: document.category,
      fileType: document.fileType,
      filePath: document.filePath,
      author: document.author,
      description: document.description,
    );
    if (error != null) {
      throw ArgumentError(error);
    }

    final sanitizedDoc = document.copyWith(
      title: document.title.trim(),
      category: document.category.trim(),
      fileType: document.fileType.trim(),
      description: document.description.trim(),
      filePath: document.filePath.trim(),
      author: document.author.trim().isEmpty ? 'Chưa cập nhật' : document.author.trim(),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    return await repository.addDocument(sanitizedDoc);
  }
}