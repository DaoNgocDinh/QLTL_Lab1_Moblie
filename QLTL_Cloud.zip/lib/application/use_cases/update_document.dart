import '../../core/validation/document_validator.dart';
import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';

class UpdateDocumentUseCase {
  final DocumentRepository repository;

  UpdateDocumentUseCase(this.repository);

  Future<bool> execute(Document document) async {
    if (document.id == null || document.id! <= 0) {
      throw ArgumentError('ID tài liệu không hợp lệ để cập nhật');
    }

    final error = DocumentValidator.collectFirstError(
      title: document.title,
      category: document.category,
      fileType: document.fileType,
      filePath: document.filePath,
      author: document.author,
      description: document.description,
    );
    if (error != null) {
      throw ArgumentError(error);
    }

    final sanitizedDoc = document.copyWith(
      title: document.title.trim(),
      category: document.category.trim(),
      fileType: document.fileType.trim(),
      description: document.description.trim(),
      filePath: document.filePath.trim(),
      author: document.author.trim().isEmpty ? 'Chưa cập nhật' : document.author.trim(),
      updatedAt: DateTime.now(),
    );

    return await repository.updateDocument(sanitizedDoc);
  }
}