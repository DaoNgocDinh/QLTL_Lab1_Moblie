import '../../domain/repositories/document_repository.dart';

class GetDocumentCountsUseCase {
  final DocumentRepository repository;

  GetDocumentCountsUseCase(this.repository);

  /// Trả về map {danh mục: số lượng} cho toàn bộ kho tài liệu.
  /// Luôn phản ánh tổng số tài liệu thực tế, không phụ thuộc bộ lọc
  /// danh mục / từ khóa đang được chọn trên giao diện.
  Future<Map<String, int>> execute() {
    return repository.countByCategory();
  }
}