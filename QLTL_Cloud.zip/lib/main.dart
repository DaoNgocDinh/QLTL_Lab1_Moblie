import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'application/controllers/auth_controller.dart';
import 'application/controllers/cloud_document_controller.dart';
import 'application/controllers/document_controller.dart';
import 'application/use_cases/add_document.dart';
import 'application/use_cases/delete_document.dart';
import 'application/use_cases/get_document_by_id.dart';
import 'application/use_cases/get_document_counts.dart';
import 'application/use_cases/get_documents.dart';
import 'application/use_cases/search_documents.dart';
import 'application/use_cases/update_document.dart';
import 'core/theme/app_theme.dart';
import 'data/dao/document_dao.dart';
import 'data/database/database_helper.dart';
import 'data/repositories/cloud_document_repository_impl.dart';
import 'data/repositories/document_repository_impl.dart';
import 'data/services/auth_service.dart';
import 'data/services/firebase_storage_service.dart';
import 'domain/repositories/document_repository.dart';

import 'package:firebase_core/firebase_core.dart';

import 'core/config/app_config.dart';
import 'firebase_options.dart';
import 'presentation/pages/cloud_document_list_page.dart';
import 'presentation/pages/login_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Khởi tạo Firebase với cấu hình DefaultFirebaseOptions
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('Firebase initialized successfully: ${Firebase.app().name}');
  } catch (e) {
    debugPrint('Firebase initialize notice: $e');
  }

  // Tải cấu hình đám mây đã lưu
  await AppConfig.loadSavedConfig();

  // Khởi tạo Supabase nếu có cấu hình dự án thực tế
  try {
    if (!AppConfig.supabaseUrl.contains('xyzcompany') &&
        AppConfig.supabaseUrl.isNotEmpty) {
      await Supabase.initialize(
        url: AppConfig.supabaseUrl,
        anonKey: AppConfig.supabaseAnonKey,
      );
      debugPrint('Supabase initialized successfully');
    }
  } catch (e) {
    debugPrint('Supabase initialize notice: $e');
  }

  // Khởi tạo FFI cho SQLite trên nền tảng Desktop (Windows, Linux, macOS)
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }

  // ==========================================================================
  // 1. TẦNG DATA & SERVICES
  // ==========================================================================
  // Khởi tạo Auth Service & Storage Service (Firebase)
  final authRepository = AuthServiceImpl();
  final storageRepository = FirebaseStorageServiceImpl();

  // Khởi tạo Cloud Document Repository (Supabase + RLS Engine)
  final cloudDocumentRepository = CloudDocumentRepositoryImpl();

  // Khởi tạo Local SQLite Repository (tương thích ngược)
  final databaseHelper = DatabaseHelper();
  final documentDao = DocumentDao(databaseHelper: databaseHelper);
  final DocumentRepository documentRepository = DocumentRepositoryImpl(
    documentDao,
  );

  // ==========================================================================
  // 2. TẦNG APPLICATION (CONTROLLERS & USE CASES)
  // ==========================================================================
  final authController = AuthController(authRepository);
  final cloudDocumentController = CloudDocumentController(
    documentRepository: cloudDocumentRepository,
    storageRepository: storageRepository,
  );

  final getDocumentsUseCase = GetDocumentsUseCase(documentRepository);
  final getDocumentByIdUseCase = GetDocumentByIdUseCase(documentRepository);
  final addDocumentUseCase = AddDocumentUseCase(documentRepository);
  final updateDocumentUseCase = UpdateDocumentUseCase(documentRepository);
  final deleteDocumentUseCase = DeleteDocumentUseCase(documentRepository);
  final searchDocumentsUseCase = SearchDocumentsUseCase(documentRepository);
  final getDocumentCountsUseCase = GetDocumentCountsUseCase(documentRepository);

  final localDocumentController = DocumentController(
    getDocumentsUseCase: getDocumentsUseCase,
    getDocumentByIdUseCase: getDocumentByIdUseCase,
    addDocumentUseCase: addDocumentUseCase,
    updateDocumentUseCase: updateDocumentUseCase,
    deleteDocumentUseCase: deleteDocumentUseCase,
    searchDocumentsUseCase: searchDocumentsUseCase,
    getDocumentCountsUseCase: getDocumentCountsUseCase,
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthController>.value(value: authController),
        ChangeNotifierProvider<CloudDocumentController>.value(
          value: cloudDocumentController,
        ),
        ChangeNotifierProvider<DocumentController>.value(
          value: localDocumentController,
        ),
      ],
      child: const QLTLApp(),
    ),
  );
}

class QLTLApp extends StatelessWidget {
  const QLTLApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quản Lý Tài Liệu Cloud (Flutter • Firebase • Supabase)',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: Consumer<AuthController>(
        builder: (context, auth, _) {
          if (auth.isAuthenticated) {
            return const CloudDocumentListPage();
          }
          return const LoginPage();
        },
      ),
    );
  }
}
