import '../../domain/entities/document_permission.dart';

class DocumentPermissionModel {
  final String id;
  final String documentId;
  final String userId;
  final String permissionLevel;
  final String grantedBy;
  final String? userEmail;
  final String? userDisplayName;
  final DateTime? createdAt;

  const DocumentPermissionModel({
    required this.id,
    required this.documentId,
    required this.userId,
    required this.permissionLevel,
    required this.grantedBy,
    this.userEmail,
    this.userDisplayName,
    this.createdAt,
  });

  factory DocumentPermissionModel.fromEntity(DocumentPermission permission) {
    return DocumentPermissionModel(
      id: permission.id,
      documentId: permission.documentId,
      userId: permission.userId,
      permissionLevel: permission.permissionLevel,
      grantedBy: permission.grantedBy,
      userEmail: permission.userEmail,
      userDisplayName: permission.userDisplayName,
      createdAt: permission.createdAt,
    );
  }

  DocumentPermission toEntity() {
    return DocumentPermission(
      id: id,
      documentId: documentId,
      userId: userId,
      permissionLevel: permissionLevel,
      grantedBy: grantedBy,
      userEmail: userEmail,
      userDisplayName: userDisplayName,
      createdAt: createdAt,
    );
  }

  factory DocumentPermissionModel.fromMap(Map<String, dynamic> map) {
    return DocumentPermissionModel(
      id: map['id']?.toString() ?? '',
      documentId: map['document_id']?.toString() ?? '',
      userId: map['user_id']?.toString() ?? '',
      permissionLevel: map['permission_level']?.toString() ?? 'view',
      grantedBy: map['granted_by']?.toString() ?? '',
      userEmail: (map['users'] is Map) ? map['users']['email']?.toString() : null,
      userDisplayName: (map['users'] is Map) ? map['users']['display_name']?.toString() : null,
      createdAt: map['created_at'] != null
          ? DateTime.tryParse(map['created_at'].toString())
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'document_id': documentId,
      'user_id': userId,
      'permission_level': permissionLevel,
      'granted_by': grantedBy,
      if (createdAt != null) 'created_at': createdAt!.toIso8601String(),
    };
  }
}
