import '../../domain/entities/cloud_document.dart';
import 'document_permission_model.dart';

class CloudDocumentModel {
  final String id;
  final String ownerId;
  final String? ownerEmail;
  final String? ownerName;
  final String title;
  final String description;
  final String category;
  final String? fileUrl;
  final String? fileName;
  final String fileType;
  final int fileSize;
  final String? storagePath;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<DocumentPermissionModel> permissions;

  const CloudDocumentModel({
    required this.id,
    required this.ownerId,
    this.ownerEmail,
    this.ownerName,
    required this.title,
    required this.description,
    required this.category,
    this.fileUrl,
    this.fileName,
    required this.fileType,
    required this.fileSize,
    this.storagePath,
    required this.createdAt,
    required this.updatedAt,
    this.permissions = const [],
  });

  factory CloudDocumentModel.fromEntity(CloudDocument doc) {
    return CloudDocumentModel(
      id: doc.id,
      ownerId: doc.ownerId,
      ownerEmail: doc.ownerEmail,
      ownerName: doc.ownerName,
      title: doc.title,
      description: doc.description,
      category: doc.category,
      fileUrl: doc.fileUrl,
      fileName: doc.fileName,
      fileType: doc.fileType,
      fileSize: doc.fileSize,
      storagePath: doc.storagePath,
      createdAt: doc.createdAt,
      updatedAt: doc.updatedAt,
      permissions: doc.permissions
          .map((p) => DocumentPermissionModel.fromEntity(p))
          .toList(),
    );
  }

  CloudDocument toEntity() {
    return CloudDocument(
      id: id,
      ownerId: ownerId,
      ownerEmail: ownerEmail,
      ownerName: ownerName,
      title: title,
      description: description,
      category: category,
      fileUrl: fileUrl,
      fileName: fileName,
      fileType: fileType,
      fileSize: fileSize,
      storagePath: storagePath,
      createdAt: createdAt,
      updatedAt: updatedAt,
      permissions: permissions.map((p) => p.toEntity()).toList(),
    );
  }

  factory CloudDocumentModel.fromMap(
    Map<String, dynamic> map, {
    List<DocumentPermissionModel>? permissionsList,
  }) {
    List<DocumentPermissionModel> parsedPerms = permissionsList ?? [];
    if (map['document_permissions'] is List) {
      parsedPerms = (map['document_permissions'] as List)
          .map((item) => DocumentPermissionModel.fromMap(
              Map<String, dynamic>.from(item as Map)))
          .toList();
    }

    String? ownerEmail;
    String? ownerName;
    if (map['users'] is Map) {
      ownerEmail = map['users']['email']?.toString();
      ownerName = map['users']['display_name']?.toString();
    }

    return CloudDocumentModel(
      id: map['id']?.toString() ?? '',
      ownerId: map['owner_id']?.toString() ?? '',
      ownerEmail: ownerEmail,
      ownerName: ownerName,
      title: map['title']?.toString() ?? '',
      description: map['description']?.toString() ?? '',
      category: map['category']?.toString() ?? '',
      fileUrl: map['file_url']?.toString(),
      fileName: map['file_name']?.toString(),
      fileType: map['file_type']?.toString() ?? 'PDF',
      fileSize: (map['file_size'] is num) ? (map['file_size'] as num).toInt() : 0,
      storagePath: map['storage_path']?.toString(),
      createdAt: map['created_at'] != null
          ? DateTime.tryParse(map['created_at'].toString()) ?? DateTime.now()
          : DateTime.now(),
      updatedAt: map['updated_at'] != null
          ? DateTime.tryParse(map['updated_at'].toString()) ?? DateTime.now()
          : DateTime.now(),
      permissions: parsedPerms,
    );
  }

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'owner_id': ownerId,
      'title': title,
      'description': description,
      'category': category,
      'file_url': fileUrl,
      'file_name': fileName,
      'file_type': fileType,
      'file_size': fileSize,
      'storage_path': storagePath,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
    if (id.trim().isNotEmpty) {
      map['id'] = id.trim();
    }
    return map;
  }
}
