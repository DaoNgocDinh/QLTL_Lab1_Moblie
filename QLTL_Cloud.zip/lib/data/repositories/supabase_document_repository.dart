import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/cloud_document.dart';
import '../../domain/entities/document_permission.dart';
import '../../domain/repositories/cloud_document_repository.dart';
import '../models/cloud_document_model.dart';
import '../models/document_permission_model.dart';

class SupabaseDocumentRepository implements CloudDocumentRepository {
  SupabaseClient get _client => Supabase.instance.client;

  @override
  Future<List<CloudDocument>> getDocumentsForUser(
    String userId, {
    String? category,
    String? query,
    DocumentTabFilter tab = DocumentTabFilter.all,
  }) async {
    try {
      // Supabase tự động áp dụng RLS documents_select_policy:
      // user chỉ lấy được documents mà họ là owner hoặc được phân quyền.
      var request = _client.from('documents').select('''
        *,
        users:owner_id(id, email, display_name),
        document_permissions(*, users:user_id(id, email, display_name))
      ''');

      if (category != null && category.isNotEmpty && category != 'Tất cả') {
        request = request.eq('category', category);
      }

      if (query != null && query.trim().isNotEmpty) {
        request = request.ilike('title', '%${query.trim()}%');
      }

      final response = await request.order('updated_at', ascending: false);
      final List<dynamic> data = response as List<dynamic>;

      List<CloudDocument> list = data
          .map((item) => CloudDocumentModel.fromMap(
              Map<String, dynamic>.from(item as Map)).toEntity())
          .toList();

      // Email của người dùng hiện tại (nếu thuộc demoUsers)
      String userEmail = '';
      for (final u in AppConfig.demoUsers) {
        if (u.id == userId) {
          userEmail = u.email;
          break;
        }
      }

      bool isMine(CloudDocument d) =>
          d.ownerId == userId ||
          (userEmail.isNotEmpty &&
              d.ownerEmail?.toLowerCase() == userEmail.toLowerCase()) ||
          (userId == 'user_alice_001' && d.ownerId == 'user_alice_001') ||
          (d.ownerId == 'user_alice_001' &&
              (userId.contains('alice') || userEmail.contains('alice')));

      bool isSharedToMe(CloudDocument d) =>
          !isMine(d) &&
          d.permissions.any((p) =>
              p.userId == userId ||
              (userEmail.isNotEmpty &&
                  p.userEmail?.toLowerCase() == userEmail.toLowerCase()) ||
              (p.userId == 'user_bob_002' &&
                  (userId == 'user_bob_002' ||
                      userId.contains('bob') ||
                      userEmail.contains('bob'))));

      if (tab == DocumentTabFilter.mine) {
        list = list.where(isMine).toList();
      } else if (tab == DocumentTabFilter.shared) {
        list = list.where(isSharedToMe).toList();
      } else {
        // Tab All: hiển thị tài liệu người dùng sở hữu HOẶC được phân quyền
        list = list.where((d) => isMine(d) || isSharedToMe(d)).toList();
      }

      return list;
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException('RLS Denied: ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<CloudDocument> getDocumentById(String documentId, String userId) async {
    try {
      final response = await _client
          .from('documents')
          .select('''
            *,
            users:owner_id(id, email, display_name),
            document_permissions(*, users:user_id(id, email, display_name))
          ''')
          .eq('id', documentId)
          .single();

      return CloudDocumentModel.fromMap(response).toEntity();
    } on PostgrestException catch (e) {
      if (e.code == '42501' || e.code == 'PGRST116') {
        throw PermissionDeniedException(
            'Truy cập bị từ chối hoặc không tìm thấy tài liệu (RLS): ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<CloudDocument> createDocument(
    CloudDocument document,
    String requestingUserId,
  ) async {
    try {
      final docId =
          document.id.trim().isEmpty ? const Uuid().v4() : document.id.trim();
      final model = CloudDocumentModel.fromEntity(
        document.copyWith(id: docId, ownerId: requestingUserId),
      );
      final response =
          await _client.from('documents').insert(model.toMap()).select().single();
      return CloudDocumentModel.fromMap(response).toEntity();
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException('RLS Insert Denied: ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<CloudDocument> updateDocument(
    CloudDocument document,
    String requestingUserId,
  ) async {
    try {
      final model = CloudDocumentModel.fromEntity(document);
      final response = await _client
          .from('documents')
          .update(model.toMap())
          .eq('id', document.id)
          .select()
          .single();
      return CloudDocumentModel.fromMap(response).toEntity();
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException(
            'Bạn không có quyền chỉnh sửa tài liệu này (RLS Update Denied): ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<void> deleteDocument(String documentId, String requestingUserId) async {
    try {
      await _client.from('documents').delete().eq('id', documentId);
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException(
            'Chỉ có Chủ sở hữu mới có quyền xóa tài liệu (RLS Delete Denied): ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<DocumentPermission> shareDocument({
    required String documentId,
    required String targetUserId,
    required String permissionLevel,
    required String requestingUserId,
  }) async {
    try {
      final response = await _client
          .from('document_permissions')
          .upsert({
            'document_id': documentId,
            'user_id': targetUserId,
            'permission_level': permissionLevel,
            'granted_by': requestingUserId,
            'updated_at': DateTime.now().toIso8601String(),
          }, onConflict: 'document_id, user_id')
          .select('''*, users:user_id(id, email, display_name)''')
          .single();

      return DocumentPermissionModel.fromMap(response).toEntity();
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException(
            'Chỉ Chủ sở hữu mới được cấp quyền chia sẻ (RLS Denied): ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<void> revokePermission({
    required String documentId,
    required String targetUserId,
    required String requestingUserId,
  }) async {
    try {
      await _client
          .from('document_permissions')
          .delete()
          .eq('document_id', documentId)
          .eq('user_id', targetUserId);
    } on PostgrestException catch (e) {
      if (e.code == '42501') {
        throw PermissionDeniedException(
            'Chỉ Chủ sở hữu mới được thu hồi quyền (RLS Denied): ${e.message}');
      }
      rethrow;
    }
  }

  @override
  Future<List<DocumentPermission>> getDocumentPermissions(
    String documentId,
    String requestingUserId,
  ) async {
    final doc = await getDocumentById(documentId, requestingUserId);
    return doc.permissions;
  }

  @override
  Future<Map<String, int>> getDocumentCounts(String userId) async {
    final docs = await getDocumentsForUser(userId);
    final Map<String, int> counts = {'Tất cả': docs.length};
    for (final cat in AppConfig.categories) {
      if (cat != 'Tất cả') {
        counts[cat] = docs.where((d) => d.category == cat).length;
      }
    }
    return counts;
  }

  /// Kiểm tra kết nối tới Supabase REST API
  static Future<Map<String, dynamic>> testConnection(String url, String anonKey) async {
    try {
      final cleanUrl = AppConfig.sanitizeUrl(url);
      final endpoint = Uri.parse('$cleanUrl/rest/v1/users?select=id&limit=1');
      final response = await http.get(
        endpoint,
        headers: {
          'apikey': anonKey.trim(),
          'Authorization': 'Bearer ${anonKey.trim()}',
        },
      );

      if (response.statusCode == 200 || response.statusCode == 206) {
        // Kiểm tra tiếp bảng documents và phát hiện chính sách RLS
        try {
          final docEndpoint = Uri.parse('$cleanUrl/rest/v1/documents?select=id&limit=1');
          final docResponse = await http.get(
            docEndpoint,
            headers: {
              'apikey': anonKey.trim(),
              'Authorization': 'Bearer ${anonKey.trim()}',
            },
          );
          if (docResponse.body.contains('infinite recursion') ||
              docResponse.body.contains('42P17')) {
            return {
              'success': false,
              'needsPolicyFix': true,
              'message': '🟡 Đã kết nối Supabase và bảng users OK!\n'
                  '⚠️ Nhưng phát hiện lỗi đệ quy chính sách RLS (42P17) trên bảng documents.\n'
                  '👉 Vui lòng mở Supabase Dashboard -> SQL Editor và chạy bản cập nhật RLS policy.',
            };
          }
        } catch (_) {}

        return {
          'success': true,
          'message': '🟢 Kết nối Supabase thành công! Bảng users và database đã sẵn sàng.',
        };
      } else if (response.statusCode == 404 ||
          response.body.contains('relation "users" does not exist') ||
          response.body.contains('PGRST205')) {
        return {
          'success': true,
          'needsSchema': true,
          'message': '🟡 Kết nối máy chủ Supabase thành công! Tuy nhiên bảng "users" chưa được tạo.\n'
              '👉 Vui lòng mở mục SQL Editor trên Supabase Dashboard và bấm "Run" script supabase_schema.sql.',
        };
      } else if (response.statusCode == 401 || response.statusCode == 403) {
        return {
          'success': false,
          'message': '🔴 Lỗi xác thực (HTTP ${response.statusCode}): Anon Key không chính xác hoặc quyền truy cập bị chặn.',
        };
      } else {
        return {
          'success': false,
          'message': 'Mã phản hồi từ Supabase: HTTP ${response.statusCode}',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message': 'Không thể kết nối đến URL Supabase: $e',
      };
    }
  }

  /// Đồng bộ người dùng Firebase sang bảng users của Supabase
  static Future<bool> syncFirebaseUser({
    required String userId,
    required String email,
    required String displayName,
    String? avatarUrl,
  }) async {
    try {
      if (AppConfig.backendMode != CloudBackendMode.liveCloud) return true;
      final cleanUrl = AppConfig.sanitizeUrl(AppConfig.supabaseUrl);
      final endpoint = Uri.parse('$cleanUrl/rest/v1/users');
      final response = await http.post(
        endpoint,
        headers: {
          'apikey': AppConfig.supabaseAnonKey.trim(),
          'Authorization': 'Bearer ${AppConfig.supabaseAnonKey.trim()}',
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates',
        },
        body: jsonEncode({
          'id': userId,
          'email': email,
          'display_name': displayName,
          'avatar_url': avatarUrl,
          'updated_at': DateTime.now().toIso8601String(),
        }),
      );
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (_) {
      return false;
    }
  }
}
