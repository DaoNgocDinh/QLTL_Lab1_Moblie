import 'dart:async';
import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';
import '../dao/document_dao.dart';
import '../models/document_model.dart';

class DocumentRepositoryImpl implements DocumentRepository {
  final DocumentDao dao;
  final StreamController<void> _streamController = StreamController<void>.broadcast();

  DocumentRepositoryImpl(this.dao);

  void _notifyChange() {
    if (!_streamController.isClosed) {
      _streamController.add(null);
    }
  }

  @override
  Future<List<Document>> getAllDocuments({String? category}) async {
    final list = await dao.getAllDocuments(category: category);
    return list.map((map) => DocumentModel.fromMap(map).toEntity()).toList();
  }

  @override
  Future<Document?> getDocumentById(int id) async {
    final map = await dao.getDocumentById(id);
    if (map == null) return null;
    return DocumentModel.fromMap(map).toEntity();
  }

  @override
  Future<int> addDocument(Document document) async {
    final model = DocumentModel.fromEntity(document);
    final id = await dao.insertDocument(model.toMap());
    _notifyChange();
    return id;
  }

  @override
  Future<bool> updateDocument(Document document) async {
    if (document.id == null) {
      throw ArgumentError('Không thể cập nhật tài liệu khi id rỗng');
    }
    final model = DocumentModel.fromEntity(document);
    final rowsAffected = await dao.updateDocument(document.id!, model.toMap());
    final success = rowsAffected > 0;
    if (success) {
      _notifyChange();
    }
    return success;
  }

  @override
  Future<int> deleteDocument(int id) async {
    final rows = await dao.deleteDocument(id);
    if (rows > 0) {
      _notifyChange();
    }
    return rows;
  }

  @override
  Future<List<Document>> searchDocuments(String keyword, {String? category}) async {
    final list = await dao.searchDocuments(keyword, category: category);
    return list.map((map) => DocumentModel.fromMap(map).toEntity()).toList();
  }

  @override
  Future<Map<String, int>> countByCategory() {
    return dao.countByCategory();
  }

  @override
  Stream<List<Document>> watchAllDocuments({String? category}) async* {
    // Initial emission
    yield await getAllDocuments(category: category);
    // Listen for subsequent changes
    await for (final _ in _streamController.stream) {
      yield await getAllDocuments(category: category);
    }
  }

  void dispose() {
    _streamController.close();
  }
}
