import 'package:uuid/uuid.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/entities/cloud_document.dart';
import '../../domain/entities/document_permission.dart';
import '../../domain/repositories/cloud_document_repository.dart';

class InMemoryCloudDocumentRepository implements CloudDocumentRepository {
  final List<CloudDocument> _documents = [];
  final List<DocumentPermission> _permissions = [];
  final Uuid _uuid = const Uuid();

  InMemoryCloudDocumentRepository() {
    _seedInitialData();
  }

  void _seedInitialData() {
    // 1. Phân quyền mẫu: Alice chia sẻ doc_001 cho Bob với quyền 'view'
    final initialPerm1 = DocumentPermission(
      id: 'perm_001',
      documentId: 'doc_001',
      userId: AppConfig.userBob.id,
      userEmail: AppConfig.userBob.email,
      userDisplayName: AppConfig.userBob.displayName,
      permissionLevel: 'view',
      grantedBy: AppConfig.userAlice.id,
      createdAt: DateTime.now().subtract(const Duration(days: 2)),
    );
    _permissions.add(initialPerm1);

    // 2. Tài liệu mẫu do Alice (Owner) tạo
    _documents.addAll([
      CloudDocument(
        id: 'doc_001',
        ownerId: AppConfig.userAlice.id,
        ownerEmail: AppConfig.userAlice.email,
        ownerName: AppConfig.userAlice.displayName,
        title: 'GiaoTrinh_LapTrinh_Flutter_Cloud.pdf',
        description: 'Giáo trình toàn diện về Flutter, Firebase Authentication và Supabase RLS.',
        category: 'Bài giảng',
        fileUrl:
            'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_001.pdf?alt=media',
        fileName: 'GiaoTrinh_LapTrinh_Flutter_Cloud.pdf',
        fileType: 'PDF',
        fileSize: 4194304, // 4 MB
        storagePath: 'documents/user_alice_001/doc_001.pdf',
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
        updatedAt: DateTime.now().subtract(const Duration(days: 2)),
        permissions: [initialPerm1],
      ),
      CloudDocument(
        id: 'doc_002',
        ownerId: AppConfig.userAlice.id,
        ownerEmail: AppConfig.userAlice.email,
        ownerName: AppConfig.userAlice.displayName,
        title: 'BaoCao_KienTruc_HeThong_Lab2.docx',
        description: 'Bản phân tích kiến trúc Clean Architecture, RLS Policy và Firebase Storage.',
        category: 'Đồ án',
        fileUrl:
            'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_002.docx?alt=media',
        fileName: 'BaoCao_KienTruc_HeThong_Lab2.docx',
        fileType: 'DOCX',
        fileSize: 2097152, // 2 MB
        storagePath: 'documents/user_alice_001/doc_002.docx',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        updatedAt: DateTime.now().subtract(const Duration(days: 1)),
        permissions: const [],
      ),
      CloudDocument(
        id: 'doc_003',
        ownerId: AppConfig.userAlice.id,
        ownerEmail: AppConfig.userAlice.email,
        ownerName: AppConfig.userAlice.displayName,
        title: 'TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx',
        description: 'Slide tóm tắt kiến thức PostgreSQL, Partitioning và Row Level Security.',
        category: 'Tài liệu ôn thi',
        fileUrl:
            'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_003.pptx?alt=media',
        fileName: 'TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx',
        fileType: 'PPTX',
        fileSize: 8388608, // 8 MB
        storagePath: 'documents/user_alice_001/doc_003.pptx',
        createdAt: DateTime.now().subtract(const Duration(hours: 12)),
        updatedAt: DateTime.now().subtract(const Duration(hours: 12)),
        permissions: const [],
      ),
    ]);
  }

  /// Trợ giúp: gán danh sách permissions mới nhất cho document
  CloudDocument _attachPermissions(CloudDocument doc) {
    final docPerms = _permissions.where((p) => p.documentId == doc.id).toList();
    return doc.copyWith(permissions: docPerms);
  }

  @override
  Future<List<CloudDocument>> getDocumentsForUser(
    String userId, {
    String? category,
    String? query,
    DocumentTabFilter tab = DocumentTabFilter.all,
  }) async {
    // RLS SELECT POLICY:
    // User chỉ được xem tài liệu nếu: (ownerId == userId) HOẶC (có trong permissions của document)
    var accessibleDocs = _documents.map(_attachPermissions).where((doc) {
      final isOwner = doc.ownerId == userId;
      final isSharedWithUser = doc.permissions.any((p) => p.userId == userId);
      return isOwner || isSharedWithUser;
    }).toList();

    // Lọc theo Tab (Tất cả / Của tôi / Được chia sẻ)
    if (tab == DocumentTabFilter.mine) {
      accessibleDocs =
          accessibleDocs.where((doc) => doc.ownerId == userId).toList();
    } else if (tab == DocumentTabFilter.shared) {
      accessibleDocs = accessibleDocs
          .where((doc) =>
              doc.ownerId != userId &&
              doc.permissions.any((p) => p.userId == userId))
          .toList();
    }

    // Lọc theo Danh mục
    if (category != null && category.isNotEmpty && category != 'Tất cả') {
      accessibleDocs =
          accessibleDocs.where((doc) => doc.category == category).toList();
    }

    // Lọc theo từ khóa tìm kiếm
    if (query != null && query.trim().isNotEmpty) {
      final q = query.toLowerCase().trim();
      accessibleDocs = accessibleDocs.where((doc) {
        final matchTitle = doc.title.toLowerCase().contains(q);
        final matchDesc = doc.description.toLowerCase().contains(q);
        final matchCategory = doc.category.toLowerCase().contains(q);
        final matchFileName = doc.fileName?.toLowerCase().contains(q) ?? false;
        final matchAuthor = doc.ownerName?.toLowerCase().contains(q) ?? false;
        return matchTitle ||
            matchDesc ||
            matchCategory ||
            matchFileName ||
            matchAuthor;
      }).toList();
    }

    // Sắp xếp thời gian cập nhật mới nhất lên đầu
    accessibleDocs.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return List.unmodifiable(accessibleDocs);
  }

  @override
  Future<CloudDocument> getDocumentById(String documentId, String userId) async {
    final index = _documents.indexWhere((d) => d.id == documentId);
    if (index == -1) {
      throw Exception('Không tìm thấy tài liệu có mã $documentId');
    }
    final doc = _attachPermissions(_documents[index]);

    // RLS SELECT ENFORCEMENT
    final isOwner = doc.ownerId == userId;
    final isPermitted = doc.permissions.any((p) => p.userId == userId);
    if (!isOwner && !isPermitted) {
      throw const PermissionDeniedException(
        'Truy cập bị từ chối: Bạn không có quyền xem tài liệu này (RLS Select Denied).',
      );
    }

    return doc;
  }

  @override
  Future<CloudDocument> createDocument(
    CloudDocument document,
    String requestingUserId,
  ) async {
    // RLS INSERT POLICY:
    // Người dùng chỉ có quyền tạo tài liệu với chính ID của mình làm owner_id
    final docId = document.id.isEmpty ? _uuid.v4() : document.id;
    final now = DateTime.now();

    final created = document.copyWith(
      id: docId,
      ownerId: requestingUserId,
      createdAt: now,
      updatedAt: now,
      permissions: const [],
    );

    _documents.add(created);
    return created;
  }

  @override
  Future<CloudDocument> updateDocument(
    CloudDocument document,
    String requestingUserId,
  ) async {
    final index = _documents.indexWhere((d) => d.id == document.id);
    if (index == -1) {
      throw Exception('Không tìm thấy tài liệu để cập nhật: ${document.id}');
    }

    final existing = _attachPermissions(_documents[index]);

    // RLS UPDATE POLICY:
    // User chỉ được sửa nếu:
    // (a) Là Owner (ownerId == requestingUserId)
    // HOẶC (b) Được chia sẻ với quyền 'edit'
    final isOwner = existing.ownerId == requestingUserId;
    final hasEditPermission = existing.permissions.any(
      (p) => p.userId == requestingUserId && p.permissionLevel == 'edit',
    );

    if (!isOwner && !hasEditPermission) {
      throw const PermissionDeniedException(
        'Truy cập bị từ chối: Bạn không có quyền chỉnh sửa tài liệu này. Cần quyền Chủ sở hữu hoặc Quyền Chỉnh sửa (RLS Update Denied).',
      );
    }

    final updated = existing.copyWith(
      title: document.title,
      description: document.description,
      category: document.category,
      fileUrl: document.fileUrl ?? existing.fileUrl,
      fileName: document.fileName ?? existing.fileName,
      fileType: document.fileType.isNotEmpty ? document.fileType : existing.fileType,
      fileSize: document.fileSize > 0 ? document.fileSize : existing.fileSize,
      storagePath: document.storagePath ?? existing.storagePath,
      updatedAt: DateTime.now(),
    );

    _documents[index] = updated;
    return _attachPermissions(updated);
  }

  @override
  Future<void> deleteDocument(String documentId, String requestingUserId) async {
    final index = _documents.indexWhere((d) => d.id == documentId);
    if (index == -1) {
      throw Exception('Không tìm thấy tài liệu để xóa: $documentId');
    }

    final existing = _documents[index];

    // RLS DELETE POLICY:
    // DUY NHẤT Owner mới có quyền xóa tài liệu
    if (existing.ownerId != requestingUserId) {
      throw const PermissionDeniedException(
        'Truy cập bị từ chối: Chỉ có Chủ sở hữu mới có quyền xóa tài liệu này (RLS Delete Denied).',
      );
    }

    _documents.removeAt(index);
    _permissions.removeWhere((p) => p.documentId == documentId);
  }

  @override
  Future<DocumentPermission> shareDocument({
    required String documentId,
    required String targetUserId,
    required String permissionLevel,
    required String requestingUserId,
  }) async {
    final docIndex = _documents.indexWhere((d) => d.id == documentId);
    if (docIndex == -1) {
      throw Exception('Không tìm thấy tài liệu: $documentId');
    }

    final doc = _documents[docIndex];

    // RLS PERMISSION INSERT POLICY:
    // DUY NHẤT Owner mới có quyền cấp quyền chia sẻ tài liệu
    if (doc.ownerId != requestingUserId) {
      throw const PermissionDeniedException(
        'Truy cập bị từ chối: Chỉ có Chủ sở hữu mới có quyền chia sẻ tài liệu (RLS Permission Insert Denied).',
      );
    }

    // Tìm thông tin người nhận quyền
    final targetUser = AppConfig.demoUsers.firstWhere(
      (u) => u.id == targetUserId,
      orElse: () => AppUser(
        id: targetUserId,
        email: 'user_$targetUserId@student.edu.vn',
        displayName: 'Người dùng $targetUserId',
      ),
    );

    // Kiểm tra xem đã tồn tại permission chưa (UPSERT)
    final existingPermIndex = _permissions.indexWhere(
      (p) => p.documentId == documentId && p.userId == targetUserId,
    );

    final now = DateTime.now();
    DocumentPermission permission;

    if (existingPermIndex != -1) {
      permission = _permissions[existingPermIndex].copyWith(
        permissionLevel: permissionLevel,
        grantedBy: requestingUserId,
        createdAt: now,
      );
      _permissions[existingPermIndex] = permission;
    } else {
      permission = DocumentPermission(
        id: _uuid.v4(),
        documentId: documentId,
        userId: targetUserId,
        userEmail: targetUser.email,
        userDisplayName: targetUser.displayName,
        permissionLevel: permissionLevel,
        grantedBy: requestingUserId,
        createdAt: now,
      );
      _permissions.add(permission);
    }

    return permission;
  }

  @override
  Future<void> revokePermission({
    required String documentId,
    required String targetUserId,
    required String requestingUserId,
  }) async {
    final docIndex = _documents.indexWhere((d) => d.id == documentId);
    if (docIndex == -1) {
      throw Exception('Không tìm thấy tài liệu: $documentId');
    }

    final doc = _documents[docIndex];

    // RLS PERMISSION DELETE POLICY:
    // DUY NHẤT Owner mới có quyền thu hồi quyền chia sẻ
    if (doc.ownerId != requestingUserId) {
      throw const PermissionDeniedException(
        'Truy cập bị từ chối: Chỉ có Chủ sở hữu mới có quyền thu hồi quyền chia sẻ (RLS Permission Delete Denied).',
      );
    }

    _permissions.removeWhere(
      (p) => p.documentId == documentId && p.userId == targetUserId,
    );
  }

  @override
  Future<List<DocumentPermission>> getDocumentPermissions(
    String documentId,
    String requestingUserId,
  ) async {
    final doc = await getDocumentById(documentId, requestingUserId);
    return List.unmodifiable(doc.permissions);
  }

  @override
  Future<Map<String, int>> getDocumentCounts(String userId) async {
    final docs = await getDocumentsForUser(userId);
    final Map<String, int> counts = {'Tất cả': docs.length};
    for (final cat in AppConfig.categories) {
      if (cat != 'Tất cả') {
        counts[cat] = docs.where((d) => d.category == cat).length;
      }
    }
    return counts;
  }
}
