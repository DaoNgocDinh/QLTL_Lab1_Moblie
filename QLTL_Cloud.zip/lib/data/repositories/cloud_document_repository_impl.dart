import '../../core/config/app_config.dart';
import '../../domain/entities/cloud_document.dart';
import '../../domain/entities/document_permission.dart';
import '../../domain/repositories/cloud_document_repository.dart';
import 'in_memory_cloud_document_repository.dart';
import 'supabase_document_repository.dart';

class CloudDocumentRepositoryImpl implements CloudDocumentRepository {
  final InMemoryCloudDocumentRepository _inMemoryRepo;
  final SupabaseDocumentRepository _supabaseRepo;

  CloudDocumentRepositoryImpl({
    InMemoryCloudDocumentRepository? inMemoryRepo,
    SupabaseDocumentRepository? supabaseRepo,
  })  : _inMemoryRepo = inMemoryRepo ?? InMemoryCloudDocumentRepository(),
        _supabaseRepo = supabaseRepo ?? SupabaseDocumentRepository();

  CloudDocumentRepository get _activeRepo {
    if (AppConfig.backendMode == CloudBackendMode.liveCloud) {
      return _supabaseRepo;
    }
    return _inMemoryRepo;
  }

  @override
  Future<List<CloudDocument>> getDocumentsForUser(
    String userId, {
    String? category,
    String? query,
    DocumentTabFilter tab = DocumentTabFilter.all,
  }) {
    return _activeRepo.getDocumentsForUser(
      userId,
      category: category,
      query: query,
      tab: tab,
    );
  }

  @override
  Future<CloudDocument> getDocumentById(String documentId, String userId) {
    return _activeRepo.getDocumentById(documentId, userId);
  }

  @override
  Future<CloudDocument> createDocument(
    CloudDocument document,
    String requestingUserId,
  ) {
    return _activeRepo.createDocument(document, requestingUserId);
  }

  @override
  Future<CloudDocument> updateDocument(
    CloudDocument document,
    String requestingUserId,
  ) {
    return _activeRepo.updateDocument(document, requestingUserId);
  }

  @override
  Future<void> deleteDocument(String documentId, String requestingUserId) {
    return _activeRepo.deleteDocument(documentId, requestingUserId);
  }

  @override
  Future<DocumentPermission> shareDocument({
    required String documentId,
    required String targetUserId,
    required String permissionLevel,
    required String requestingUserId,
  }) {
    return _activeRepo.shareDocument(
      documentId: documentId,
      targetUserId: targetUserId,
      permissionLevel: permissionLevel,
      requestingUserId: requestingUserId,
    );
  }

  @override
  Future<void> revokePermission({
    required String documentId,
    required String targetUserId,
    required String requestingUserId,
  }) {
    return _activeRepo.revokePermission(
      documentId: documentId,
      targetUserId: targetUserId,
      requestingUserId: requestingUserId,
    );
  }

  @override
  Future<List<DocumentPermission>> getDocumentPermissions(
    String documentId,
    String requestingUserId,
  ) {
    return _activeRepo.getDocumentPermissions(documentId, requestingUserId);
  }

  @override
  Future<Map<String, int>> getDocumentCounts(String userId) {
    return _activeRepo.getDocumentCounts(userId);
  }
}
