import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../../domain/repositories/storage_repository.dart';
import '../../firebase_options.dart';

class FirebaseStorageServiceImpl implements StorageRepository {
  final http.Client _httpClient;

  FirebaseStorageServiceImpl({http.Client? httpClient})
      : _httpClient = httpClient ?? http.Client();

  @override
  Future<CloudUploadedFile> uploadDocumentFile({
    required String userId,
    required String fileName,
    required List<int> bytes,
    String? mimeType,
  }) async {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    // Cấu trúc thư mục Firebase Storage theo chuẩn Checklist mục 2:
    // documents/{userId}/{timestamp}_{sanitized_fileName}
    final sanitizedName = fileName.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
    final storagePath = 'documents/$userId/${timestamp}_$sanitizedName';

    // Xác định định dạng tệp (PDF, DOCX, PPTX, XLSX, TXT, ZIP, ...)
    final extension = fileName.contains('.')
        ? fileName.split('.').last.toUpperCase()
        : 'PDF';

    final fileSize = bytes.length;
    String downloadUrl = '';
    final bucket = DefaultFirebaseOptions.web.storageBucket ?? 'qltl-cloud-doc.firebasestorage.app';

    // 1. Thử qua Firebase Storage SDK nếu khả dụng (Web & Mobile)
    if (kIsWeb ||
        defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS) {
      if (Firebase.apps.isNotEmpty) {
        try {
          debugPrint('Bắt đầu tải lên Firebase Storage SDK: $storagePath');
          final ref = FirebaseStorage.instance.ref().child(storagePath);
          final metadata = SettableMetadata(
            contentType: mimeType ?? _guessMimeType(extension),
            customMetadata: {'uploadedBy': userId},
          );
          final uploadTask =
              await ref.putData(Uint8List.fromList(bytes), metadata);
          downloadUrl = await uploadTask.ref.getDownloadURL();
          debugPrint('Tải lên Firebase Storage SDK thành công: $downloadUrl');
        } catch (e) {
          debugPrint('Firebase Storage SDK upload notice: $e');
        }
      }
    }

    // 2. Thử qua Firebase Storage REST API (hoạt động 100% trên Windows Desktop & mọi nền tảng)
    if (downloadUrl.isEmpty) {
      try {
        final encodedName = Uri.encodeQueryComponent(storagePath);
        final restUrl = Uri.parse(
          'https://firebasestorage.googleapis.com/v0/b/$bucket/o?uploadType=media&name=$encodedName',
        );

        final response = await _httpClient.post(
          restUrl,
          headers: {
            'Content-Type': mimeType ?? _guessMimeType(extension),
          },
          body: bytes,
        );

        if (response.statusCode == 200 && response.body.isNotEmpty) {
          final data = jsonDecode(response.body) as Map<String, dynamic>;
          final token = data['downloadTokens'] as String?;
          if (token != null && token.isNotEmpty) {
            downloadUrl =
                'https://firebasestorage.googleapis.com/v0/b/$bucket/o/${Uri.encodeComponent(storagePath)}?alt=media&token=$token';
          } else {
            downloadUrl =
                'https://firebasestorage.googleapis.com/v0/b/$bucket/o/${Uri.encodeComponent(storagePath)}?alt=media';
          }
          debugPrint('Tải lên Firebase Storage REST thành công: $downloadUrl');
        } else if (response.statusCode == 404) {
          debugPrint(
              'Firebase Storage Notice: Bucket "$bucket" chưa được tạo trên Firebase Console (Lỗi 404: The specified bucket does not exist).\n'
              '👉 Hãy vào Firebase Console -> Build -> Storage -> Bấm "Get Started" để kích hoạt!');
        } else {
          debugPrint('Firebase Storage REST upload response code: ${response.statusCode}');
        }
      } catch (e) {
        debugPrint('Firebase Storage REST upload notice: $e');
      }
    }

    // 3. Nếu chưa kích hoạt bucket hoặc chạy ở chế độ offline / mock,
    // sinh URL chuẩn định dạng Firebase Storage để tiếp tục kiểm thử không bị gián đoạn
    if (downloadUrl.isEmpty) {
      downloadUrl =
          'https://firebasestorage.googleapis.com/v0/b/$bucket/o/${Uri.encodeComponent(storagePath)}?alt=media';
    }

    return CloudUploadedFile(
      fileUrl: downloadUrl,
      storagePath: storagePath,
      fileName: fileName,
      fileType: extension,
      fileSize: fileSize,
    );
  }

  /// Kiểm tra trạng thái thực tế của Bucket trên Firebase Storage
  static Future<Map<String, dynamic>> checkBucketStatus({http.Client? client}) async {
    final httpClient = client ?? http.Client();
    final bucket = DefaultFirebaseOptions.web.storageBucket ?? 'qltl-cloud-doc.firebasestorage.app';
    try {
      final url = Uri.parse('https://firebasestorage.googleapis.com/v0/b/$bucket/o');
      final res = await httpClient.get(url);
      if (res.statusCode == 200) {
        return {
          'isReady': true,
          'bucket': bucket,
          'statusCode': 200,
          'message': 'Bucket đã kích hoạt và sẵn sàng lưu trữ tệp.',
        };
      } else if (res.statusCode == 404) {
        return {
          'isReady': false,
          'bucket': bucket,
          'statusCode': 404,
          'message': 'Bucket chưa được khởi tạo trên Firebase Console.\nCần vào tab Storage và bấm "Get Started" (Bắt đầu).',
        };
      } else if (res.statusCode == 403) {
        return {
          'isReady': true,
          'bucket': bucket,
          'statusCode': 403,
          'message': 'Bucket đã tồn tại trên Firebase nhưng Rules đang hạn chế quyền truy cập.',
        };
      } else {
        return {
          'isReady': false,
          'bucket': bucket,
          'statusCode': res.statusCode,
          'message': 'Mã phản hồi từ Firebase Storage: HTTP ${res.statusCode}',
        };
      }
    } catch (e) {
      return {
        'isReady': false,
        'bucket': bucket,
        'statusCode': 0,
        'message': 'Không thể kết nối đến máy chủ Firebase: $e',
      };
    } finally {
      if (client == null) {
        httpClient.close();
      }
    }
  }

  String _guessMimeType(String ext) {
    switch (ext.toUpperCase()) {
      case 'PDF':
        return 'application/pdf';
      case 'DOC':
      case 'DOCX':
        return 'application/msword';
      case 'PPT':
      case 'PPTX':
        return 'application/vnd.ms-powerpoint';
      case 'XLS':
      case 'XLSX':
        return 'application/vnd.ms-excel';
      case 'PNG':
        return 'image/png';
      case 'JPG':
      case 'JPEG':
        return 'image/jpeg';
      default:
        return 'application/octet-stream';
    }
  }

  @override
  Future<void> deleteDocumentFile(String storagePath) async {
    if (kIsWeb ||
        defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS) {
      if (Firebase.apps.isNotEmpty) {
        try {
          await FirebaseStorage.instance.ref().child(storagePath).delete();
          return;
        } catch (_) {}
      }
    }

    try {
      final bucket = DefaultFirebaseOptions.web.storageBucket ?? 'qltl-cloud-doc.firebasestorage.app';
      final encodedPath = Uri.encodeComponent(storagePath);
      final url = Uri.parse('https://firebasestorage.googleapis.com/v0/b/$bucket/o/$encodedPath');
      await _httpClient.delete(url);
    } catch (_) {}
  }
}
