import 'dart:async';
import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/config/app_config.dart';
import '../../domain/entities/app_user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../../firebase_options.dart';
import '../repositories/supabase_document_repository.dart';

class AuthServiceImpl implements AuthRepository {
  static const String _kCurrentUserIdKey = 'qltl_current_user_id';

  final StreamController<AppUser?> _authStateController =
      StreamController<AppUser?>.broadcast();

  final http.Client _httpClient;
  AppUser? _currentUser;
  final List<AppUser> _allUsers = List.from(AppConfig.demoUsers);

  AuthServiceImpl({http.Client? httpClient})
      : _httpClient = httpClient ?? http.Client() {
    _initSession();
    _listenToFirebaseAuth();
  }

  void _listenToFirebaseAuth() {
    try {
      FirebaseAuth.instance.authStateChanges().listen((fbUser) {
        if (fbUser != null) {
          String effectiveId = fbUser.uid;
          if (fbUser.email == AppConfig.userAlice.email) {
            effectiveId = AppConfig.userAlice.id;
          } else if (fbUser.email == AppConfig.userBob.email) {
            effectiveId = AppConfig.userBob.id;
          } else if (fbUser.email == AppConfig.userCharlie.email) {
            effectiveId = AppConfig.userCharlie.id;
          }

          final user = AppUser(
            id: effectiveId,
            email: fbUser.email ?? 'google_user@gmail.com',
            displayName: fbUser.displayName ?? fbUser.email?.split('@').first ?? 'Firebase User',
            avatarUrl: fbUser.photoURL,
          );
          registerUser(user);
          _currentUser = user;
          if (!_authStateController.isClosed) {
            _authStateController.add(user);
          }
        }
      });
    } catch (_) {
      // Firebase Auth SDK chưa hỗ trợ native trên một số nền tảng (như Windows Desktop)
    }
  }

  Future<void> _initSession() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedUserId = prefs.getString(_kCurrentUserIdKey);
      if (savedUserId != null) {
        final found = _allUsers.firstWhere(
          (u) => u.id == savedUserId,
          orElse: () => AppConfig.userAlice,
        );
        _currentUser = found;
      } else {
        _currentUser = AppConfig.userAlice;
      }
    } catch (_) {
      _currentUser = AppConfig.userAlice;
    }
    if (!_authStateController.isClosed) {
      _authStateController.add(_currentUser);
    }
  }

  @override
  Future<AppUser?> getCurrentUser() async {
    return _currentUser;
  }

  @override
  Stream<AppUser?> get authStateChanges => _authStateController.stream;

  @override
  Future<AppUser> signInWithGoogle() async {
    debugPrint('Bắt đầu quy trình đăng nhập Google với Firebase Auth...');

    if (kIsWeb) {
      // 1. Trình duyệt Web (Chrome, Edge): Sử dụng signInWithPopup chính thức của Firebase
      try {
        final GoogleAuthProvider googleProvider = GoogleAuthProvider();
        googleProvider.addScope('email');
        googleProvider.addScope('profile');

        final userCredential =
            await FirebaseAuth.instance.signInWithPopup(googleProvider);
        final fbUser = userCredential.user;

        if (fbUser != null) {
          final user = AppUser(
            id: fbUser.uid,
            email: fbUser.email ?? 'google_user@gmail.com',
            displayName: fbUser.displayName ?? 'Google User',
            avatarUrl: fbUser.photoURL,
          );
          registerUser(user);
          await _saveUserSession(user);
          debugPrint('Đăng nhập Google Web thành công: ${user.email} (UID: ${user.id})');
          return user;
        }
        throw Exception('Không nhận được phản hồi người dùng từ Google Web.');
      } catch (e) {
        debugPrint('Lỗi đăng nhập Google trên Web: $e');
        rethrow;
      }
    } else if (defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS) {
      // 2. Thiết bị di động (Android / iOS): Sử dụng GoogleSignIn SDK
      try {
        final account = await GoogleSignIn.instance.authenticate();
        final auth = account.authentication;

        final AuthCredential credential = GoogleAuthProvider.credential(
          idToken: auth.idToken,
        );

        final userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);
        final fbUser = userCredential.user;

        if (fbUser != null) {
          final user = AppUser(
            id: fbUser.uid,
            email: fbUser.email ?? account.email,
            displayName: fbUser.displayName ?? account.displayName ?? 'Google User',
            avatarUrl: fbUser.photoURL ?? account.photoUrl,
          );
          registerUser(user);
          await _saveUserSession(user);
          debugPrint('Đăng nhập Google Mobile thành công: ${user.email} (UID: ${user.id})');
          return user;
        }
        throw Exception('Không nhận được thông tin người dùng từ Firebase Auth.');
      } catch (e) {
        debugPrint('Lỗi đăng nhập Google Mobile: $e');
        final msg = e.toString();
        if (msg.contains('10') || msg.contains('DEVELOPER_ERROR')) {
          throw Exception(
              'Lỗi Google Sign-In (Code 10): Ứng dụng Android chưa được thêm SHA-1 vào Firebase Console.\n'
              'SHA-1 máy này: 60:7E:D8:47:AA:B7:6B:03:90:94:91:EB:A5:08:6B:F1:0D:7C:B0:AF');
        }
        rethrow;
      }
    } else {
      // 3. Máy tính để bàn (Windows Desktop):
      throw Exception(
        'Google Sign-In SDK plugin chưa được hỗ trợ trên Windows Desktop.\n\n'
        '👉 Để kiểm tra tạo bản ghi thực tế trên Firebase Console tab Users ngay trên máy tính:\n'
        '1. Vui lòng bấm "Đăng nhập / Đăng ký Email Firebase" bên dưới (hoạt động 100% trên Windows!).\n'
        '2. Hoặc chạy trên trình duyệt Web: flutter run -d chrome'
      );
    }
  }

  @override
  Future<AppUser> signInWithEmailPassword(String email, String password) async {
    debugPrint('Bắt đầu xác thực Email với Firebase Auth: $email');

    // Thử qua Firebase Auth SDK trước (Web & Mobile)
    if (kIsWeb ||
        defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS) {
      try {
        final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.trim(),
          password: password,
        );
        final fbUser = cred.user;
        if (fbUser != null) {
          String effectiveId = fbUser.uid;
          if (fbUser.email == AppConfig.userAlice.email) {
            effectiveId = AppConfig.userAlice.id;
          } else if (fbUser.email == AppConfig.userBob.email) {
            effectiveId = AppConfig.userBob.id;
          } else if (fbUser.email == AppConfig.userCharlie.email) {
            effectiveId = AppConfig.userCharlie.id;
          }

          final user = AppUser(
            id: effectiveId,
            email: fbUser.email ?? email,
            displayName: fbUser.displayName ?? email.split('@').first,
            avatarUrl: fbUser.photoURL,
          );
          registerUser(user);
          await _saveUserSession(user);
          return user;
        }
      } catch (e) {
        debugPrint('FirebaseAuth SDK sign in notice: $e');
      }
    }

    // Dự phòng qua Firebase Auth REST API (hoạt động 100% trên Windows Desktop & mọi nền tảng)
    final apiKey = DefaultFirebaseOptions.web.apiKey;
    final url = Uri.parse(
      'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$apiKey',
    );

    final response = await _httpClient.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email.trim(),
        'password': password,
        'returnSecureToken': true,
      }),
    );

    Map<String, dynamic> data = {};
    if (response.body.isNotEmpty) {
      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {}
    }

    if (response.statusCode == 200 && data.containsKey('localId')) {
      final uid = data['localId'] as String;
      final retEmail = (data['email'] as String?) ?? email;
      final retName = (data['displayName'] as String?)?.isNotEmpty == true
          ? (data['displayName'] as String)
          : email.split('@').first;

      final user = AppUser(
        id: uid,
        email: retEmail,
        displayName: retName,
      );
      registerUser(user);
      await _saveUserSession(user);
      debugPrint('Đăng nhập Firebase Auth REST thành công: $retEmail (UID: $uid)');
      return user;
    } else {
      final errorMsg = _parseFirebaseError(data);
      throw Exception(errorMsg.isNotEmpty ? errorMsg : 'Không thể kết nối Firebase Auth (HTTP ${response.statusCode})');
    }
  }

  @override
  Future<AppUser> signUpWithEmailPassword(
    String email,
    String password, {
    String? displayName,
  }) async {
    debugPrint('Bắt đầu tạo tài khoản mới trên Firebase Auth: $email');

    // Thử qua Firebase Auth SDK trước (Web & Mobile)
    if (kIsWeb ||
        defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS) {
      try {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.trim(),
          password: password,
        );
        final fbUser = cred.user;
        if (fbUser != null) {
          if (displayName != null && displayName.isNotEmpty) {
            try {
              await fbUser.updateDisplayName(displayName);
            } catch (_) {}
          }
          final user = AppUser(
            id: fbUser.uid,
            email: fbUser.email ?? email,
            displayName: displayName ?? fbUser.displayName ?? email.split('@').first,
            avatarUrl: fbUser.photoURL,
          );
          registerUser(user);
          await _saveUserSession(user);
          return user;
        }
      } catch (e) {
        debugPrint('FirebaseAuth SDK sign up notice: $e');
      }
    }

    // Dự phòng qua Firebase Auth REST API (hoạt động 100% trên Windows Desktop & mọi nền tảng)
    final apiKey = DefaultFirebaseOptions.web.apiKey;
    final url = Uri.parse(
      'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey',
    );

    final response = await _httpClient.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email.trim(),
        'password': password,
        'returnSecureToken': true,
      }),
    );

    Map<String, dynamic> data = {};
    if (response.body.isNotEmpty) {
      try {
        data = jsonDecode(response.body) as Map<String, dynamic>;
      } catch (_) {}
    }

    if (response.statusCode == 200 && data.containsKey('localId')) {
      final uid = data['localId'] as String;
      final retEmail = (data['email'] as String?) ?? email;
      final name = displayName ?? email.split('@').first;

      final user = AppUser(
        id: uid,
        email: retEmail,
        displayName: name,
      );
      registerUser(user);
      await _saveUserSession(user);
      debugPrint('Đăng ký Firebase Auth REST thành công: $retEmail (UID: $uid)');
      return user;
    } else {
      final errorMsg = _parseFirebaseError(data);
      throw Exception(errorMsg.isNotEmpty ? errorMsg : 'Không thể kết nối Firebase Auth (HTTP ${response.statusCode})');
    }
  }

  @override
  Future<AppUser> signInDemoUser(String userId) async {
    // Tìm cấu hình demo user tương ứng
    final demoUser = _allUsers.firstWhere(
      (u) => u.id == userId,
      orElse: () => AppConfig.userAlice,
    );

    // Đồng bộ xác thực trực tiếp lên Firebase Auth (nếu có kết nối mạng)
    try {
      if (demoUser.id == AppConfig.userAlice.id) {
        await signInWithEmailPassword(demoUser.email, 'Password123!');
      } else if (demoUser.id == AppConfig.userBob.id) {
        await signInWithEmailPassword(demoUser.email, 'Password123!');
      } else if (demoUser.id == AppConfig.userCharlie.id) {
        await signInWithEmailPassword(demoUser.email, 'Password123!');
      }
    } catch (e) {
      debugPrint('Xác thực Firebase demo user qua mạng bỏ qua (dùng phiên bản offline): $e');
    }

    _currentUser = demoUser;
    await _saveUserSession(demoUser);
    if (!_authStateController.isClosed) {
      _authStateController.add(demoUser);
    }
    return demoUser;
  }

  @override
  Future<void> signOut() async {
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}

    try {
      await GoogleSignIn.instance.signOut();
    } catch (_) {}

    _currentUser = null;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_kCurrentUserIdKey);
    } catch (_) {}
    if (!_authStateController.isClosed) {
      _authStateController.add(null);
    }
  }

  @override
  Future<List<AppUser>> getAllUsers() async {
    return List.unmodifiable(_allUsers);
  }

  Future<void> _saveUserSession(AppUser user) async {
    _currentUser = user;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kCurrentUserIdKey, user.id);
    } catch (_) {}
    if (!_authStateController.isClosed) {
      _authStateController.add(_currentUser);
    }

    // Tự động đồng bộ người dùng Firebase sang bảng users của Supabase (nếu ở chế độ liveCloud)
    unawaited(SupabaseDocumentRepository.syncFirebaseUser(
      userId: user.id,
      email: user.email,
      displayName: user.displayName,
      avatarUrl: user.avatarUrl,
    ));
  }

  void registerUser(AppUser user) {
    if (!_allUsers.any((u) => u.id == user.id)) {
      _allUsers.add(user);
    }
  }

  String _parseFirebaseError(Map<String, dynamic> data) {
    if (data.isEmpty) {
      return 'Không nhận được dữ liệu phản hồi từ Firebase Auth.';
    }
    final error = data['error'];
    if (error is Map<String, dynamic>) {
      final msg = error['message'] as String? ?? 'UNKNOWN_ERROR';
      if (msg.contains('EMAIL_EXISTS')) {
        return 'Email này đã được đăng ký trên Firebase Auth. Vui lòng chọn "Đăng nhập".';
      }
      if (msg.contains('EMAIL_NOT_FOUND')) {
        return 'Email này chưa được đăng ký trên Firebase Auth. Vui lòng chọn "Đăng ký".';
      }
      if (msg.contains('INVALID_PASSWORD') || msg.contains('INVALID_LOGIN_CREDENTIALS')) {
        return 'Mật khẩu không chính xác.';
      }
      if (msg.contains('WEAK_PASSWORD')) {
        return 'Mật khẩu quá yếu (yêu cầu ít nhất 6 ký tự).';
      }
      if (msg.contains('INVALID_EMAIL')) {
        return 'Địa chỉ email không đúng định dạng.';
      }
      if (msg.contains('ADMIN_ONLY_OPERATION')) {
        return 'Tính năng đăng ký đang tạm khóa trong thiết lập Firebase Console.';
      }
      return 'Lỗi Firebase: $msg';
    }
    return 'Lỗi xác thực không xác định từ Firebase.';
  }

  void dispose() {
    _authStateController.close();
  }
}
