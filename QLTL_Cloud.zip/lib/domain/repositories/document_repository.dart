import '../entities/document.dart';

abstract class DocumentRepository {
  Future<List<Document>> getAllDocuments({String? category});

  Future<Document?> getDocumentById(int id);

  Future<int> addDocument(Document document);

  Future<bool> updateDocument(Document document);

  Future<int> deleteDocument(int id);

  Future<List<Document>> searchDocuments(String keyword, {String? category});

  /// Số lượng tài liệu của toàn bộ kho, không bị ảnh hưởng bởi bộ lọc
  /// danh mục hay từ khóa tìm kiếm đang hoạt động.
  Future<Map<String, int>> countByCategory();

  Stream<List<Document>> watchAllDocuments({String? category});
}
