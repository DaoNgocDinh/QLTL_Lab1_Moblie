import '../entities/cloud_document.dart';
import '../entities/document_permission.dart';

enum DocumentTabFilter {
  all, // Tất cả tài liệu mà user có quyền truy cập
  mine, // Tài liệu do chính user sở hữu (Owner)
  shared, // Tài liệu được chia sẻ cho user từ người khác
}

class PermissionDeniedException implements Exception {
  final String message;
  const PermissionDeniedException(this.message);

  @override
  String toString() => 'PermissionDeniedException: $message';
}

abstract class CloudDocumentRepository {
  /// Lấy danh sách tài liệu mà user có quyền xem (RLS SELECT)
  Future<List<CloudDocument>> getDocumentsForUser(
    String userId, {
    String? category,
    String? query,
    DocumentTabFilter tab = DocumentTabFilter.all,
  });

  /// Lấy chi tiết tài liệu theo ID (kiểm tra quyền xem)
  Future<CloudDocument> getDocumentById(String documentId, String userId);

  /// Tạo mới tài liệu (RLS INSERT: owner_id = requestingUserId)
  Future<CloudDocument> createDocument(
    CloudDocument document,
    String requestingUserId,
  );

  /// Cập nhật tài liệu (RLS UPDATE: owner hoặc edit permission)
  Future<CloudDocument> updateDocument(
    CloudDocument document,
    String requestingUserId,
  );

  /// Xóa tài liệu (RLS DELETE: chỉ owner mới có quyền xóa)
  Future<void> deleteDocument(
    String documentId,
    String requestingUserId,
  );

  /// Chia sẻ tài liệu cho người khác (RLS INSERT permission: chỉ owner)
  Future<DocumentPermission> shareDocument({
    required String documentId,
    required String targetUserId,
    required String permissionLevel,
    required String requestingUserId,
  });

  /// Thu hồi quyền chia sẻ (RLS DELETE permission: chỉ owner)
  Future<void> revokePermission({
    required String documentId,
    required String targetUserId,
    required String requestingUserId,
  });

  /// Lấy danh sách các quyền chia sẻ của tài liệu (chỉ owner hoặc người được cấp quyền)
  Future<List<DocumentPermission>> getDocumentPermissions(
    String documentId,
    String requestingUserId,
  );

  /// Thống kê số lượng tài liệu theo danh mục cho user hiện tại
  Future<Map<String, int>> getDocumentCounts(String userId);
}
