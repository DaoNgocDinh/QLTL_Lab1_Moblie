import '../entities/app_user.dart';

abstract class AuthRepository {
  /// Lấy thông tin người dùng đang đăng nhập hiện tại
  Future<AppUser?> getCurrentUser();

  /// Luồng theo dõi thay đổi trạng thái đăng nhập
  Stream<AppUser?> get authStateChanges;

  /// Đăng nhập bằng tài khoản Google (Firebase Auth)
  Future<AppUser> signInWithGoogle();

  /// Đăng nhập nhanh tài khoản thử nghiệm (Alice / Bob / Charlie)
  Future<AppUser> signInDemoUser(String userId);

  /// Đăng nhập bằng Email và Mật khẩu (Firebase Auth)
  Future<AppUser> signInWithEmailPassword(String email, String password);

  /// Đăng ký tài khoản mới bằng Email và Mật khẩu (Firebase Auth)
  Future<AppUser> signUpWithEmailPassword(String email, String password, {String? displayName});

  /// Đăng xuất khỏi hệ thống
  Future<void> signOut();

  /// Lấy danh sách tất cả người dùng trong hệ thống (để chọn chia sẻ tài liệu)
  Future<List<AppUser>> getAllUsers();
}
