class CloudUploadedFile {
  final String fileUrl;
  final String storagePath;
  final String fileName;
  final String fileType;
  final int fileSize;

  const CloudUploadedFile({
    required this.fileUrl,
    required this.storagePath,
    required this.fileName,
    required this.fileType,
    required this.fileSize,
  });
}

abstract class StorageRepository {
  /// Tải tệp vật lý lên Firebase Storage
  /// Đường dẫn đích: documents/{userId}/{timestamp}_{fileName}
  Future<CloudUploadedFile> uploadDocumentFile({
    required String userId,
    required String fileName,
    required List<int> bytes,
    String? mimeType,
  });

  /// Xóa tệp khỏi Firebase Storage
  Future<void> deleteDocumentFile(String storagePath);
}
