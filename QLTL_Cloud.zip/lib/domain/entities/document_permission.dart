class DocumentPermission {
  final String id;
  final String documentId;
  final String userId;
  final String permissionLevel; // 'view' hoặc 'edit'
  final String grantedBy;
  final String? userEmail;
  final String? userDisplayName;
  final DateTime? createdAt;

  const DocumentPermission({
    required this.id,
    required this.documentId,
    required this.userId,
    required this.permissionLevel,
    required this.grantedBy,
    this.userEmail,
    this.userDisplayName,
    this.createdAt,
  });

  bool get isViewOnly => permissionLevel == 'view';
  bool get isEditable => permissionLevel == 'edit';

  DocumentPermission copyWith({
    String? id,
    String? documentId,
    String? userId,
    String? permissionLevel,
    String? grantedBy,
    String? userEmail,
    String? userDisplayName,
    DateTime? createdAt,
  }) {
    return DocumentPermission(
      id: id ?? this.id,
      documentId: documentId ?? this.documentId,
      userId: userId ?? this.userId,
      permissionLevel: permissionLevel ?? this.permissionLevel,
      grantedBy: grantedBy ?? this.grantedBy,
      userEmail: userEmail ?? this.userEmail,
      userDisplayName: userDisplayName ?? this.userDisplayName,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DocumentPermission &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;
}
