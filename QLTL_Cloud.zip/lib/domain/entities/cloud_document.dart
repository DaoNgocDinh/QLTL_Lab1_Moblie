import 'document_permission.dart';

class CloudDocument {
  final String id;
  final String ownerId;
  final String? ownerEmail;
  final String? ownerName;
  final String title;
  final String description;
  final String category;
  final String? fileUrl;
  final String? fileName;
  final String fileType;
  final int fileSize;
  final String? storagePath;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<DocumentPermission> permissions;

  const CloudDocument({
    required this.id,
    required this.ownerId,
    this.ownerEmail,
    this.ownerName,
    required this.title,
    required this.description,
    required this.category,
    this.fileUrl,
    this.fileName,
    required this.fileType,
    required this.fileSize,
    this.storagePath,
    required this.createdAt,
    required this.updatedAt,
    this.permissions = const [],
  });

  /// Kiểm tra xem user hiện tại có phải là Chủ sở hữu (Owner) không
  bool isOwner(String userId) => ownerId == userId;

  /// Kiểm tra xem user có quyền chỉnh sửa tài liệu không (Owner hoặc Permission = 'edit')
  bool canEdit(String userId) {
    if (isOwner(userId)) return true;
    return permissions.any(
      (p) => p.userId == userId && p.permissionLevel == 'edit',
    );
  }

  /// Kiểm tra xem user có quyền xem tài liệu không (Owner hoặc có trong permissions)
  bool canView(String userId) {
    if (isOwner(userId)) return true;
    return permissions.any((p) => p.userId == userId);
  }

  /// Trả về cấp độ quyền của user đối với tài liệu: 'owner', 'edit', 'view', hoặc null
  String? permissionLevelFor(String userId) {
    if (isOwner(userId)) return 'owner';
    final perm = permissions.where((p) => p.userId == userId).toList();
    if (perm.isNotEmpty) {
      return perm.first.permissionLevel;
    }
    return null;
  }

  /// Định dạng dung lượng tệp đọc được (vd: 2.4 MB, 512 KB)
  String get formattedFileSize {
    if (fileSize <= 0) return '0 B';
    if (fileSize < 1024) return '$fileSize B';
    if (fileSize < 1024 * 1024) {
      return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    }
    return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  CloudDocument copyWith({
    String? id,
    String? ownerId,
    String? ownerEmail,
    String? ownerName,
    String? title,
    String? description,
    String? category,
    String? fileUrl,
    String? fileName,
    String? fileType,
    int? fileSize,
    String? storagePath,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<DocumentPermission>? permissions,
  }) {
    return CloudDocument(
      id: id ?? this.id,
      ownerId: ownerId ?? this.ownerId,
      ownerEmail: ownerEmail ?? this.ownerEmail,
      ownerName: ownerName ?? this.ownerName,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      fileUrl: fileUrl ?? this.fileUrl,
      fileName: fileName ?? this.fileName,
      fileType: fileType ?? this.fileType,
      fileSize: fileSize ?? this.fileSize,
      storagePath: storagePath ?? this.storagePath,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      permissions: permissions ?? this.permissions,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CloudDocument &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          title == other.title &&
          category == other.category &&
          updatedAt == other.updatedAt;

  @override
  int get hashCode => id.hashCode ^ title.hashCode ^ updatedAt.hashCode;
}
