class SupabaseConfig {
  static const String supabaseUrl =
      'https://gqodmzbvivtumxnbelix.supabase.co';
  static const String supabasePublishableKey =
      'sb_publishable_KhLi7pSCQcaKfA8AOdTLdw_wRorvyev';
}
