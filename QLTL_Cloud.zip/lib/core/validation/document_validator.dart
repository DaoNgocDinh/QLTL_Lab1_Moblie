import '../constants/app_constants.dart';

/// Quy tắc kiểm tra dữ liệu tài liệu dùng chung cho tầng Application (use case)
/// và tầng Presentation (form thêm / chỉnh sửa).
///
/// Mục tiêu: một quy tắc chỉ được định nghĩa một lần, form hiển thị lỗi ngay
/// và use case vẫn chặn được dữ liệu sai khi được gọi từ nơi khác.
class DocumentValidator {
  const DocumentValidator._();

  static const int minTitleLength = 3;
  static const int maxTitleLength = 120;
  static const int maxAuthorLength = 80;
  static const int maxDescriptionLength = 1000;
  static const int maxFilePathLength = 255;

  // Ký tự không hợp lệ trong tên file / đường dẫn lưu trữ.
  static final RegExp _invalidPathChars = RegExp(r'[<>"|?*]');

  static String? validateTitle(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Vui lòng nhập tên tài liệu';
    }
    if (text.length < minTitleLength) {
      return 'Tên tài liệu phải có ít nhất $minTitleLength ký tự';
    }
    if (text.length > maxTitleLength) {
      return 'Tên tài liệu không được vượt quá $maxTitleLength ký tự';
    }
    return null;
  }

  static String? validateCategory(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Vui lòng chọn danh mục';
    }
    if (text == AppConstants.categoryAll) {
      return 'Danh mục không được là "${AppConstants.categoryAll}"';
    }
    if (!AppConstants.categories.contains(text)) {
      return 'Danh mục "$text" không hợp lệ';
    }
    return null;
  }

  static String? validateFileType(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Vui lòng chọn định dạng tệp';
    }
    if (!AppConstants.fileTypes.contains(text)) {
      return 'Định dạng "$text" không hợp lệ';
    }
    return null;
  }

  static String? validateFilePath(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) {
      return null; // Đường dẫn là trường tùy chọn.
    }
    if (text.length > maxFilePathLength) {
      return 'Đường dẫn không được vượt quá $maxFilePathLength ký tự';
    }
    if (_invalidPathChars.hasMatch(text)) {
      return 'Đường dẫn chứa ký tự không hợp lệ (< > " | ? *)';
    }
    return null;
  }

  static String? validateAuthor(String? value) {
    final text = value?.trim() ?? '';
    if (text.isEmpty) {
      return null; // Tác giả là trường tùy chọn.
    }
    if (text.length > maxAuthorLength) {
      return 'Tên tác giả không được vượt quá $maxAuthorLength ký tự';
    }
    return null;
  }

  static String? validateDescription(String? value) {
    final text = value?.trim() ?? '';
    if (text.length > maxDescriptionLength) {
      return 'Mô tả không được vượt quá $maxDescriptionLength ký tự';
    }
    return null;
  }

  /// Trả về thông báo lỗi đầu tiên, hoặc `null` nếu tài liệu hợp lệ.
  /// Dùng cho use case để ném `ArgumentError` với thông điệp thân thiện.
  static String? collectFirstError({
    required String? title,
    required String? category,
    required String? fileType,
    String? filePath,
    String? author,
    String? description,
  }) {
    final errors = <String?>[
      validateTitle(title),
      validateCategory(category),
      validateFileType(fileType),
      validateFilePath(filePath),
      validateAuthor(author),
      validateDescription(description),
    ];
    for (final error in errors) {
      if (error != null) return error;
    }
    return null;
  }
}