import 'package:shared_preferences/shared_preferences.dart';
import '../../domain/entities/app_user.dart';
import '../../supabase_config.dart';

enum CloudBackendMode {
  /// Chế độ mô phỏng đám mây: hoạt động trơn tru 100% không phụ thuộc internet,
  /// tuân thủ chính xác cơ chế RLS Supabase và Firebase Storage, tối ưu cho chấm điểm và kiểm thử tự động.
  mockCloud,

  /// Chế độ trực tiếp: kết nối tới Firebase Auth, Firebase Storage và Supabase PostgreSQL thật.
  liveCloud,
}

class AppConfig {
  /// Chuẩn hóa URL Supabase (loại bỏ /rest/v1 và dấu gạch chéo cuối nếu người dùng dán nhầm)
  static String sanitizeUrl(String raw) {
    var url = raw.trim();
    while (url.endsWith('/')) {
      url = url.substring(0, url.length - 1);
    }
    if (url.endsWith('/rest/v1')) {
      url = url.substring(0, url.length - '/rest/v1'.length);
    }
    while (url.endsWith('/')) {
      url = url.substring(0, url.length - 1);
    }
    return url;
  }

  /// Supabase Project URL (đọc tự động từ SupabaseConfig hoặc mặc định)
  static String supabaseUrl = sanitizeUrl(SupabaseConfig.supabaseUrl);

  /// Supabase Anon Public Key (đọc tự động từ SupabaseConfig hoặc mặc định)
  static String supabaseAnonKey = SupabaseConfig.supabasePublishableKey.trim();

  /// Chế độ vận hành hiện tại (tự động chuyển sang liveCloud nếu có config Supabase hợp lệ)
  static CloudBackendMode backendMode = (supabaseUrl.isNotEmpty &&
          !supabaseUrl.contains('xyzcompany') &&
          supabaseAnonKey.isNotEmpty)
      ? CloudBackendMode.liveCloud
      : CloudBackendMode.mockCloud;

  static const String _kSupabaseUrlKey = 'qltl_supabase_url';
  static const String _kSupabaseKeyKey = 'qltl_supabase_anon_key';
  static const String _kBackendModeKey = 'qltl_backend_mode';

  /// Tải cấu hình Supabase đã lưu từ SharedPreferences
  static Future<void> loadSavedConfig() async {
    final configuredUrl = sanitizeUrl(SupabaseConfig.supabaseUrl);
    final configuredKey = SupabaseConfig.supabasePublishableKey.trim();
    if (configuredUrl.isNotEmpty &&
        !configuredUrl.contains('xyzcompany') &&
        configuredKey.isNotEmpty) {
      supabaseUrl = configuredUrl;
      supabaseAnonKey = configuredKey;
      backendMode = CloudBackendMode.liveCloud;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final savedUrl = prefs.getString(_kSupabaseUrlKey);
      final savedKey = prefs.getString(_kSupabaseKeyKey);
      final savedMode = prefs.getString(_kBackendModeKey);

      if (savedUrl != null && savedUrl.isNotEmpty) {
        supabaseUrl = sanitizeUrl(savedUrl);
      }
      if (savedKey != null && savedKey.isNotEmpty) {
        supabaseAnonKey = savedKey.trim();
      }
      if (savedMode == 'liveCloud') {
        backendMode = CloudBackendMode.liveCloud;
      } else if (savedMode == 'mockCloud') {
        backendMode = CloudBackendMode.mockCloud;
      }
    } catch (_) {}
  }

  /// Cập nhật và lưu cấu hình Supabase
  static Future<void> updateSupabaseConfig({
    required String url,
    required String anonKey,
    CloudBackendMode? mode,
  }) async {
    supabaseUrl = sanitizeUrl(url);
    supabaseAnonKey = anonKey.trim();
    if (mode != null) {
      backendMode = mode;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kSupabaseUrlKey, supabaseUrl);
      await prefs.setString(_kSupabaseKeyKey, supabaseAnonKey);
      await prefs.setString(_kBackendModeKey, backendMode.name);
    } catch (_) {}
  }

  /// Danh sách 3 tài khoản kiểm thử tiêu chuẩn đáp ứng Checklist mục 6
  static const AppUser userAlice = AppUser(
    id: 'user_alice_001',
    email: 'alice.nguyen@student.edu.vn',
    displayName: 'Nguyễn Thị Thu Hà (Alice - Chủ sở hữu)',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/png?seed=Alice',
  );

  static const AppUser userBob = AppUser(
    id: 'user_bob_002',
    email: 'bob.tran@student.edu.vn',
    displayName: 'Trần Văn Bình (Bob - Cộng tác viên)',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/png?seed=Bob',
  );

  static const AppUser userCharlie = AppUser(
    id: 'user_charlie_003',
    email: 'charlie.le@student.edu.vn',
    displayName: 'Lê Hoàng Cường (Charlie - Người lạ)',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/png?seed=Charlie',
  );

  static List<AppUser> get demoUsers => [userAlice, userBob, userCharlie];

  /// Danh mục tài liệu chuẩn
  static const List<String> categories = [
    'Tất cả',
    'Bài giảng',
    'Đồ án',
    'Tài liệu ôn thi',
    'Tham khảo',
  ];

  /// Các định dạng tệp tin cho phép
  static const List<String> allowedFileExtensions = [
    'pdf',
    'docx',
    'doc',
    'pptx',
    'ppt',
    'xlsx',
    'xls',
    'txt',
    'zip',
    'png',
    'jpg',
  ];
}
