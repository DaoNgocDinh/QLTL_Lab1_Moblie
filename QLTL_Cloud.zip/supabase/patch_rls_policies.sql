-- ====================================================================
-- BẢN VÁ SỬA LỖI ĐỆ QUY CHÍNH SÁCH RLS (42P17) TRÊN SUPABASE
-- Chạy đoạn mã này trong Supabase Dashboard -> SQL Editor -> Bấm "Run" (hoặc Ctrl+Enter)
-- ====================================================================

-- 1. Hàm trợ giúp xác định UID
CREATE OR REPLACE FUNCTION current_app_user_id()
RETURNS text AS $$
BEGIN
    RETURN COALESCE(
        current_setting('request.jwt.claims', true)::json->>'sub',
        auth.uid()::text,
        current_setting('request.headers', true)::json->>'x-user-id',
        current_setting('app.current_user_id', true)
    );
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

-- 2. Xóa các chính sách cũ gây đệ quy vòng lặp trên bảng documents và document_permissions
DROP POLICY IF EXISTS "documents_select_policy" ON documents;
DROP POLICY IF EXISTS "documents_insert_policy" ON documents;
DROP POLICY IF EXISTS "documents_update_policy" ON documents;
DROP POLICY IF EXISTS "documents_delete_policy" ON documents;

DROP POLICY IF EXISTS "permissions_select_policy" ON document_permissions;
DROP POLICY IF EXISTS "permissions_insert_policy" ON document_permissions;
DROP POLICY IF EXISTS "permissions_update_policy" ON document_permissions;
DROP POLICY IF EXISTS "permissions_delete_policy" ON document_permissions;

-- 3. Tạo lại chính sách cho bảng documents (Không còn đệ quy)
CREATE POLICY "documents_select_policy"
ON documents FOR SELECT
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id()
    )
);

CREATE POLICY "documents_insert_policy"
ON documents FOR INSERT
WITH CHECK (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
);

CREATE POLICY "documents_update_policy"
ON documents FOR UPDATE
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id() 
          AND permission_level = 'edit'
    )
)
WITH CHECK (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id() 
          AND permission_level = 'edit'
    )
);

CREATE POLICY "documents_delete_policy"
ON documents FOR DELETE
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
);

-- 4. Tạo lại chính sách cho bảng document_permissions (Chỉ kiểm tra user_id và granted_by, KHÔNG truy vấn ngược lại documents)
CREATE POLICY "permissions_select_policy"
ON document_permissions FOR SELECT
USING (
    current_app_user_id() IS NULL
    OR user_id = current_app_user_id()
    OR granted_by = current_app_user_id()
);

CREATE POLICY "permissions_insert_policy"
ON document_permissions FOR INSERT
WITH CHECK (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

CREATE POLICY "permissions_update_policy"
ON document_permissions FOR UPDATE
USING (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
)
WITH CHECK (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

CREATE POLICY "permissions_delete_policy"
ON document_permissions FOR DELETE
USING (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

-- Thông báo hoàn tất thành công
SELECT 'RLS Policies updated successfully! No recursion!' as status;
