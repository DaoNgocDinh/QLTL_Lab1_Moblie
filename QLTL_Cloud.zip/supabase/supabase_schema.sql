-- ====================================================================
-- HỆ THỐNG QUẢN LÝ TÀI LIỆU ĐA NỀN TẢNG (FLUTTER + FIREBASE + SUPABASE)
-- TẬP LỆNH KHỞI TẠO CƠ SỞ DỮ LIỆU VÀ CHÍNH SÁCH BẢO MẬT (ROW LEVEL SECURITY - RLS)
-- Sinh viên: Đào Ngọc Đình - MSSV: 2351170582 - Lớp: 65KTPM
-- ====================================================================

-- 1. KÍCH HOẠT EXTENSION HỖ TRỢ UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ====================================================================
-- 2. ĐỊNH NGHĨA CÁC BẢNG DỮ LIỆU QUAN HỆ
-- ====================================================================

-- BẢNG 1: NGƯỜI DÙNG (users / profiles)
-- Lưu trữ thông tin người dùng được đồng bộ từ Firebase Auth hoặc Supabase Auth
DROP TABLE IF EXISTS document_permissions CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
    id TEXT PRIMARY KEY,                       -- Khóa chính: UID từ Firebase Auth hoặc UUID từ Supabase
    email TEXT NOT NULL UNIQUE,                -- Email người dùng (Google Account)
    display_name TEXT NOT NULL,                -- Họ tên hiển thị
    avatar_url TEXT,                           -- Ảnh đại diện (Google photoURL)
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- BẢNG 2: TÀI LIỆU (documents)
-- Quản lý metadata tài liệu và liên kết với tệp tin vật lý trên Firebase Storage
CREATE TABLE documents (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,                    -- Danh mục: Bài giảng, Đồ án, Tài liệu ôn thi, Tham khảo
    file_url TEXT,                             -- Đường dẫn tải file từ Firebase Storage (Download URL)
    file_name TEXT,                            -- Tên tệp gốc (vd: DeCuong_Flutter.pdf)
    file_type TEXT NOT NULL DEFAULT 'PDF',     -- Định dạng: PDF, DOCX, PPTX, XLSX, TXT, ZIP
    file_size BIGINT NOT NULL DEFAULT 0,       -- Dung lượng tệp tính bằng Bytes
    storage_path TEXT,                         -- Đường dẫn vật lý trên Firebase Storage: documents/{userId}/{filename}
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- BẢNG 3: QUYỀN CHIA SẺ TÀI LIỆU (document_permissions)
-- Quản lý quyền truy cập phân cấp (View / Edit) giữa các người dùng
CREATE TABLE document_permissions (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,          -- Người được chia sẻ
    permission_level TEXT NOT NULL CHECK (permission_level IN ('view', 'edit')), -- 'view': Chỉ xem, 'edit': Chỉnh sửa
    granted_by TEXT NOT NULL REFERENCES users(id),                         -- Người cấp quyền (thường là Owner)
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    CONSTRAINT uq_doc_user_permission UNIQUE (document_id, user_id)
);

-- ====================================================================
-- 3. CHỈ MỤC (INDEXES) TỐI ƯU HÓA HIỆU NĂNG TRUY VẤN
-- ====================================================================
CREATE INDEX idx_documents_owner_id ON documents(owner_id);
CREATE INDEX idx_documents_category ON documents(category);
CREATE INDEX idx_documents_created_at ON documents(created_at DESC);
CREATE INDEX idx_permissions_doc_user ON document_permissions(document_id, user_id);
CREATE INDEX idx_permissions_user_id ON document_permissions(user_id);
CREATE INDEX idx_users_email ON users(email);

-- ====================================================================
-- 4. HÀM TRỢ GIÚP XÁC ĐỊNH USER HIỆN TẠI TỪ JWT (Firebase Auth / Supabase Auth)
-- ====================================================================
CREATE OR REPLACE FUNCTION current_app_user_id()
RETURNS text AS $$
BEGIN
    -- Lấy ID từ Supabase auth uid hoặc JWT claim 'sub' (tương thích Firebase Auth Token)
    RETURN COALESCE(
        current_setting('request.jwt.claims', true)::json->>'sub',
        auth.uid()::text,
        current_setting('app.current_user_id', true)
    );
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

-- ====================================================================
-- 5. CHÍNH SÁCH BẢO MẬT HÀNG (ROW LEVEL SECURITY - RLS)
-- ====================================================================

-- 5.1 Bật RLS cho tất cả các bảng
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_permissions ENABLE ROW LEVEL SECURITY;

-- 5.2 RLS CHO BẢNG USERS:
-- Bất kỳ người dùng đã xác thực nào cũng có thể đọc danh sách người dùng để tìm kiếm và chia sẻ
CREATE POLICY "users_select_policy"
ON users FOR SELECT
USING (true);

-- Người dùng chỉ được sửa thông tin cá nhân của chính mình
CREATE POLICY "users_update_policy"
ON users FOR UPDATE
USING (id = current_app_user_id())
WITH CHECK (id = current_app_user_id());

-- Cho phép chèn bản ghi profile khi đăng nhập lần đầu
CREATE POLICY "users_insert_policy"
ON users FOR INSERT
WITH CHECK (true);

-- 5.3 RLS CHO BẢNG DOCUMENTS:
-- Quyền ĐỌC (SELECT):
-- Người dùng xem được tài liệu nếu:
-- (a) Họ là Chủ sở hữu (Owner)
-- HOẶC (b) Họ được chia sẻ trong bảng document_permissions
-- HOẶC (c) Kết nối qua anon key (client áp dụng bộ lọc phân quyền theo tài khoản)
CREATE POLICY "documents_select_policy"
ON documents FOR SELECT
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id()
    )
);

-- Quyền TẠO MỚI (INSERT):
-- Chỉ người dùng đã đăng nhập và đặt owner_id là chính mình mới được tạo
CREATE POLICY "documents_insert_policy"
ON documents FOR INSERT
WITH CHECK (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
);

-- Quyền CẬP NHẬT (UPDATE):
-- Chỉ được sửa tài liệu nếu:
-- (a) Họ là Chủ sở hữu (Owner)
-- HOẶC (b) Họ được chia sẻ với quyền 'edit'
CREATE POLICY "documents_update_policy"
ON documents FOR UPDATE
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id() 
          AND permission_level = 'edit'
    )
)
WITH CHECK (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
    OR id IN (
        SELECT document_id 
        FROM document_permissions 
        WHERE user_id = current_app_user_id() 
          AND permission_level = 'edit'
    )
);

-- Quyền XÓA (DELETE):
-- DUY NHẤT Chủ sở hữu (Owner) mới có quyền xóa tài liệu
CREATE POLICY "documents_delete_policy"
ON documents FOR DELETE
USING (
    current_app_user_id() IS NULL
    OR owner_id = current_app_user_id()
);

-- 5.4 RLS CHO BẢNG DOCUMENT_PERMISSIONS:
-- Quyền ĐỌC (SELECT):
-- Xem được quyền chia sẻ nếu là chính người được cấp quyền HOẶC người cấp quyền (Owner)
CREATE POLICY "permissions_select_policy"
ON document_permissions FOR SELECT
USING (
    current_app_user_id() IS NULL
    OR user_id = current_app_user_id()
    OR granted_by = current_app_user_id()
);

-- Quyền TẠO QUYỀN (INSERT):
-- DUY NHẤT Owner của tài liệu mới có quyền chia sẻ cho người khác
CREATE POLICY "permissions_insert_policy"
ON document_permissions FOR INSERT
WITH CHECK (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

-- Quyền CẬP NHẬT QUYỀN (UPDATE):
-- DUY NHẤT Owner của tài liệu mới có quyền nâng cấp / hạ cấp quyền (view <-> edit)
CREATE POLICY "permissions_update_policy"
ON document_permissions FOR UPDATE
USING (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
)
WITH CHECK (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

-- Quyền THU HỒI QUYỀN (DELETE):
-- DUY NHẤT Owner của tài liệu mới có quyền thu hồi quyền chia sẻ
CREATE POLICY "permissions_delete_policy"
ON document_permissions FOR DELETE
USING (
    current_app_user_id() IS NULL
    OR granted_by = current_app_user_id()
);

-- ====================================================================
-- 6. DỮ LIỆU MẪU (SEED DATA CHO 3 TÀI KHOẢN KIỂM THỬ)
-- ====================================================================

-- 3 Tài khoản kiểm thử chuẩn:
-- 1. Alice (Chủ sở hữu - Owner)
-- 2. Bob (Cộng tác viên - Collaborator)
-- 3. Charlie (Người dùng chưa được cấp quyền - Unauthorized Viewer)

INSERT INTO users (id, email, display_name, avatar_url) VALUES
('user_alice_001', 'alice.nguyen@student.edu.vn', 'Nguyễn Thị Thu Hà (Alice - Owner)', 'https://api.dicebear.com/7.x/bottts/png?seed=Alice'),
('user_bob_002', 'bob.tran@student.edu.vn', 'Trần Văn Bình (Bob - Collaborator)', 'https://api.dicebear.com/7.x/bottts/png?seed=Bob'),
('user_charlie_003', 'charlie.le@student.edu.vn', 'Lê Hoàng Cường (Charlie - Stranger)', 'https://api.dicebear.com/7.x/bottts/png?seed=Charlie')
ON CONFLICT (id) DO UPDATE 
SET display_name = EXCLUDED.display_name,
    avatar_url = EXCLUDED.avatar_url;

-- Tài liệu mẫu do Alice tạo
INSERT INTO documents (id, owner_id, title, description, category, file_url, file_name, file_type, file_size, storage_path) VALUES
('doc_001', 'user_alice_001', 'GiaoTrinh_LapTrinh_Flutter_Cloud.pdf', 'Giáo trình toàn diện về Flutter, Firebase và Supabase.', 'Bài giảng', 'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_001_GiaoTrinh_LapTrinh_Flutter_Cloud.pdf?alt=media', 'GiaoTrinh_LapTrinh_Flutter_Cloud.pdf', 'PDF', 4194304, 'documents/user_alice_001/doc_001_GiaoTrinh_LapTrinh_Flutter_Cloud.pdf'),
('doc_002', 'user_alice_001', 'BaoCao_KienTruc_HeThong_Lab2.docx', 'Bản thiết kế kiến trúc phân lớp Clean Architecture và RLS.', 'Đồ án', 'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_002_BaoCao_KienTruc_HeThong_Lab2.docx?alt=media', 'BaoCao_KienTruc_HeThong_Lab2.docx', 'DOCX', 2097152, 'documents/user_alice_001/doc_002_BaoCao_KienTruc_HeThong_Lab2.docx'),
('doc_003', 'user_alice_001', 'TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx', 'Slide tóm tắt kiến thức Indexing, Partitioning và Row Level Security.', 'Tài liệu ôn thi', 'https://firebasestorage.googleapis.com/v0/b/demo-qltl.appspot.com/o/documents%2Fuser_alice_001%2Fdoc_003_TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx?alt=media', 'TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx', 'PPTX', 8388608, 'documents/user_alice_001/doc_003_TaiLieu_OnTap_CoSoDuLieu_NangCao.pptx')
ON CONFLICT (id) DO NOTHING;

-- Phân quyền mẫu: Alice chia sẻ doc_001 cho Bob với quyền 'view'
INSERT INTO document_permissions (id, document_id, user_id, permission_level, granted_by) VALUES
('perm_001', 'doc_001', 'user_bob_002', 'view', 'user_alice_001')
ON CONFLICT (document_id, user_id) DO NOTHING;
