import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:qltl/data/services/firebase_storage_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Kiểm thử Firebase Storage Service', () {
    test('Cấu trúc đường dẫn tệp tải lên tuân thủ chuẩn Checklist mục 2', () async {
      final storageService = FirebaseStorageServiceImpl();
      final result = await storageService.uploadDocumentFile(
        userId: 'user_alice_001',
        fileName: 'bao_cao_tot_nghiep.pdf',
        bytes: [1, 2, 3, 4, 5],
      );

      expect(result.storagePath, startsWith('documents/user_alice_001/'));
      expect(result.storagePath, endsWith('_bao_cao_tot_nghiep.pdf'));
      expect(result.fileType, 'PDF');
      expect(result.fileSize, 5);
      expect(result.fileUrl, contains('qltl-cloud-doc.firebasestorage.app'));
    });

    test('Tải lên thành công qua REST API khi Bucket đã kích hoạt', () async {
      final mockClient = MockClient((request) async {
        if (request.url.path.contains('/o') && request.method == 'POST') {
          return http.Response(
            jsonEncode({
              'name': 'documents/test/sample.pdf',
              'bucket': 'qltl-cloud-doc.firebasestorage.app',
              'downloadTokens': 'mock-token-xyz-123',
              'size': '10',
            }),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        return http.Response('Not Found', 404);
      });

      final storageService = FirebaseStorageServiceImpl(httpClient: mockClient);
      final result = await storageService.uploadDocumentFile(
        userId: 'test_user',
        fileName: 'sample.pdf',
        bytes: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
      );

      expect(result.fileUrl, contains('token=mock-token-xyz-123'));
    });

    test('checkBucketStatus phát hiện chính xác mã 404 khi chưa kích hoạt Bucket', () async {
      final mockClient = MockClient((request) async {
        return http.Response(
          jsonEncode({'error': {'code': 404, 'message': 'Not Found.'}}),
          404,
          headers: {'content-type': 'application/json; charset=utf-8'},
        );
      });

      final status = await FirebaseStorageServiceImpl.checkBucketStatus(client: mockClient);
      expect(status['isReady'], isFalse);
      expect(status['statusCode'], 404);
      expect(status['message'], contains('chưa được khởi tạo'));
    });
  });
}
