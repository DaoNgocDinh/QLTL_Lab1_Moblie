import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/application/controllers/document_controller.dart';
import 'package:qltl/application/use_cases/add_document.dart';
import 'package:qltl/application/use_cases/delete_document.dart';
import 'package:qltl/application/use_cases/get_document_by_id.dart';
import 'package:qltl/application/use_cases/get_document_counts.dart';
import 'package:qltl/application/use_cases/get_documents.dart';
import 'package:qltl/application/use_cases/search_documents.dart';
import 'package:qltl/application/use_cases/update_document.dart';
import 'package:qltl/core/constants/app_constants.dart';
import 'package:qltl/domain/entities/document.dart';
import 'package:qltl/domain/repositories/document_repository.dart';

class ControllerTestRepository implements DocumentRepository {
  final List<Document> items = [];
  int idGen = 1;

  @override
  Future<List<Document>> getAllDocuments({String? category}) async {
    if (category != null && category.isNotEmpty && category != 'Tất cả') {
      return items.where((d) => d.category == category).toList();
    }
    return List.from(items);
  }

  @override
  Future<Document?> getDocumentById(int id) async {
    try {
      return items.firstWhere((d) => d.id == id);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<int> addDocument(Document document) async {
    final newId = idGen++;
    items.add(document.copyWith(id: newId));
    return newId;
  }

  @override
  Future<bool> updateDocument(Document document) async {
    final idx = items.indexWhere((d) => d.id == document.id);
    if (idx != -1) {
      items[idx] = document;
      return true;
    }
    return false;
  }

  @override
  Future<int> deleteDocument(int id) async {
    final initial = items.length;
    items.removeWhere((d) => d.id == id);
    return initial - items.length;
  }

  @override
  Future<List<Document>> searchDocuments(String keyword, {String? category}) async {
    final q = keyword.toLowerCase();
    return items.where((d) {
      final matches = d.title.toLowerCase().contains(q) || d.description.toLowerCase().contains(q);
      final catMatch = category == null || category == 'Tất cả' || d.category == category;
      return matches && catMatch;
    }).toList();
  }

  @override
  Future<Map<String, int>> countByCategory() async {
    final counts = <String, int>{};
    for (final doc in items) {
      counts[doc.category] = (counts[doc.category] ?? 0) + 1;
    }
    return counts;
  }

  @override
  Stream<List<Document>> watchAllDocuments({String? category}) => Stream.value(items);
}

void main() {
  late ControllerTestRepository repo;
  late DocumentController controller;

  setUp(() {
    repo = ControllerTestRepository();
    controller = DocumentController(
      getDocumentsUseCase: GetDocumentsUseCase(repo),
      getDocumentByIdUseCase: GetDocumentByIdUseCase(repo),
      addDocumentUseCase: AddDocumentUseCase(repo),
      updateDocumentUseCase: UpdateDocumentUseCase(repo),
      deleteDocumentUseCase: DeleteDocumentUseCase(repo),
      searchDocumentsUseCase: SearchDocumentsUseCase(repo),
      getDocumentCountsUseCase: GetDocumentCountsUseCase(repo),
    );
  });

  group('Application Layer - DocumentController State Management Tests', () {
    test('Trạng thái khởi tạo đúng chuẩn', () {
      expect(controller.documents, isEmpty);
      expect(controller.isLoading, isFalse);
      expect(controller.selectedCategory, AppConstants.categoryAll);
      expect(controller.searchQuery, isEmpty);
    });

    test('addDocument thêm tài liệu và tự động cập nhật danh sách', () async {
      final now = DateTime.now();
      final success = await controller.addDocument(Document(
        title: 'Thực hành Lập trình Mạng',
        description: 'Socket TCP/UDP',
        category: 'Bài tập',
        filePath: '',
        fileType: 'PDF',
        author: 'Đào Ngọc Đình',
        createdAt: now,
        updatedAt: now,
      ));

      expect(success, isTrue);
      expect(controller.documents.length, 1);
      expect(controller.documents.first.title, 'Thực hành Lập trình Mạng');
      expect(controller.countByCategory('Bài tập'), 1);
    });

    test('selectCategory lọc tài liệu đúng theo danh mục', () async {
      final now = DateTime.now();
      await controller.addDocument(Document(
        title: 'Bài giảng 1',
        description: '',
        category: 'Bài giảng',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      ));
      await controller.addDocument(Document(
        title: 'Bài tập 1',
        description: '',
        category: 'Bài tập',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      ));

      expect(controller.documents.length, 2);

      controller.selectCategory('Bài tập');
      await Future.delayed(const Duration(milliseconds: 50));

      expect(controller.documents.length, 1);
      expect(controller.documents.first.category, 'Bài tập');
    });

    test('countByCategory phản ánh tổng số tài liệu kho, không bị ảnh hưởng bởi bộ lọc',
        () async {
      final now = DateTime.now();
      for (var i = 0; i < 3; i++) {
        await controller.addDocument(Document(
          title: 'Bài giảng $i',
          description: '',
          category: 'Bài giảng',
          filePath: '',
          fileType: 'PDF',
          author: '',
          createdAt: now,
          updatedAt: now,
        ));
      }
      await controller.addDocument(Document(
        title: 'Bài tập 1',
        description: '',
        category: 'Bài tập',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      ));

      expect(controller.totalCount, 4);
      expect(controller.countByCategory('Bài giảng'), 3);
      expect(controller.countByCategory('Bài tập'), 1);
      expect(controller.countByCategory('Đề thi'), 0);

      // Lọc theo "Bài tập": danh sách chỉ còn 1 item nhưng số liệu chip phải giữ nguyên.
      controller.selectCategory('Bài tập');
      await Future.delayed(const Duration(milliseconds: 50));

      expect(controller.documents.length, 1);
      expect(controller.totalCount, 4);
      expect(controller.countByCategory(AppConstants.categoryAll), 4);
      expect(controller.countByCategory('Bài giảng'), 3);
      expect(controller.countByCategory('Bài tập'), 1);
    });

    test('Số lượng được cập nhật sau khi thêm, sửa và xóa tài liệu', () async {
      final now = DateTime.now();

      await controller.addDocument(Document(
        title: 'Tài liệu A',
        description: '',
        category: 'Bài giảng',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      ));
      expect(controller.countByCategory('Bài giảng'), 1);

      // Chuyển sang danh mục khác thì số liệu cũ phải về 0.
      final docId = controller.documents.first.id!;
      await controller.updateDocument(controller.documents.first.copyWith(category: 'Đề thi'));
      expect(controller.countByCategory('Bài giảng'), 0);
      expect(controller.countByCategory('Đề thi'), 1);
      expect(controller.totalCount, 1);

      await controller.deleteDocument(docId);
      expect(controller.totalCount, 0);
      expect(controller.countByCategory('Đề thi'), 0);
    });

    test('deleteDocument xóa tài liệu và làm mới danh sách', () async {
      final now = DateTime.now();
      await controller.addDocument(Document(
        title: 'Tài liệu cần xóa',
        description: '',
        category: 'Đề thi',
        filePath: '',
        fileType: 'PDF',
        author: '',
        createdAt: now,
        updatedAt: now,
      ));

      final docId = controller.documents.first.id!;
      final deleted = await controller.deleteDocument(docId);

      expect(deleted, isTrue);
      expect(controller.documents, isEmpty);
    });
  });
}
