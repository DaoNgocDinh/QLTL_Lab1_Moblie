import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/core/config/app_config.dart';
import 'package:qltl/data/repositories/in_memory_cloud_document_repository.dart';
import 'package:qltl/domain/entities/cloud_document.dart';
import 'package:qltl/domain/repositories/cloud_document_repository.dart';

void main() {
  group('Hệ thống Quản lý Tài liệu Cloud - Kiểm thử Phân quyền 3 Tài khoản (Checklist 6)', () {
    late InMemoryCloudDocumentRepository repository;

    final aliceId = AppConfig.userAlice.id;     // user_alice_001 (Owner)
    final bobId = AppConfig.userBob.id;         // user_bob_002   (Collaborator)
    final charlieId = AppConfig.userCharlie.id; // user_charlie_003 (Unauthorized Stranger)

    setUp(() {
      repository = InMemoryCloudDocumentRepository();
    });

    test('Kịch bản 1: Chủ sở hữu (Alice) tạo tài liệu mới, người khác không thấy (RLS Select)', () async {
      // Alice tạo tài liệu mới
      final newDoc = CloudDocument(
        id: 'doc_alice_private_01',
        ownerId: aliceId,
        ownerEmail: AppConfig.userAlice.email,
        ownerName: AppConfig.userAlice.displayName,
        title: 'BaoCao_BiMat_DoAn_Alice.pdf',
        description: 'Tài liệu mật chỉ riêng Alice được xem.',
        category: 'Đồ án',
        fileType: 'PDF',
        fileSize: 1024 * 1024,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      final createdDoc = await repository.createDocument(newDoc, aliceId);
      expect(createdDoc.id, 'doc_alice_private_01');
      expect(createdDoc.ownerId, aliceId);

      // Alice xem danh sách -> Thấy tài liệu
      final aliceDocs = await repository.getDocumentsForUser(aliceId);
      expect(aliceDocs.any((d) => d.id == 'doc_alice_private_01'), isTrue);

      // Bob và Charlie xem danh sách -> KHÔNG thấy tài liệu của Alice (RLS Select bảo vệ dữ liệu)
      final bobDocs = await repository.getDocumentsForUser(bobId);
      expect(bobDocs.any((d) => d.id == 'doc_alice_private_01'), isFalse);

      final charlieDocs = await repository.getDocumentsForUser(charlieId);
      expect(charlieDocs.any((d) => d.id == 'doc_alice_private_01'), isFalse);
    });

    test('Kịch bản 2: Alice chia sẻ tài liệu cho Bob với quyền "view", Bob xem được nhưng KHÔNG sửa được', () async {
      // doc_001 trong dữ liệu khởi tạo mặc định đã được Alice chia sẻ cho Bob với quyền 'view'
      final bobDocs = await repository.getDocumentsForUser(
        bobId,
        tab: DocumentTabFilter.shared,
      );
      expect(bobDocs.any((d) => d.id == 'doc_001'), isTrue);

      final bobDoc = await repository.getDocumentById('doc_001', bobId);
      expect(bobDoc.title, 'GiaoTrinh_LapTrinh_Flutter_Cloud.pdf');
      expect(bobDoc.isOwner(bobId), isFalse);
      expect(bobDoc.canEdit(bobId), isFalse);
      expect(bobDoc.canView(bobId), isTrue);

      // Bob cố tình cập nhật tài liệu -> Bị từ chối bởi RLS Update Policy
      final updatedAttempt = bobDoc.copyWith(
        title: 'Bob_Hack_ThayDoiTieuDe.pdf',
      );

      expect(
        () async => await repository.updateDocument(updatedAttempt, bobId),
        throwsA(isA<PermissionDeniedException>()),
      );
    });

    test('Kịch bản 3: Người lạ (Charlie) không có quyền bị từ chối truy cập mọi thao tác', () async {
      // Charlie không thấy doc_001 trong danh sách
      final charlieDocs = await repository.getDocumentsForUser(charlieId);
      expect(charlieDocs.any((d) => d.id == 'doc_001'), isFalse);

      // Charlie cố tình truy vấn trực tiếp bằng ID -> Ném ngoại lệ PermissionDeniedException
      expect(
        () async => await repository.getDocumentById('doc_001', charlieId),
        throwsA(isA<PermissionDeniedException>()),
      );

      // Charlie cố tình xóa tài liệu của Alice -> Ném ngoại lệ PermissionDeniedException
      expect(
        () async => await repository.deleteDocument('doc_001', charlieId),
        throwsA(isA<PermissionDeniedException>()),
      );

      // Charlie cố tình chia sẻ tài liệu của Alice cho người khác -> Ném ngoại lệ PermissionDeniedException
      expect(
        () async => await repository.shareDocument(
          documentId: 'doc_001',
          targetUserId: 'user_stranger',
          permissionLevel: 'edit',
          requestingUserId: charlieId,
        ),
        throwsA(isA<PermissionDeniedException>()),
      );
    });

    test('Kịch bản 4: Alice nâng cấp quyền cho Bob lên "edit", Bob cập nhật tài liệu thành công', () async {
      // Alice cấp quyền 'edit' cho Bob
      final perm = await repository.shareDocument(
        documentId: 'doc_001',
        targetUserId: bobId,
        permissionLevel: 'edit',
        requestingUserId: aliceId,
      );
      expect(perm.permissionLevel, 'edit');

      // Bob kiểm tra lại tài liệu -> canEdit là true
      final bobDoc = await repository.getDocumentById('doc_001', bobId);
      expect(bobDoc.canEdit(bobId), isTrue);

      // Bob cập nhật tài liệu
      final updatedDoc = bobDoc.copyWith(
        title: 'GiaoTrinh_Flutter_Cloud_Bob_DaSua.pdf',
        description: 'Bob đã bổ sung chương kiến trúc Supabase và RLS.',
      );

      final result = await repository.updateDocument(updatedDoc, bobId);
      expect(result.title, 'GiaoTrinh_Flutter_Cloud_Bob_DaSua.pdf');

      // Alice xem lại -> Dữ liệu đã được cập nhật toàn vẹn
      final aliceDoc = await repository.getDocumentById('doc_001', aliceId);
      expect(aliceDoc.title, 'GiaoTrinh_Flutter_Cloud_Bob_DaSua.pdf');
      expect(aliceDoc.description, 'Bob đã bổ sung chương kiến trúc Supabase và RLS.');
    });

    test('Kịch bản 5: Bob cố tình xóa tài liệu mà mình chỉ là cộng tác viên -> Bị từ chối', () async {
      // Dù có quyền edit, Bob vẫn KHÔNG phải là Owner nên KHÔNG được xóa
      expect(
        () async => await repository.deleteDocument('doc_001', bobId),
        throwsA(isA<PermissionDeniedException>()),
      );

      // Tài liệu vẫn tồn tại an toàn
      final doc = await repository.getDocumentById('doc_001', aliceId);
      expect(doc, isNotNull);
    });

    test('Kịch bản 6: Alice thu hồi quyền của Bob, Bob mất quyền truy cập tài liệu', () async {
      // Alice thu hồi quyền của Bob
      await repository.revokePermission(
        documentId: 'doc_001',
        targetUserId: bobId,
        requestingUserId: aliceId,
      );

      // Bob kiểm tra danh sách -> doc_001 không còn xuất hiện
      final bobDocs = await repository.getDocumentsForUser(bobId);
      expect(bobDocs.any((d) => d.id == 'doc_001'), isFalse);

      // Bob cố truy cập trực tiếp bằng ID -> Ném ngoại lệ PermissionDeniedException
      expect(
        () async => await repository.getDocumentById('doc_001', bobId),
        throwsA(isA<PermissionDeniedException>()),
      );
    });

    test('Kịch bản 7: Kiểm thử lọc danh mục, tìm kiếm và phân tách Tab (Của tôi vs Được chia sẻ)', () async {
      // Alice kiểm tra tab 'Của tôi'
      final aliceMine = await repository.getDocumentsForUser(
        aliceId,
        tab: DocumentTabFilter.mine,
      );
      expect(aliceMine.length, 3); // doc_001, doc_002, doc_003

      // Alice kiểm tra tab 'Được chia sẻ' -> 0 vì chưa ai chia sẻ cho Alice
      final aliceShared = await repository.getDocumentsForUser(
        aliceId,
        tab: DocumentTabFilter.shared,
      );
      expect(aliceShared.length, 0);

      // Lọc theo danh mục 'Bài giảng'
      final baiGiangDocs = await repository.getDocumentsForUser(
        aliceId,
        category: 'Bài giảng',
      );
      expect(baiGiangDocs.every((d) => d.category == 'Bài giảng'), isTrue);

      // Tìm kiếm theo từ khóa 'BaoCao'
      final searchResults = await repository.getDocumentsForUser(
        aliceId,
        query: 'BaoCao',
      );
      expect(searchResults.length, 1);
      expect(searchResults.first.id, 'doc_002');
    });
  });
}
