import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/application/controllers/auth_controller.dart';
import 'package:qltl/application/controllers/cloud_document_controller.dart';
import 'package:qltl/core/config/app_config.dart';
import 'package:qltl/data/repositories/in_memory_cloud_document_repository.dart';
import 'package:qltl/data/services/auth_service.dart';
import 'package:qltl/data/services/firebase_storage_service.dart';
import 'package:qltl/domain/repositories/cloud_document_repository.dart';

void main() {
  group('Kiểm thử Điều phối Trạng thái Cloud (AuthController & CloudDocumentController)', () {
    late AuthServiceImpl authService;
    late AuthController authController;
    late InMemoryCloudDocumentRepository documentRepo;
    late FirebaseStorageServiceImpl storageService;
    late CloudDocumentController documentController;

    setUp(() {
      authService = AuthServiceImpl();
      authController = AuthController(authService);
      documentRepo = InMemoryCloudDocumentRepository();
      storageService = FirebaseStorageServiceImpl();
      documentController = CloudDocumentController(
        documentRepository: documentRepo,
        storageRepository: storageService,
      );
    });

    test('Chuyển đổi tài khoản (Switch User) cập nhật đúng danh sách và quyền hạn', () async {
      // 1. Mặc định khởi tạo với Alice (Owner)
      await authController.switchUser(AppConfig.userAlice.id);
      expect(authController.currentUser?.id, AppConfig.userAlice.id);

      await documentController.loadDocuments(AppConfig.userAlice.id);
      expect(documentController.documents.length, 3);

      // 2. Chuyển sang Bob (Collaborator)
      await authController.switchUser(AppConfig.userBob.id);
      expect(authController.currentUser?.id, AppConfig.userBob.id);

      await documentController.loadDocuments(AppConfig.userBob.id);
      // Bob chỉ được chia sẻ doc_001
      expect(documentController.documents.length, 1);
      expect(documentController.documents.first.id, 'doc_001');

      // 3. Chuyển sang Charlie (Unauthorized Viewer)
      await authController.switchUser(AppConfig.userCharlie.id);
      expect(authController.currentUser?.id, AppConfig.userCharlie.id);

      await documentController.loadDocuments(AppConfig.userCharlie.id);
      // Charlie không có tài liệu nào
      expect(documentController.documents.length, 0);
    });

    test('Alice tải lên tài liệu mới thành công và danh mục được cập nhật', () async {
      final success = await documentController.uploadAndCreateDocument(
        userId: AppConfig.userAlice.id,
        userEmail: AppConfig.userAlice.email,
        userName: AppConfig.userAlice.displayName,
        title: 'DoAn_ChuyenDe_Flutter.pdf',
        description: 'Tài liệu hướng dẫn hoàn thành đồ án.',
        category: 'Đồ án',
        fileName: 'DoAn_ChuyenDe_Flutter.pdf',
        fileBytes: [1, 2, 3, 4, 5],
      );

      expect(success, isTrue);
      expect(documentController.documents.length, 4);
      expect(
        documentController.documents.any((d) => d.title == 'DoAn_ChuyenDe_Flutter.pdf'),
        isTrue,
      );
    });

    test('Chuyển tab lọc (Tất cả / Của tôi / Được chia sẻ) hoạt động chính xác', () async {
      // Bob đăng nhập
      await documentController.loadDocuments(AppConfig.userBob.id);

      // Tab Của tôi -> Bob chưa tạo tài liệu nào
      await documentController.setTab(DocumentTabFilter.mine, AppConfig.userBob.id);
      expect(documentController.documents.length, 0);

      // Tab Được chia sẻ -> Bob có 1 tài liệu doc_001
      await documentController.setTab(DocumentTabFilter.shared, AppConfig.userBob.id);
      expect(documentController.documents.length, 1);
      expect(documentController.documents.first.id, 'doc_001');
    });
  });
}
