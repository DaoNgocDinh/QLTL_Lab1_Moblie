import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:qltl/application/controllers/document_controller.dart';
import 'package:qltl/application/use_cases/add_document.dart';
import 'package:qltl/application/use_cases/delete_document.dart';
import 'package:qltl/application/use_cases/get_document_by_id.dart';
import 'package:qltl/application/use_cases/get_document_counts.dart';
import 'package:qltl/application/use_cases/get_documents.dart';
import 'package:qltl/application/use_cases/search_documents.dart';
import 'package:qltl/application/use_cases/update_document.dart';
import 'package:qltl/core/theme/app_theme.dart';
import 'package:qltl/domain/entities/document.dart';
import 'package:qltl/domain/repositories/document_repository.dart';
import 'package:qltl/presentation/pages/add_edit_document_page.dart';
import 'package:qltl/presentation/pages/document_list_page.dart';

class MockRepo implements DocumentRepository {
  final List<Document> docs = [
    Document(
      id: 1,
      title: 'Kiến trúc Phần mềm',
      description: 'Phân tích Cashew App',
      category: 'Bài giảng',
      filePath: '/docs/cashew.pdf',
      fileType: 'PDF',
      author: 'Đào Ngọc Đình',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  /// Ghi lại dữ liệu được gọi từ form để kiểm chứng validation chặn đúng chỗ.
  Document? lastAdded;
  String? updatedTitle;

  @override
  Future<List<Document>> getAllDocuments({String? category}) async => docs;

  @override
  Future<Document?> getDocumentById(int id) async => docs.first;

  @override
  Future<int> addDocument(Document document) async {
    lastAdded = document;
    return docs.length + 1;
  }

  @override
  Future<bool> updateDocument(Document document) async {
    updatedTitle = document.title;
    return true;
  }

  @override
  Future<int> deleteDocument(int id) async => 1;

  @override
  Future<List<Document>> searchDocuments(String keyword, {String? category}) async => docs;

  @override
  Future<Map<String, int>> countByCategory() async {
    final counts = <String, int>{};
    for (final doc in docs) {
      counts[doc.category] = (counts[doc.category] ?? 0) + 1;
    }
    return counts;
  }

  @override
  Stream<List<Document>> watchAllDocuments({String? category}) => Stream.value(docs);
}

Widget buildApp(DocumentController controller, {Widget? home}) {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider<DocumentController>.value(value: controller),
    ],
    child: MaterialApp(
      theme: AppTheme.lightTheme,
      home: home ?? const DocumentListPage(),
    ),
  );
}

/// Form thêm/chỉnh sửa dài hơn màn hình test mặc định (800x600), nên nút submit
/// và các thông báo lỗi nằm ngoài vùng nhìn. Dùng màn hình cao hơn cho các
/// test liên quan tới form.
void useTallScreen(WidgetTester tester) {
  tester.view.devicePixelRatio = 1.0;
  tester.view.physicalSize = const Size(1000, 2200);
  addTearDown(tester.view.reset);
}

DocumentController buildController(DocumentRepository repo) {
  return DocumentController(
    getDocumentsUseCase: GetDocumentsUseCase(repo),
    getDocumentByIdUseCase: GetDocumentByIdUseCase(repo),
    addDocumentUseCase: AddDocumentUseCase(repo),
    updateDocumentUseCase: UpdateDocumentUseCase(repo),
    deleteDocumentUseCase: DeleteDocumentUseCase(repo),
    searchDocumentsUseCase: SearchDocumentsUseCase(repo),
    getDocumentCountsUseCase: GetDocumentCountsUseCase(repo),
  );
}

void main() {
  testWidgets('Kiểm thử giao diện DocumentListPage hiển thị đầy đủ thành phần', (WidgetTester tester) async {
    final repo = MockRepo();
    final controller = buildController(repo);

    await tester.pumpWidget(buildApp(controller));

    // Initial pump & settle
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    // Verify Title
    expect(find.text('QL Tài Liệu Học Tập'), findsOneWidget);
    expect(find.text('Kiến trúc Cashew (Local-First)'), findsOneWidget);

    // Verify Search bar
    expect(find.byType(TextField), findsOneWidget);

    // Verify Filter chips
    expect(find.text('Tất cả'), findsOneWidget);
    expect(find.text('Bài giảng'), findsAtLeastNWidgets(1));

    // Verify tổng số tài liệu
    expect(find.text('Tổng: 1 tài liệu'), findsOneWidget);

    // Verify FAB
    expect(find.text('Thêm tài liệu'), findsOneWidget);
    expect(find.byType(FloatingActionButton), findsOneWidget);
  });

  testWidgets('Form thêm tài liệu chặn submit và hiển thị lỗi khi tiêu đề không hợp lệ',
      (WidgetTester tester) async {
    final repo = MockRepo();
    final controller = buildController(repo);
    useTallScreen(tester);

    await tester.pumpWidget(buildApp(controller, home: const AddEditDocumentPage()));
    await tester.pump();

    await tester.tap(find.text('Thêm tài liệu vào kho'));
    await tester.pumpAndSettle();

    // Form chưa hợp lệ -> hiển thị lỗi và không điều hướng đi nơi khác
    expect(find.text('Vui lòng nhập tên tài liệu'), findsOneWidget);
    expect(find.text('Thêm tài liệu mới'), findsOneWidget);
    expect(repo.lastAdded, isNull);
  });

  testWidgets('Form thêm tài liệu báo lỗi khi tiêu đề quá ngắn', (WidgetTester tester) async {
    final repo = MockRepo();
    final controller = buildController(repo);
    useTallScreen(tester);

    await tester.pumpWidget(buildApp(controller, home: const AddEditDocumentPage()));
    await tester.pump();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nhập tên tài liệu hoặc bài giảng...'),
      'ab',
    );
    await tester.tap(find.text('Thêm tài liệu vào kho'));
    await tester.pumpAndSettle();

    expect(find.text('Tên tài liệu phải có ít nhất 3 ký tự'), findsOneWidget);
    expect(repo.lastAdded, isNull);
  });

  testWidgets('Form chỉnh sửa tài liệu lưu được dữ liệu hợp lệ', (WidgetTester tester) async {
    final repo = MockRepo();
    final controller = buildController(repo);
    final document = repo.docs.first;
    useTallScreen(tester);

    await tester.pumpWidget(buildApp(controller));
    await tester.pumpAndSettle();

    // Đẩy form chỉnh sửa lên trên trang danh sách để kiểm tra việc pop sau khi lưu.
    unawaited(
      tester.state<NavigatorState>(find.byType(Navigator)).push(
        MaterialPageRoute<void>(
          builder: (_) => AddEditDocumentPage(document: document),
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nhập tên tài liệu hoặc bài giảng...'),
      'Kiến trúc Phần mềm (đã chỉnh sửa)',
    );
    await tester.tap(find.text('Lưu thay đổi'));
    await tester.pumpAndSettle();

    expect(repo.updatedTitle, 'Kiến trúc Phần mềm (đã chỉnh sửa)');
    // Form đã lưu thành công và trở về trang danh sách.
    expect(find.byType(AddEditDocumentPage), findsNothing);
    expect(find.text('QL Tài Liệu Học Tập'), findsOneWidget);
  });
}
