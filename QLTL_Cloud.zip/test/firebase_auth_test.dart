import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:qltl/data/services/auth_service.dart';
import 'package:qltl/domain/entities/app_user.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Kiểm thử Xác thực Firebase Auth', () {
    test('Đăng nhập tài khoản kiểm thử Alice đồng bộ thành công', () async {
      final authService = AuthServiceImpl();
      final user = await authService.signInDemoUser('user_alice_001');
      expect(user, isA<AppUser>());
      expect(user.email, 'alice.nguyen@student.edu.vn');
      authService.dispose();
    });

    test('Đăng nhập tài khoản kiểm thử Bob đồng bộ thành công', () async {
      final authService = AuthServiceImpl();
      final user = await authService.signInDemoUser('user_bob_002');
      expect(user, isA<AppUser>());
      expect(user.email, 'bob.tran@student.edu.vn');
      authService.dispose();
    });

    test('Đăng ký tài khoản Email mới thành công trên Firebase Auth REST', () async {
      final mockClient = MockClient((request) async {
        if (request.url.path.contains('accounts:signUp')) {
          return http.Response(
            jsonEncode({
              'kind': 'identitytoolkit#SignupNewUserResponse',
              'idToken': 'mock_token',
              'email': 'student_test@qltl.cloud',
              'refreshToken': 'mock_refresh',
              'expiresIn': '3600',
              'localId': 'firebase_mock_uid_123',
            }),
            200,
          );
        }
        return http.Response('Not Found', 404);
      });

      final authService = AuthServiceImpl(httpClient: mockClient);
      final newUser = await authService.signUpWithEmailPassword(
        'student_test@qltl.cloud',
        'Password123!',
        displayName: 'Sinh Viên Test',
      );

      expect(newUser.id, 'firebase_mock_uid_123');
      expect(newUser.email, 'student_test@qltl.cloud');
      expect(newUser.displayName, 'Sinh Viên Test');
      authService.dispose();
    });

    test('Đăng nhập Email và Mật khẩu thành công qua Firebase Auth REST', () async {
      final mockClient = MockClient((request) async {
        if (request.url.path.contains('accounts:signInWithPassword')) {
          return http.Response(
            utf8.decode(utf8.encode(jsonEncode({
              'kind': 'identitytoolkit#VerifyPasswordResponse',
              'localId': 'firebase_alice_uid_001',
              'email': 'alice.nguyen@student.edu.vn',
              'displayName': 'Nguyen Thi Thu Ha',
              'idToken': 'mock_token',
            }))),
            200,
            headers: {'content-type': 'application/json; charset=utf-8'},
          );
        }
        return http.Response('Not Found', 404);
      });

      final authService = AuthServiceImpl(httpClient: mockClient);
      final user = await authService.signInWithEmailPassword(
        'alice.nguyen@student.edu.vn',
        'Password123!',
      );

      expect(user.id, 'firebase_alice_uid_001');
      expect(user.email, 'alice.nguyen@student.edu.vn');
      authService.dispose();
    });
  });
}
