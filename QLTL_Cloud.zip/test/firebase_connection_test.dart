import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/firebase_options.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Kiểm tra cấu hình DefaultFirebaseOptions cho các nền tảng', () {
    expect(DefaultFirebaseOptions.android.projectId, 'qltl-cloud-doc');
    expect(DefaultFirebaseOptions.android.storageBucket, 'qltl-cloud-doc.firebasestorage.app');
    expect(DefaultFirebaseOptions.web.projectId, 'qltl-cloud-doc');
    expect(DefaultFirebaseOptions.windows.projectId, 'qltl-cloud-doc');
  });
}
