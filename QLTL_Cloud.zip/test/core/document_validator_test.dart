import 'package:flutter_test/flutter_test.dart';
import 'package:qltl/core/constants/app_constants.dart';
import 'package:qltl/core/validation/document_validator.dart';

void main() {
  group('Core Layer - DocumentValidator Tests', () {
    group('validateTitle', () {
      test('Chấp nhận tiêu đề hợp lệ', () {
        expect(DocumentValidator.validateTitle('Bài giảng Kiến trúc'), isNull);
        expect(DocumentValidator.validateTitle('Flutter cơ bản'), isNull);
      });

      test('Báo lỗi khi tiêu đề rỗng hoặc chỉ chứa khoảng trắng', () {
        expect(DocumentValidator.validateTitle(null), isNotNull);
        expect(DocumentValidator.validateTitle(''), isNotNull);
        expect(DocumentValidator.validateTitle('     '), isNotNull);
      });

      test('Báo lỗi khi tiêu đề quá ngắn', () {
        expect(DocumentValidator.validateTitle('ab'), isNotNull);
        expect(DocumentValidator.validateTitle('abc'), isNull);
      });

      test('Báo lỗi khi tiêu đề quá dài', () {
        final long = 'a' * (DocumentValidator.maxTitleLength + 1);
        expect(DocumentValidator.validateTitle(long), isNotNull);
        expect(
          DocumentValidator.validateTitle('a' * DocumentValidator.maxTitleLength),
          isNull,
        );
      });
    });

    group('validateCategory', () {
      test('Chấp nhận danh mục nằm trong danh sách cho phép', () {
        for (final category in AppConstants.categories) {
          expect(DocumentValidator.validateCategory(category), isNull);
        }
      });

      test('Báo lỗi khi danh mục rỗng', () {
        expect(DocumentValidator.validateCategory(null), isNotNull);
        expect(DocumentValidator.validateCategory('  '), isNotNull);
      });

      test('Báo lỗi khi danh mục là "Tất cả" hoặc nằm ngoài danh sách', () {
        expect(DocumentValidator.validateCategory(AppConstants.categoryAll), isNotNull);
        expect(DocumentValidator.validateCategory('Danh mục lạ'), isNotNull);
      });
    });

    group('validateFileType', () {
      test('Chấp nhận định dạng hợp lệ', () {
        for (final type in AppConstants.fileTypes) {
          expect(DocumentValidator.validateFileType(type), isNull);
        }
      });

      test('Báo lỗi khi định dạng rỗng hoặc không hợp lệ', () {
        expect(DocumentValidator.validateFileType(null), isNotNull);
        expect(DocumentValidator.validateFileType(''), isNotNull);
        expect(DocumentValidator.validateFileType('TXT'), isNotNull);
      });
    });

    group('validateFilePath', () {
      test('Cho phép để trống (trường tùy chọn)', () {
        expect(DocumentValidator.validateFilePath(null), isNull);
        expect(DocumentValidator.validateFilePath('   '), isNull);
      });

      test('Chấp nhận đường dẫn hợp lệ', () {
        expect(DocumentValidator.validateFilePath('/documents/lectures/bai1.pdf'), isNull);
        expect(DocumentValidator.validateFilePath('C:\\docs\\bai2.docx'), isNull);
      });

      test('Báo lỗi khi đường dẫn chứa ký tự không hợp lệ', () {
        expect(DocumentValidator.validateFilePath('/docs/bai?.pdf'), isNotNull);
        expect(DocumentValidator.validateFilePath('/docs/ba<i>.pdf'), isNotNull);
      });

      test('Báo lỗi khi đường dẫn quá dài', () {
        final long = '/docs/${'a' * DocumentValidator.maxFilePathLength}';
        expect(DocumentValidator.validateFilePath(long), isNotNull);
      });
    });

    group('validateAuthor & validateDescription', () {
      test('Cho phép để trống', () {
        expect(DocumentValidator.validateAuthor(''), isNull);
        expect(DocumentValidator.validateDescription(''), isNull);
      });

      test('Báo lỗi khi vượt quá độ dài cho phép', () {
        expect(
          DocumentValidator.validateAuthor('a' * (DocumentValidator.maxAuthorLength + 1)),
          isNotNull,
        );
        expect(
          DocumentValidator.validateDescription(
              'a' * (DocumentValidator.maxDescriptionLength + 1)),
          isNotNull,
        );
      });
    });

    group('collectFirstError', () {
      test('Trả về null khi tài liệu hoàn toàn hợp lệ', () {
        final error = DocumentValidator.collectFirstError(
          title: 'Bài giảng Kiến trúc',
          category: AppConstants.categoryLecture,
          fileType: AppConstants.fileTypePdf,
          filePath: '/docs/bai1.pdf',
          author: 'TS. Nguyễn Văn A',
          description: 'Mô tả nội dung',
        );
        expect(error, isNull);
      });

      test('Trả về lỗi đầu tiên tìm thấy theo thứ tự ưu tiên', () {
        final error = DocumentValidator.collectFirstError(
          title: '',
          category: '',
          fileType: 'TXT',
        );
        expect(error, DocumentValidator.validateTitle(''));
      });

      test('Báo lỗi định dạng khi tiêu đề và danh mục hợp lệ', () {
        final error = DocumentValidator.collectFirstError(
          title: 'Bài giảng Kiến trúc',
          category: AppConstants.categoryLecture,
          fileType: 'TXT',
        );
        expect(error, DocumentValidator.validateFileType('TXT'));
      });
    });
  });
}