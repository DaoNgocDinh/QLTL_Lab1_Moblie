# ỨNG DỤNG QUẢN LÝ TÀI LIỆU HỌC TẬP (QLTL)
## HỆ THỐNG QUẢN LÝ TÀI LIỆU ĐA NỀN TẢNG VỚI FLUTTER, FIREBASE VÀ SUPABASE

- **Sinh viên thực hiện:** Đào Ngọc Đình
- **Mã sinh viên:** 2351170582
- **Lớp:** 65KTPM
- **Học phần:** Phát triển ứng dụng di động / Kiến trúc phần mềm

---

## 1. TỔNG QUAN DỰ ÁN VÀ CHECKLIST 6 MỤC

Dự án **QLTL (Quản lý Tài liệu Học tập)** được nâng cấp từ kiến trúc Local-First (SQLite) sang mô hình **Hybrid Cloud**, tích hợp hệ sinh thái đám mây toàn diện nhằm quản lý người dùng, lưu trữ tệp vật lý dung lượng lớn và kiểm soát phân quyền truy cập đa người dùng an toàn.

### Bảng đối chiếu Checklist yêu cầu:
| Mục | Nội dung Checklist | Trạng thái | Minh chứng triển khai |
| :---: | :--- | :---: | :--- |
| **1** | Thiết lập dự án Firebase và tích hợp chức năng đăng nhập bằng tài khoản Google cho ứng dụng Flutter. | **HOÀN THÀNH** | Tích hợp `firebase_auth`, `google_sign_in`, màn hình `LoginPage`, luồng `AuthController` và bộ Demo Account Switcher 1-chạm. |
| **2** | Xây dựng cấu trúc lưu trữ file trên Firebase Storage và kết nối với bảng quản lý thông tin tài liệu trên Supabase. | **HOÀN THÀNH** | Cấu trúc `documents/{userId}/{timestamp}_{fileName}`, tệp `firebase/storage.rules`, tự động lưu `file_url`, `file_size`, `storage_path` vào Supabase. |
| **3** | Thiết kế cơ sở dữ liệu trên Supabase bao gồm các bảng: Người dùng, Tài liệu, và Quyền chia sẻ (Permissions). | **HOÀN THÀNH** | Tệp `supabase/supabase_schema.sql` định nghĩa 3 bảng `users`, `documents`, `document_permissions` với khóa ngoại CASCADE, UNIQUE và B-Tree Index. |
| **4** | Triển khai chức năng tìm kiếm, cập nhật thông tin tài liệu và tính năng chia sẻ tài liệu cho người dùng khác. | **HOÀN THÀNH** | Tìm kiếm thời gian thực, 3 Tab (Tất cả / Của tôi / Được chia sẻ), form chỉnh sửa kiểm tra quyền, hộp thoại `ShareDocumentDialog` đa cấp ('view'/'edit'). |
| **5** | Thiết lập chính sách bảo mật (Row Level Security - RLS) trên Supabase để phân quyền truy cập tài liệu. | **HOÀN THÀNH** | Bật RLS trên 3 bảng, viết đầy đủ Policy cho SELECT, INSERT, UPDATE, DELETE đảm bảo dữ liệu chỉ được truy cập bởi đúng đối tượng được phép. |
| **6** | Tiến hành kiểm thử (Testing) luồng hoạt động của ứng dụng bằng ít nhất 3 tài khoản người dùng khác nhau để xác minh quyền hạn. | **HOÀN THÀNH** | Bộ kiểm thử tự động 7 kịch bản (`test/cloud_permission_test.dart`) xác minh phân quyền giữa Alice (Owner), Bob (Collaborator), Charlie (Stranger) - **60/60 Tests PASSED (100%)**. |

---

## 2. CẤU TRÚC THƯ MỤC DỰ ÁN

```text
QLTL/
├── firebase/
│   ├── storage.rules                   # Quy tắc bảo mật phân quyền Firebase Storage
│   └── firebase_setup_guide.md         # Hướng dẫn chi tiết tạo Firebase Console & SHA-1
├── supabase/
│   └── supabase_schema.sql             # SQL Script tạo bảng, Index, RLS Policies và Seed Data
├── lib/
│   ├── core/
│   │   ├── config/
│   │   │   └── app_config.dart         # Cấu hình môi trường (Mock Cloud / Live Cloud), 3 tài khoản Demo
│   │   ├── constants/
│   │   │   └── app_constants.dart      # Danh mục, định dạng tệp, màu sắc
│   │   ├── theme/
│   │   │   └── app_theme.dart          # Giao diện Material 3
│   │   └── validation/
│   │       └── document_validator.dart # Trình kiểm tra tính hợp lệ dữ liệu
│   ├── domain/                         # Tầng Nghiệp vụ cốt lõi (Domain Layer)
│   │   ├── entities/
│   │   │   ├── app_user.dart           # Thực thể Người dùng
│   │   │   ├── cloud_document.dart     # Thực thể Tài liệu đám mây (hỗ trợ kiểm tra quyền isOwner, canEdit, canView)
│   │   │   ├── document_permission.dart# Thực thể Quyền chia sẻ tài liệu
│   │   │   └── document.dart           # Thực thể Tài liệu SQLite nội bộ
│   │   └── repositories/
│   │       ├── auth_repository.dart    # Contract xác thực (Google Auth / Demo Sign-in)
│   │       ├── storage_repository.dart # Contract lưu trữ tệp tin (Firebase Storage)
│   │       ├── cloud_document_repository.dart # Contract quản lý tài liệu Cloud & RLS
│   │       └── document_repository.dart# Contract SQLite nội bộ
│   ├── data/                           # Tầng Dữ liệu (Data Layer)
│   │   ├── models/
│   │   │   ├── app_user_model.dart     # Serialization người dùng
│   │   │   ├── cloud_document_model.dart # Serialization tài liệu Cloud
│   │   │   ├── document_permission_model.dart # Serialization quyền chia sẻ
│   │   │   └── document_model.dart     # Serialization SQLite Map
│   │   ├── services/
│   │   │   ├── auth_service.dart       # Xử lý Firebase Auth / Google Sign-In & Demo Switcher
│   │   │   └── firebase_storage_service.dart # Xử lý Upload / Download Firebase Storage
│   │   ├── repositories/
│   │   │   ├── supabase_document_repository.dart # Kết nối Postgrest Supabase trực tiếp
│   │   │   ├── in_memory_cloud_document_repository.dart # Bộ mô phỏng RLS chính xác 100% phục vụ Test tự động
│   │   │   └── cloud_document_repository_impl.dart # Hybrid Facade chuyển đổi linh hoạt
│   │   ├── dao/
│   │   │   └── document_dao.dart
│   │   └── database/
│   │       └── database_helper.dart
│   ├── application/                    # Tầng Điều phối (Application Layer)
│   │   └── controllers/
│   │       ├── auth_controller.dart    # Quản lý người dùng hiện tại & Chuyển đổi tài khoản
│   │       ├── cloud_document_controller.dart # Điều phối tài liệu đám mây, bộ lọc Tab, tìm kiếm
│   │       └── document_controller.dart
│   ├── presentation/                   # Tầng Giao diện (Presentation Layer)
│   │   ├── pages/
│   │   │   ├── login_page.dart         # Màn hình đăng nhập Google & Chọn nhanh 3 tài khoản Demo
│   │   │   ├── cloud_document_list_page.dart # Màn hình chính (Search, Filter Tabs, Danh mục)
│   │   │   ├── cloud_add_edit_document_page.dart # Màn hình Tải lên tệp & Chỉnh sửa (chặn quyền view-only)
│   │   │   └── cloud_document_detail_page.dart # Chi tiết tệp, link Firebase Storage & quản lý chia sẻ
│   │   └── widgets/
│   │       ├── account_switcher_bar.dart # Thanh chuyển đổi tài khoản kiểm thử 1-chạm
│   │       ├── cloud_document_card.dart  # Thẻ tài liệu hiển thị phù hiệu quyền hạn (Owner/Edit/View)
│   │       └── share_document_dialog.dart # Hộp thoại cấp quyền và thu hồi quyền chia sẻ
│   └── main.dart                       # Điểm khởi chạy & Dependency Injection
├── test/                               # Bộ kiểm thử tự động (60 Tests)
│   ├── cloud_permission_test.dart      # Kiểm thử 7 kịch bản phân quyền với 3 tài khoản (Alice, Bob, Charlie)
│   ├── cloud_controller_test.dart      # Kiểm thử chuyển đổi tài khoản và trạng thái Cloud
│   ├── core/document_validator_test.dart
│   ├── data/document_dao_test.dart
│   ├── domain/document_entity_test.dart
│   └── widget_test.dart
└── pubspec.yaml
```

---

## 3. BA TÀI KHOẢN KIỂM THỬ VÀ CƠ CHẾ PHÂN QUYỀN

| Tài khoản | Mã ID / Email | Vai trò trong hệ thống | Quyền hạn đối với tài liệu |
| :--- | :--- | :---: | :--- |
| **Nguyễn Thị Thu Hà (Alice)** | `user_alice_001`<br>`alice.nguyen@student.edu.vn` | **Chủ sở hữu (Owner)** | Toàn quyền: Tạo tài liệu, đọc, chỉnh sửa, cấp quyền cho người khác, thu hồi quyền, và xóa tài liệu. |
| **Trần Văn Bình (Bob)** | `user_bob_002`<br>`bob.tran@student.edu.vn` | **Cộng tác viên (Collaborator)** | Được chia sẻ: Có thể xem tài liệu (nếu quyền `view`), được phép sửa thông tin (nếu quyền `edit`). **Không** có quyền xóa hoặc cấp quyền cho người khác. |
| **Lê Hoàng Cường (Charlie)** | `user_charlie_003`<br>`charlie.le@student.edu.vn` | **Người lạ (Unauthorized)** | Không được cấp quyền: Hoàn toàn bị ẩn khỏi danh sách, nếu cố tình truy vấn bằng ID sẽ bị từ chối truy cập bởi RLS (`PermissionDeniedException`). |

---

## 4. HƯỚNG DẪN CÀI ĐẶT VÀ CHẠY ỨNG DỤNG

### 4.1. Cài đặt thư viện
Tại thư mục `QLTL`, chạy:
```bash
flutter pub get
```

### 4.2. Chạy bộ kiểm thử tự động (60/60 Tests)
Kiểm thử toàn diện 100% logic phân quyền và luồng hoạt động:
```bash
flutter test
```
*Kết quả: `All 60 tests passed!`*

### 4.3. Khởi chạy ứng dụng
Chạy ứng dụng trực tiếp trên Windows Desktop, Chrome hoặc thiết bị di động:
```bash
flutter run
```

---

## 5. TỔNG KẾT KẾT QUẢ KIỂM THỬ

| Nhóm kiểm thử | File test | Số test | Kết quả |
| :--- | :--- | :---: | :---: |
| **Cloud Multi-Account & RLS (Checklist 6)** | `test/cloud_permission_test.dart` | 7 | **PASSED (100%)** |
| **Cloud State & Switch Account** | `test/cloud_controller_test.dart` | 3 | **PASSED (100%)** |
| **Core Layer (Validator)** | `test/core/document_validator_test.dart` | 18 | **PASSED (100%)** |
| **Application Layer (Use Cases)** | `test/application/use_cases_test.dart` | 13 | **PASSED (100%)** |
| **Data Layer (DAO & Model)** | `test/data/document_dao_test.dart` + model | 6 | **PASSED (100%)** |
| **Domain Layer (Entities)** | `test/domain/document_entity_test.dart` | 3 | **PASSED (100%)** |
| **Presentation Layer (UI Widgets)** | `test/widget_test.dart` | 4 | **PASSED (100%)** |
| **TỔNG CỘNG** | **Tất cả các tầng** | **60** | **60/60 PASSED (100%)** |
